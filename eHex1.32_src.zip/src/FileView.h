#ifndef FILEVIEW_H
#define FILEVIEW_H

typedef struct FileNode
{
    char *Name; //����
    int16 Index; //���,��1��ʼ
    uint8 Type; //���� 
    int32 Size; //��С
    struct FileNode *Before; //��һ�ڵ�
    struct FileNode *Next; //��һ�ڵ�
}FILENODE, *PFILENODE;

typedef void (*FV_CB)(char *dir, char *name);

void FV_Init(void);
void FV_Draw(uint8 Refresh);
void FV_Show(char *Title, char *LastPath, int32 flag, FV_CB cbFunc);
void FV_End(void);

int32 FV_Event(int32 code, int32 p0, int32 p1);

#endif