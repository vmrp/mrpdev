#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include "FileIO.h"

//��Сֵ
#ifndef MIN
# define MIN(a,b) (((a)<(b))?(a):(b))
#endif

//���ֵ
#ifndef MAX
# define MAX(a,b) (((a)>(b))?(a):(b))
#endif

//�ͷŶ�̬�����ڴ�
#ifndef TRYFREE
# define TRYFREE(p) \
    if (NULL != p) \
    { \
        mrc_free(p); \
        p = NULL; \
    }
#endif

//�ر��ļ�
#ifndef TRYCLOSE
# define TRYCLOSE(fd) \
    if (0 != fd) \
    { \
        mrc_close(fd); \
        fd = 0; \
    }
#endif

typedef struct
{
    uint32 total; //�ܵĴ�С
    uint32 tunit; //�ܴ�С�ĵ�λ
    uint32 account; //ʣ��ռ�Ĵ�С
    uint32 unit; //ʣ���С�ĵ�λ
} T_DSM_FREE_SAPCE;

void Data2Hex(uint8 *Data, int32 dataSize, uint8 *HexBuffer, int32 bufSize);
void Hex2Data(uint8 *HexBuffer, int32 hexSize, uint8 *DataBuffer, int32 dataSize);

int32 CopyFile(char *srcFile, char *destFile);
int32 CopyFileEx(char *srcFile, char *destFile, uint32 srcPos, uint32 destPos, uint32 copySize);
int32 CopyFileFullPath(char *srcPath, char *destPath, char *srcFile, char *destFile);
int32 CopyFileByHandle(int32 ifd, int32 ofd, uint32 copySize);

int32 ReadFile(char *dir, char *file, int32 pos, uint8 *buf, int32 bufSize);
int32 SaveFile(char *dir, char *file, int32 pos, uint8 *buf, int32 bufSize);
int32 FindFromFile(char *dir, char *file, int32 offset, uint8 *data, int32 size);

int32 GetDir(char* strDir);
int32 Switch2Dir(const char* strDisk);
uint32 GetDiskSize(const char* strDisk, uint8 Type);

int32 OpenInPath(const char *path, const char *name, uint32 mode);
int32 FileLenInPath(const char *path, const char *name);

int32 GetAppId(void);
int32 GetAppVer(void);

int32 GetLast(uint8 *T, int32 TLen, uint8 C);
int32 BM(uint8 *S, uint8 *T, int32 SLen, int32 TLen);

int32 watoi(char *UniStr);
char *witoa(int32 Value);

int32 stricmp(uint8 *dst, uint8 *src);
int32 str2wstr(const char* utf8, uint8* unicode, int32 size);
int32 wstr2str(const uint8* unicode, char* utf8, int32 size);

void UCase(char *buf, int32 bufSize);
void ExchangeBytes(uint8 *Buffer, int32 bufSize);
void GBToUni(const char *gbStr, char *uniBuffer, int32 bufSize);
void UniToGB(const char *uniStr, char *gbBuffer, int32 bufSize);
void DecodeStr(uint8 StrBytes[], uint8 XorByte);

void ColorUL2ST(uint32 uColor, mr_colourSt *tColor);
void Screen2File(char *fName);
void WLog(char* Text, int32 Value);

#endif