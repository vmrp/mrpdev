/*
* �Ի��ļ��������
*/

#include <mrc_base.h>

#include "FileView.h"
#include "Functions.h"
#include "Draw.h"
#include "AppMain.h"
#include "KeyTimer.h"
#include "LocalUI.h"

#define MR_IS_DISK    16
#define MR_IS_OPEN    32

static FV_CB FVCallBack; //�ļ�����ص�����
static int32 FVFlag; //�ļ�������Ͳ���
static char FVTitle[32]; //����������

static PFILENODE PathNodes; //����·��ȫ���ڵ�
static PFILENODE FirstNode, TopNode, FocusNode; //�ļ������׽ڵ㣬����ʾ�ڵ㣬��ǰ�ڵ�
static int32 FileCount, VisCount; //�ļ��������б�����ʾ��Ŀ��
static char FullPath[256]; //����·��

extern mr_screenRectSt rectTitle, rectTool; //��������������
//static mr_screenRectSt rectTitle, rectTool; //��������������
//static mr_screenRectSt rectTCmd1, rectTCmd2; //��������ť
static mr_screenRectSt rectInput, rectInfo;  //·���������Ϣ��
static mr_screenRectSt rectList, rectScroll; //�ļ��б���������
static mr_screenRectSt rectSpace; //

static uint16 ItemHeight; //�б���߶�

static POSXY_ST MousePos; //��������λ��
static uint8 IsScrolling; //�Ƿ�������ڹ���
static int16 InputIndex; //�����������

int32 FV_FindFiles(void);
void FV_SwitchNode(uint8 Action);
void FV_ClearNodes(void);
void FV_ClearPathNodes(void);
void FV_DoListEvent(uint8 KeyCode);

//��ʼ���ļ����
void FV_Init(void)
{
    int32 fw, fh;
    uint16 scnWidth, scnHeight;
    mr_screeninfo sInfo;

    mrc_getScreenInfo(&sInfo); //��ȡ��Ļ�ߴ���Ϣ
    mrc_unicodeTextWidthHeight((uint16*)"\x65\x87\x67\x2c\x0\x0", AppDatas.AppFont, &fw, &fh); //"�ı�"

    //�趨����
    scnWidth = (uint16)sInfo.width;
    scnHeight = (uint16)sInfo.height;
    ItemHeight = (uint16)(fh + 4);

    //�趨�ؼ�λ����Ϣ
    rectInfo.x = 0; rectInfo.y = rectTitle.h; rectInfo.w = scnWidth; rectInfo.h = ItemHeight;
    rectInput.x = 0; rectInput.y = rectInfo.y + rectInfo.h + 1; rectInput.w = scnWidth; rectInput.h = ItemHeight + 2;
    rectList.x = 0; rectList.y = rectInput.y + rectInput.h + 1; rectList.w = scnWidth - 5; rectList.h = scnHeight - rectTitle.h - rectTool.h - rectInfo.h - rectInput.h - 3;
    rectScroll.x = scnWidth - 5; rectScroll.y = rectList.y; rectScroll.w = 5; rectScroll.h = rectList.h;
    rectSpace.x = rectInfo.x; rectSpace.y = rectInfo.y; rectSpace.w = rectInfo.w; rectSpace.h = rectInfo.h + rectInput.h + rectList.h + 2;

    //rectTitle.x = 0; rectTitle.y = 0; rectTitle.w = scnWidth; rectTitle.h = ItemHeight;
    //rectTool.x = 0; rectTool.y = scnHeight - ItemHeight; rectTool.w = scnWidth; rectTool.h = ItemHeight;
    //rectTCmd1.x = 0; rectTCmd1.y = rectTool.y; rectTCmd1.w = ItemHeight; rectTCmd1.h = rectTool.h;
    //rectTCmd2.x = scnWidth - ItemHeight; rectTCmd2.y = rectTool.y; rectTCmd2.w = ItemHeight; rectTCmd2.h = rectTool.h;

    if (ItemHeight < 16)
        ItemHeight = 16;
    VisCount = rectList.h / ItemHeight;
}

//�����ļ�������ͷ��ڴ�
void FV_End(void)
{
    FV_ClearNodes();
    FV_ClearPathNodes();
}

//�����ļ��б�
void FV_DrawList(uint8 Refresh)
{
    PFILENODE fNode = NULL;
    mr_screenRectSt itemRect, txtRect;
    char fInfo[32] = {0};
    uint8 sr, sg, sb;
    int16 picY, sclY, sclH;
    
    DrawFillRect(rectSpace, AppColor.backColor);

    /*------------------------------------------------------------*/
    //�����
    DrawRoundRect(rectInput);
    DrawTextMidLeftA(rectInput, FullPath, AppColor.textdColor);

    /*------------------------------------------------------------*/
    //�б�
    itemRect.x = rectList.x + 2; itemRect.y = rectList.y + 2; itemRect.w = rectList.w - 4; itemRect.h = ItemHeight;
    txtRect.x = rectList.x + 2 + 16; txtRect.y = rectList.y + 2; txtRect.w = rectList.w - 4 - 16; txtRect.h = ItemHeight;

    fNode = TopNode;

    //���Ƹ����б���
    while(fNode)
    {
        if (fNode == FocusNode) //������
            DrawShadeRect(itemRect);

        DrawTextMidLeftA(txtRect, fNode->Name, AppColor.textdColor);

        //��ʾͼ��
        switch(fNode->Type)
        {
        case MR_IS_DISK:
            if (-1 == fNode->Size) //ȡ�ô��̴�С
                fNode->Size = GetDiskSize(fNode->Name, 0);
            picY = 0;
            break;
        case MR_IS_DIR:
            picY = 16;
            break;
        case MR_IS_FILE:
            if (-1 == fNode->Size) //ȡ���ļ���С
            {
                fNode->Size = FileLenInPath(FullPath, fNode->Name);
                if (-1 == fNode->Size)
                    fNode->Type = MR_IS_OPEN; //�ı�����Ϊ�޷������ļ�
            }

            if (MR_IS_FILE == fNode->Type)
                picY = 32;
            else
                picY = 64;
            break;
        case MR_IS_OPEN:
            picY = 64;
            break;
        default:
            picY = 48;
            break;
        }
        mrc_bitmapShow(0, 2, itemRect.y + (itemRect.h - 16) / 2, BM_TRANSPARENT, 0, picY, 16, 16);

        itemRect.y += ItemHeight;
        txtRect.y = itemRect.y;

        if (itemRect.y + itemRect.h >= rectList.y + rectList.h)
            break;

        fNode = fNode->Next;
    }

    DrawRoundRect(rectList);

    /*------------------------------------------------------------*/
    //��Ϣ��
    DrawFillRect(rectInfo, AppColor.lightColor);
    DrawRoundRect(rectInfo);

    //���
    if (FileCount <= 0)
        mrc_sprintf(fInfo, "0/0");
    else if (NULL != FocusNode)
        mrc_sprintf(fInfo, "%d/%d", FocusNode->Index, FileCount);
    DrawTextMidRightA(rectInfo, fInfo, AppColor.textdColor);

    //��Ϣ
    if (FileCount <= 0)
    {
        mrc_sprintf(fInfo, "���ļ���");
    }
    else if (NULL != FocusNode)
    {
        switch(FocusNode->Type)
        {
        case MR_IS_DISK:
            {
                if (FocusNode->Size > 1024 * 1024)
                    mrc_sprintf(fInfo, "%d.%dGB",  FocusNode->Size / (1024 * 1024), (FocusNode->Size % (1024 * 1024)) * 100 / (1024 * 1024));
                else if (FocusNode->Size > 1024)
                    mrc_sprintf(fInfo, "%d.%dMB", FocusNode->Size / 1024, (FocusNode->Size % 1024) * 100 / 1024);
                else
                    mrc_sprintf(fInfo, "%dKB", FocusNode->Size);
                break;
            }
        case MR_IS_FILE:
            {
                if (FocusNode->Size > 1024 * 1024 * 1024)
                    mrc_sprintf(fInfo, "%d.%dGB",  FocusNode->Size / (1024 * 1024 * 1024), (FocusNode->Size % (1024 * 1024 * 1024)) * 100 / (1024 * 1024 * 1024));
                else if (FocusNode->Size > 1024 * 1024)
                    mrc_sprintf(fInfo, "%d.%dMB",  FocusNode->Size / (1024 * 1024), (FocusNode->Size % (1024 * 1024)) * 100 / (1024 * 1024));
                else if (FocusNode->Size > 1024)
                    mrc_sprintf(fInfo, "%d.%dKB", FocusNode->Size / 1024, (FocusNode->Size % 1024) * 100 / 1024);
                else
                    mrc_sprintf(fInfo, "%dB", FocusNode->Size);
                break;
            }
        case MR_IS_DIR:
            mrc_sprintf(fInfo, "�ļ���");
            break;
        case MR_IS_OPEN:
            mrc_sprintf(fInfo, "�޷�����");
            break;
        default:
            mrc_sprintf(fInfo, "�����ļ�");
            break;
        }
    }
    DrawTextMidLeftA(rectInfo, fInfo, AppColor.textdColor); 

    /*------------------------------------------------------------*/
    //������
    if (FileCount <= VisCount)
    {
        //mrc_drawRect(rectScroll.x, rectScroll.y + 1, rectScroll.w, rectScroll.h - 2, PIXEL888RED(AppColor.deepColor), PIXEL888GREEN(AppColor.deepColor), PIXEL888BLUE(AppColor.deepColor));
    }
    else
    {
        //mrc_drawRect(rectScroll.x, rectScroll.y + 1 + (rectScroll.h - 2) * (TopNode->Index - 1) / (int16)FileCount, rectScroll.w, (rectScroll.h - 2) * (int16)VisCount / (int16)FileCount, 
        //    PIXEL888RED(AppColor.deepColor), PIXEL888GREEN(AppColor.deepColor), PIXEL888BLUE(AppColor.deepColor));

        sr = PIXEL888RED(AppColor.deepColor);
        sg = PIXEL888GREEN(AppColor.deepColor);
        sb = PIXEL888BLUE(AppColor.deepColor);
        sclY = (int16)(rectScroll.y + 1 + (rectScroll.h - 2) * (TopNode->Index - 1) / FileCount);
        sclH = (int16)((rectScroll.h - 2) * VisCount / FileCount);
        mrc_drawRect(rectScroll.x + 1, sclY, rectScroll.w - 1, sclH, sr, sg, sb);
        mrc_drawLine(rectScroll.x + 2, sclY - 1, rectScroll.x + rectScroll.w - 2, sclY - 1, sr, sg, sb);
        mrc_drawLine(rectScroll.x + 2, sclY + sclH, rectScroll.x + rectScroll.w - 2, sclY + sclH, sr, sg, sb);
    }

    if (Refresh > 0)
        RefreshRect(rectSpace);
}

//����ȫ��
void FV_Draw(uint8 Refresh)
{
    DrawTitle(FVTitle, Refresh);
    DrawTool(0, 0, Refresh);
    FV_DrawList(Refresh);
}

//��ʾ�ѱ����ļ���
void FV_ShowCount(int32 fCount)
{
    char fInfo[64] = {0};
    
    DrawFillRect(rectInfo, AppColor.lightColor);
    DrawRoundRect(rectInfo);
    DrawTextMidLeftA(rectInfo, "������������", AppColor.textdColor);
    mrc_sprintf(fInfo, ">%d", fCount);
    DrawTextMidRightA(rectInfo, fInfo, AppColor.textdColor);
    mrc_refreshScreen(rectInfo.x, rectInfo.y, rectInfo.w, rectInfo.h);
}

/***************************************************************************************************/
//����������ı��б�
//������������
void FV_Pos2Node(int32 Y, uint8 IsUp)
{
    int16 lIndex;
    PFILENODE fNode = NULL;
    static IsFirstPress = 1; //�Ƿ��һ�ε���������ڵ�һ�ξͽ���

    if (NULL == TopNode)
        return;

    lIndex = (int16)(Y - rectList.y) / ItemHeight + TopNode->Index;

    //��λ������
    fNode = FirstNode;
    while(fNode && fNode->Index != lIndex)
    {
        fNode = fNode->Next;
    }

    if (NULL != fNode)
    {
        if (FocusNode == fNode && 1 == IsUp) //�ٴ�ѡ��
        {
            if (0 == IsFirstPress)
                FV_DoListEvent(4);
            else
                IsFirstPress = 0;
        }
        else if (FocusNode != fNode)
        {
            IsFirstPress = 1;
            FocusNode = fNode; //ѡ��
            FV_DrawList(1);
        }
    }
}

//�ı������
//�������������꣬������0 - ���£�1 - ̧��
void FV_ChangeScroll(int32 NewY, uint8 KeyCode)
{
    int16 ScrollM;

    IsScrolling = 1 - KeyCode;
    ScrollM = rectScroll.y + 1 + (rectScroll.h - 2) / 2;

    if (0 == KeyCode)
    {
        if (NewY > ScrollM)
        {
            FV_Event(MR_KEY_PRESS, MR_KEY_DOWN, 0);
        }
        else
        {
            FV_Event(MR_KEY_PRESS, MR_KEY_UP, 0);
        }
    }
    else
    {
        if (NewY > ScrollM)
        {
            FV_Event(MR_KEY_RELEASE, MR_KEY_DOWN, 0);
        }
        else
        {
            FV_Event(MR_KEY_RELEASE, MR_KEY_UP, 0);
        }
    }
}

//�������ȡ���ļ��ڵ�
//���������
//���أ��ڵ�
PFILENODE FV_Index2Node(int16 Index)
{
    PFILENODE fNode = NULL;

    fNode = FirstNode;
    while(fNode && fNode->Index != Index)
    {
        fNode = fNode->Next;
    }

    if (NULL == fNode)
        fNode = FirstNode;

    return fNode;
}

//��������ȡ���ļ��ڵ�
//����������
//���أ��ڵ�
PFILENODE FV_Name2Node(char *toName)
{
    PFILENODE fNode = FirstNode;

    while (NULL != fNode && 0 != stricmp((uint8*)fNode->Name, (uint8*)toName))
    {
        fNode = fNode->Next;
    }

    if (NULL == fNode)
        fNode = FirstNode;

    return fNode;
}

//���¸ı��б���
//�������ı�����
void FV_ListUpDown(int16 ChangeNum)
{
    PFILENODE fNode = NULL;
    int16 NewIndex = 0;

    if (NULL == TopNode || NULL == FocusNode || 0 == ChangeNum)
        return;

    //��λ����
    NewIndex = TopNode->Index + ChangeNum;

    if (ChangeNum < 0) //���Ϲ���
    {
        if (NewIndex < 1)
            NewIndex = 1;
    }
    else if (ChangeNum > 0) //���¹���
    {
        if (NewIndex + VisCount > FileCount) //������Χ
        {
            if (FileCount > VisCount)
                NewIndex = (int16)(FileCount - VisCount + 1);
            else
                NewIndex = 1;
        }
    }

    fNode = FirstNode;
    while(fNode && fNode->Index != NewIndex)
    {
        fNode = fNode->Next;
    }
    TopNode = fNode;

    //��λ������
    NewIndex = FocusNode->Index;

    if (FocusNode->Index < TopNode->Index)
        NewIndex = TopNode->Index;

    if (FocusNode->Index > TopNode->Index + VisCount - 1)
        NewIndex = TopNode->Index + (int16)VisCount - 1;

    fNode = FirstNode;
    while(fNode && fNode->Index != NewIndex)
    {
        fNode = fNode->Next;
    }
    FocusNode = fNode;

    FV_DrawList(1);
}

/*-------------------------------------------------------------------------------------------------*/

//�������̽ڵ�
void FV_MakeDiskNode(void)
{
    PFILENODE fNode;
    char *dText = NULL;
    int32 dtLen = 0;

    FV_ClearNodes();

    fNode = (PFILENODE)mrc_malloc(sizeof(FILENODE));
    FirstNode = fNode;
    fNode->Index = 1;
    fNode->Type = MR_IS_DISK;
    fNode->Size = -1;
    dText = "A:\\��ϵͳ�̣�";
    dtLen = mrc_strlen(dText) + 1;
    fNode->Name = (char*)mrc_malloc(dtLen);
    mrc_memcpy(fNode->Name, dText, dtLen);
    fNode->Before = NULL;
    fNode->Next = (PFILENODE)mrc_malloc(sizeof(FILENODE));
    fNode->Next->Before = fNode;
    fNode = fNode->Next;
    fNode->Index = 2;
    fNode->Type = MR_IS_DISK;
    fNode->Size = -1;
    dText = "B:\\���ֻ��̣�";
    dtLen = mrc_strlen(dText) + 1;
    fNode->Name = (char*)mrc_malloc(dtLen);
    mrc_memcpy(fNode->Name, dText, dtLen);
    fNode->Next = (PFILENODE)mrc_malloc(sizeof(FILENODE));
    fNode->Next->Before = fNode;
    fNode = fNode->Next;
    fNode->Index = 3;
    fNode->Type = MR_IS_DISK;
    fNode->Size = -1;
    dText = "C:\\���ڴ濨��";
    dtLen = mrc_strlen(dText) + 1;
    fNode->Name = (char*)mrc_malloc(dtLen);
    mrc_memcpy(fNode->Name, dText, dtLen);
    fNode->Next = NULL;
    FileCount = 3;

    if (GetDiskSize("D:\\", 0) > 0) //�������D��
    {
        fNode->Next = (PFILENODE)mrc_malloc(sizeof(FILENODE));
        fNode->Next->Before = fNode;
        fNode = fNode->Next;
        fNode->Index = 4;
        fNode->Type = MR_IS_DISK;
        fNode->Size = -1;
        dText = "D:\\��������";
        dtLen = mrc_strlen(dText) + 1;
        fNode->Name = (char*)mrc_malloc(dtLen);
        mrc_memcpy(fNode->Name, dText, dtLen);
        fNode->Next = NULL;
        FileCount++;
    }
}

//���·������
void FV_ClearPathNodes(void)
{
    PFILENODE fNode = NULL, fNode2 = NULL;

    fNode = PathNodes;
    while(fNode)
    {
        mrc_free(fNode->Name);
        fNode2 = fNode->Next;
        mrc_free(fNode);
        fNode = fNode2;
    }

    PathNodes = NULL;
}

// ����·����λ�ļ�
// ������·���������̷���
void FV_Locate(char *path)
{
    char *p;
    PFILENODE node;

    // ����·���ָ���
    p = (char*)mrc_strchr(path, '\\');

    if (NULL != p)
    {
        *p = '\0';

        // ��ʾΪ������"\"
        if (*path == '\0')
        {
            // ֱ������
            FV_Locate(p + 1);
            return;
        }
    }

    // ��λĿ���ļ�
    node = FV_Name2Node(path);
    FocusNode = node;
    if (node->Index + VisCount <= FileCount + 1)
    {
        TopNode = node;
    } 
    else if (FileCount > VisCount)
    {
        TopNode = FV_Index2Node((int16)(FileCount - VisCount + 1));
    }
    else
    {
        TopNode = FirstNode;
    }

    // ƥ�䲢���²�Ŀ¼
    if (0 == stricmp((uint8*)node->Name, (uint8*)path) && NULL != p)
    {
        // ������һ��
        FV_SwitchNode(1);
        FV_Locate(p + 1);
    }
    else
    {
        // �Ѿ������ƥ���
        FV_DrawList(1);
    }
}

//��ʾ�ļ����
//��������������
//      �ļ�·����NULL�����ȫ������
//      ��ʽ��0x1-�ļ���0x2-�ļ��У�0x4-��ֹ�л�������Ŀ¼
//      �ص�����
void FV_Show(char *Title, char *lPath, int32 flag, FV_CB cbFunc)
{
    int32 slen;

    FVCallBack = cbFunc;
    FVFlag = flag;
    if (NULL != Title)
    {
        slen = mrc_wstrlen(Title);
        mrc_memcpy(FVTitle, Title, slen + 2);
    }
    else
    {
        FVTitle[0] = FVTitle[1] = '\0';
    }

    if (NULL == lPath)
    {
        FV_End();
        FV_MakeDiskNode();
        FocusNode = FirstNode;
        TopNode = FirstNode;
        mrc_memset(FullPath, 0, sizeof(FullPath));
    }
    else
    {
        int16 index;
        char *tpath;

        slen = mrc_strlen(lPath);
        tpath = mrc_malloc(slen + 1);
        mrc_memcpy(tpath, lPath, slen + 1);

        index = *tpath - 'A';
        if (index > 32) index -= 32;

        FV_End();
        FV_MakeDiskNode();
        TopNode = FirstNode;
        FocusNode = FV_Index2Node(index + 1);
        mrc_memset(FullPath, 0, sizeof(FullPath));
        FV_SwitchNode(1);
        FV_Locate(tpath + 3);

        mrc_free(tpath);
    }
}

//ͨ��ȫ·���ڵ㶨λ�ļ����ļ���
//������������1 - �¼��ļ��У�2 - �ϼ��ļ���
void FV_SwitchNode(uint8 Action)
{
    PFILENODE fNode = NULL;
    int16 tIndex = 1, cIndex = 1; //����ʾ�ڵ���ţ���ǰ�ڵ����
    int32 sLen;

    if (1 == Action)
    {
        sLen = mrc_strlen(FocusNode->Name) + 1;

        if (NULL == PathNodes) //���Ӵ��̽ڵ�
        {
            fNode = PathNodes = (PFILENODE)mrc_malloc(sizeof(FILENODE));
            fNode->Before = NULL;
            fNode->Next = NULL;
            fNode->Type = MR_IS_DISK;
        }
        else
        {
            fNode = PathNodes;
            while(fNode->Next)
            {
                fNode = fNode->Next;
            }
            fNode->Next = (PFILENODE)mrc_malloc(sizeof(FILENODE));
            fNode->Next->Before = fNode;
            fNode = fNode->Next;
            fNode->Next = NULL;
            fNode->Type = FocusNode->Type;
        }

        fNode->Index = FocusNode->Index;
        fNode->Size = TopNode->Index;
        fNode->Name = (char*)mrc_malloc(sLen);
        mrc_memcpy(fNode->Name, FocusNode->Name, sLen);

        tIndex = 1;
        cIndex = 1;
    }
    else if (2 == Action)
    {
        if (NULL == PathNodes) //��·��
        {
            return;
        }
        else if (NULL == PathNodes->Next) //��Ŀ¼
        {
            mrc_memset(FullPath, 0, sizeof(FullPath));
            FV_MakeDiskNode(); //�������̽ڵ�

            mrc_free(PathNodes->Name);
            tIndex = (int16)PathNodes->Size;
            cIndex = PathNodes->Index;
            mrc_free(PathNodes);
            PathNodes = NULL;

            FocusNode = FV_Index2Node(cIndex); //��λ������
            TopNode = FV_Index2Node(tIndex); //��λ��ʾ����
            FV_DrawList(1);
            return;
        }
        else //����
        {
            fNode = PathNodes;
            while(fNode->Next)
            {
                fNode = fNode->Next;
            }
            mrc_free(fNode->Name);
            fNode->Before->Next = NULL;
            tIndex = (int16)fNode->Size;
            cIndex = fNode->Index;
            mrc_free(fNode);
        }
    }

    mrc_memset(FullPath, 0, sizeof(FullPath));
    fNode = PathNodes;

    while(fNode)
    {
        switch(fNode->Type)
        {
        case MR_IS_DISK: //����
            mrc_strncat(FullPath, fNode->Name, 3); //�����ļ���·��
            break;
        case MR_IS_DIR: //�ļ���
            mrc_strcat(FullPath, fNode->Name); //�����ļ���·��
            mrc_strcat(FullPath, "\\");
            break;
        case MR_IS_FILE: //�ļ�
            break;
        default:
            FileCount = 0;
            return;
            break;
        }

        fNode = fNode->Next;
    }

    //Switch2Dir(FullPath); //�л�Ŀ¼
    FileCount = FV_FindFiles(); //�����ļ�
    FocusNode = FV_Index2Node(cIndex); //��λ������
    TopNode = FV_Index2Node(tIndex); //��λ��ʾ����
    FV_DrawList(1);
}

/*-------------------------------------------------------------------------------------------------*/
//���ҵ�ǰ�ļ����ļ�����������������
//���أ��ļ�����
int32 FV_FindFiles(void)
{
    int16 i;
    int32 findHwnd, fCount = 0, nLen = 0;
    const int32 bufSize = 256;
    char *fBuffer = NULL;
    PFILENODE fNode = NULL, lNode = NULL;

    FV_ClearNodes();

    //�����սڵ㣬��������
    fNode = (PFILENODE)mrc_malloc(sizeof(FILENODE));
    FirstNode = fNode;
    fNode->Type = MR_IS_DIR;
    fNode->Size = -2;
    fNode->Name = "";
    fNode->Before = NULL;
    fNode->Next = (PFILENODE)mrc_malloc(sizeof(FILENODE));
    fNode->Next->Before = fNode;
    fNode = fNode->Next;
    fNode->Type = MR_IS_FILE;
    fNode->Size = -2;
    fNode->Name = "";
    fNode->Next = (PFILENODE)mrc_malloc(sizeof(FILENODE));
    fNode->Next->Before = fNode;
    fNode = fNode->Next;
    fNode->Type = MR_IS_INVALID;
    fNode->Size = -2;
    fNode->Name = "";
    fNode->Next = (PFILENODE)mrc_malloc(sizeof(FILENODE));
    fNode->Next->Before = fNode;
    fNode = fNode->Next;
    fNode->Type = MR_IS_DISK;
    fNode->Size = -2;
    fNode->Name = "";
    fNode->Next = NULL;

    fBuffer = (char*)mrc_malloc(bufSize);
    mrc_memset(fBuffer, 0, bufSize);

    Switch2Dir(FullPath);

    //���ҵ�һ��
    findHwnd = mrc_findStart("", fBuffer, bufSize);

    if (findHwnd > 0) //�ǿ��ļ���
    {
        while(1) //���������ļ��к��ļ�
        {
            if (fBuffer[0] && fBuffer[0] != '.') //�ļ�����Ч
            {
                if (0 == fCount % 10 && fCount > 0)
                    FV_ShowCount(fCount);

                fCount++;

                nLen = mrc_strlen(fBuffer) + 1;

                //ȡ����Ϣ
                fNode = (PFILENODE)mrc_malloc(sizeof(FILENODE));
                fNode->Name = (char*)mrc_malloc(nLen);
                mrc_memcpy(fNode->Name, fBuffer, nLen);
                fNode->Type = (uint8)mrc_fileState(fBuffer);
                fNode->Size = -1;

                //����ͬ���Ϳ�ʼλ��
                lNode = FirstNode;
                while(lNode->Type != fNode->Type)
                {
                    lNode = lNode->Next;
                }

                //����������
                while (NULL != lNode) 
                {
                    if (NULL != lNode->Next && lNode->Next->Type == lNode->Type)
                    {
                        if (stricmp((uint8*)lNode->Next->Name, (uint8*)fNode->Name) < 0)
                        {
                            lNode = lNode->Next;
                            continue;
                        }
                    }

                    break;
                }

                //����
                lNode->Next->Before = fNode;
                fNode->Next = lNode->Next;
                lNode->Next = fNode;
                fNode->Before = lNode;
            }

            //������һ��
            mrc_memset(fBuffer, 0, bufSize);

            if (MR_SUCCESS != mrc_findGetNext(findHwnd, fBuffer, bufSize)) //��������
            {
                break;
            }
        }

        //��������
        mrc_findStop(findHwnd);
    }

    Switch2Dir(NULL);

    mrc_free(fBuffer);

    fNode = FirstNode;
    FirstNode = NULL;
    i = 1;

    while (NULL != fNode)
    {
        if (-2 != fNode->Size) //�������
        {
            if (1 == i)
                FirstNode = fNode;
            fNode->Index = i;
            i++;
        }
        else //ɾ���սڵ�
        {
            if (fNode->Before)
                fNode->Before->Next = fNode->Next;
            if (fNode->Next)
                fNode->Next->Before = fNode->Before;
            mrc_free(fNode);
        }
        fNode = fNode->Next;
    }

    return fCount;
}

//����ļ�����
void FV_ClearNodes(void)
{
    PFILENODE fNode = NULL, fNode2 = NULL;

    fNode = FirstNode;

    while (NULL != fNode)
    {
        if (fNode->Name)
        {
            mrc_free(fNode->Name);
            fNode->Name = NULL;
        }
        fNode2 = fNode->Next;
        mrc_free(fNode);
        fNode = fNode2;
    }

    FirstNode = NULL;
    FocusNode = NULL;
    TopNode = NULL;
}

/*---------------------------------------------------------------------------------------------------*/
//�����ļ��б�����
//��������������
void FV_DoListEvent(uint8 KeyCode)
{
    switch (KeyCode)
    {
    case 0: //��
        if (FileCount <= 0) return;

        if (FocusNode->Index == 1) //����ͷ
        {
            if (1 == IsScrolling) //�������ڶ�
            {
                KeyTimerStop();
                IsScrolling = 0;
                break;
            }

            while(FocusNode->Next) //���������
            {
                FocusNode = FocusNode->Next;
            }

            if (FocusNode->Index > VisCount) //�ж�ҳ
            {
                TopNode = FocusNode;

                while(FocusNode->Index - TopNode->Index != VisCount - 1) //��������ʾ��
                {
                    TopNode = TopNode->Before;
                }
            }
            else //ֻ��һҳ
            {
                TopNode = FirstNode;
            }

            FV_DrawList(1);
            break;
        }

        FocusNode = FocusNode->Before;

        if (FocusNode->Index - TopNode->Index == -1) //��Ҫ����
        {
            TopNode = TopNode->Before;
        }

        FV_DrawList(1);

        break;
    case 1: //��
        if (FileCount <= 0) return;

        if (FocusNode->Index == FileCount) //��ĩβ
        {
            if (1 == IsScrolling) //�������ڶ�
            {
                KeyTimerStop();
                IsScrolling = 0;
                break;
            }

            FocusNode = FirstNode;
            TopNode = FirstNode;
            FV_DrawList(1);
            break;
        }

        FocusNode = FocusNode->Next;

        if (FocusNode->Index - TopNode->Index >= VisCount) //��Ҫ����
        {
            TopNode = TopNode->Next;
        }

        FV_DrawList(1);

        break;
    case 2: //�ϼ�Ŀ¼/��
        if ((FVFlag & 0x4) > 0)
            break;

        FV_SwitchNode(2);
        break;
    case 3: //�¼�Ŀ¼/��
        if (FileCount <= 0)
            return;
        if ((FVFlag & 0x4) > 0)
            break;

        switch(FocusNode->Type)
        {
        case MR_IS_DISK:
            FV_SwitchNode(1);
            break;
        case MR_IS_DIR:
            FV_SwitchNode(1);
            break;
        case MR_IS_FILE:
            break;
        default:
            break;
        }
        break;
    case 4: //ѡ���ļ����¼�Ŀ¼/OK
        if (FileCount <= 0) 
            return;

        switch(FocusNode->Type)
        {
        case MR_IS_DISK:
            if ((FVFlag & 0x4) > 0)
                break;

            if ((FVFlag & 0x2) > 0)
            {
                //mrc_strncat(FullPath, CurNode->Name, 3);
                //Switch2Dir("Z");
                (*FVCallBack)(FullPath, FocusNode->Name);
                ChangeAppState(APPSTATE_NORMAL, 1);
            }
            else
            {
                FV_SwitchNode(1);
            }
            break;
        case MR_IS_DIR:
            if ((FVFlag & 0x4) > 0)
                break;

            if ((FVFlag & 0x2) > 0)
            {
                //mrc_strcat(FullPath, CurNode->Name);
                //Switch2Dir("Z");
                (*FVCallBack)(FullPath, FocusNode->Name);
                ChangeAppState(APPSTATE_NORMAL, 1);
            }
            else
            {
                FV_SwitchNode(1);
            }
            break;
        case MR_IS_FILE:
            if ((FVFlag & 0x1) > 0)
            {
                // �л���ԭʼĿ¼
                //Switch2Dir("Z");
                (*FVCallBack)(FullPath, FocusNode->Name);
                ChangeAppState(APPSTATE_NORMAL, 1);
            }
            break;
        default:
            break;
        }
        break;
    }
}

//���������ص�
static void FVKeyTimerDo(int32 data)
{
    FV_DoListEvent((uint8)data);
}

//����Ŀ¼�ص�
static void FVInputPathCb(char *path)
{
    char *gbStr;

    gbStr = mrc_malloc(256);
    UniToGB(path, gbStr, 256);
    FV_Show(FVTitle, gbStr, FVFlag, FVCallBack);
    mrc_free(gbStr);
}

//����Ŀ¼
static void FVInputPath(void)
{
    char *uniStr;

    uniStr = mrc_malloc(512);
    GBToUni(FullPath, uniStr, 512);
    ShowInput("\x8f\x93\x51\x65\x8d\xef\x5f\x84\x0\x0", uniStr, MR_EDIT_ANY, 255, FVInputPathCb);
    mrc_free(uniStr);
}

/*---------------------------------------------------------------------------------------------------*/
//�ļ�����¼�����
int32 FV_Event(int32 code, int32 p0, int32 p1)
{
    switch(code)
    {
    case MR_KEY_PRESS://ѡ���б���
        switch(p0)
        {
        case MR_KEY_UP: //��
            KeyTimerStart(0, FVKeyTimerDo);
            break;
        case MR_KEY_DOWN: //��
            KeyTimerStart(1, FVKeyTimerDo);
            break;
        case MR_KEY_SOFTLEFT:
            DrawTool(0, 1, 1);
            break;
        case MR_KEY_SOFTRIGHT:
            DrawTool(0, 2, 1);
            break;
        }
        break;
    case MR_KEY_RELEASE:
        switch(p0)
        {
        case MR_KEY_UP: //��
            KeyTimerStop();
            break;
        case MR_KEY_DOWN: //��
            KeyTimerStop();
            break;
        case MR_KEY_LEFT: //��
            FV_DoListEvent(2);
            break;
        case MR_KEY_RIGHT: //��
            FV_DoListEvent(3);
            break;
        case MR_KEY_SOFTLEFT:
            DrawTool(0, 0, 1);
        case MR_KEY_SELECT: //OK
            FV_DoListEvent(4);
            break;
        case MR_KEY_SOFTRIGHT: //ȡ�����
            //EndShowOpen();
            //Switch2Dir("Z");
            ChangeAppState(APPSTATE_NORMAL, 1);
            break;
        case MR_KEY_STAR: //�л�Ƥ��
            ChangeAppColor();
            break;
        case MR_KEY_POUND: //ת�����
            if (InputIndex > 0 && InputIndex <= FileCount)
            {
                TopNode = FV_Index2Node((FileCount > VisCount + InputIndex) ? InputIndex : (int16)(FileCount - VisCount + 1));
                FocusNode = FV_Index2Node(InputIndex);
                FV_DrawList(1);
                InputIndex = 0;
            }
            break;
        default:
            if (p0 >= MR_KEY_0 && p0 <= MR_KEY_9) //�����������
            {
                InputIndex = InputIndex * 10 + (int16)p0;
                if (InputIndex > FileCount)
                    InputIndex = 0;
            }
            break;
        }
        break;
    case MR_MOUSE_UP: //����̧��
        {
            if (1 == IsScrolling) //������
            {
                FV_ChangeScroll(p1, 1);
            }
            else if (MousePos.X - p0 > (int32)rectList.w / 3) //���󻬶�
            {
                FV_DoListEvent(2);
            }
            else if (p0 - MousePos.X > (int32)rectList.w / 3) //���һ���
            {
                FV_DoListEvent(3);
            }
            else if (MousePos.Y - (int16)p1 > ItemHeight) //���ϻ���
            {
                FV_ListUpDown((MousePos.Y - (int16)p1) / ItemHeight);
            }
            else if ((int16)p1 - MousePos.Y > ItemHeight) //���»���
            {
                FV_ListUpDown((MousePos.Y - (int16)p1) / ItemHeight);
            }
            else if (p1 >= rectInput.y && p1 < rectInput.y + rectInput.h) //·�������
            {
                FVInputPath();
            }
            else if (p0 < rectList.x + rectList.w - 4) //�б�
            {
                FV_Pos2Node(p1, 1);
            }
        }
        break;
    case MR_MOUSE_DOWN: //��������
        {
            MousePos.X = (int16)p0;
            MousePos.Y = (int16)p1;

            if (p0 > rectScroll.x - 4 && p0 < rectScroll.x + rectScroll.w) //������
            {
                FV_ChangeScroll(p1, 0);
            }
            else if (p0 < rectList.x + rectList.w - 4) //�б�
            {
                FV_Pos2Node(p1, 0);
            }
        }
        break;
    case MR_MOUSE_MOVE:
        break;
    }

    return 0;
}
