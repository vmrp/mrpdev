/*
* ����˵��ص�����
*/

#include <mrc_base.h>

#include "MenuFunc.h"
#include "AppMain.h"
#include "Functions.h"
#include "FileView.h"
#include "LocalUI.h"
#include "Draw.h"
#include "Menu.h"
#include "BackRun.h"
#include "FileCmp.h"
#include "NumConv.h"

//extern void mrc_connectWAP(char* wap);

typedef void (*Redo_Cb)(void); // �ظ��ϴβ����ص�
static Redo_Cb RedoFunc = NULL;

static uint8 LastInput[512]; // �ϴ���������
static uint8 ToFind[512], ToReplace[512]; // ����/�滻����
static int32 ToFindSize, ToReplaceSize; // ����/�滻��С
static uint8 CompareMode; // �Ƚ�ģʽ

static char TempPath[MAX_PATH_LEN_A]; // ��ʱ·��
static char TempName[MAX_FILENAME_LEN_A]; // ��ʱ�ļ���
static int32 TempValue; // ��ʱ����

// �ص�
void GotoOffsetCb(char *NuwStr);
void FileCopyCb(char *dir, char *name);
void CreateFileCb2(char *fName);
void CreateFileCb(char *dNumStr);
void FileRenameCb(char *fName);

void AddDataCb(char *dNumStr);
void DelDataCb(char *dNumStr);
void Data2FileCb(char *dNumStr);
void Data2FileCb2(char *fName);

void SetUserDirCb(char *path);

void BackRunDelayCb(char *dNumStr);
void BackRunFlileCb(char *timeStr);

/*-------------------------------------------------------------------------------------------------*/
//��������ĳ������
void M_SetFont_S(void)
{
    SetAppFont(MR_FONT_SMALL);
}
void M_SetFont_M(void)
{
    SetAppFont(MR_FONT_MEDIUM);
}
void M_SetFont_B(void)
{
    SetAppFont(MR_FONT_BIG);
}

//������Ϣĳ����Ϣ-��ֵ
void M_SetInfo_uint8(void)
{
    SetShowInfo(0x0001);
}
void M_SetInfo_int8(void)
{
    SetShowInfo(0x0002);
}
void M_SetInfo_uint16(void)
{
    SetShowInfo(0x0004);
}
void M_SetInfo_int16(void)
{
    SetShowInfo(0x0008);
}
void M_SetInfo_uint32(void)
{
    SetShowInfo(0x0010);
}
void M_SetInfo_int32(void)
{
    SetShowInfo(0x0020);
}

//������Ϣĳ����Ϣ-�ı�
void M_SetInfo_UCS2BE(void)
{
    SetShowInfo(0x0040);
}
void M_SetInfo_UCS2LE(void)
{
    SetShowInfo(0x0080);
}
void M_SetInfo_GB2312(void)
{
    SetShowInfo(0x0100);
}
void M_SetInfo_UTF8(void)
{
    SetShowInfo(0x0200);
}

//��ɫ
void M_SetColor_Blue(void)
{
    InitColor(0);
    SetMenuChecked(4, 4, 1, 1);
    SetMenuChecked(4, 4, 2, 0);
    DrawMainForm(1);
}
void M_SetColor_Black(void)
{
    InitColor(1);
    SetMenuChecked(4, 4, 1, 0);
    SetMenuChecked(4, 4, 2, 1);
    DrawMainForm(1);
}

// �����ֽ���
void M_SetEndian(void)
{
    if (AppDatas.BigEndian == 0)
    {
        AppDatas.BigEndian = 1;
        SetMenuChecked(4, 5, 1, 1);
    }
    else
    {
        AppDatas.BigEndian = 0;
        SetMenuChecked(4, 5, 1, 0);
    }

    DrawMainForm(1);
}

// ���ÿ�ݼ��Ƿ񵯳��˵�
void M_SetPopMenu(void)
{
    if (AppDatas.PopMenu == 0)
    {
        AppDatas.PopMenu = 1;
        SetMenuChecked(4, 5, 2, 1);
    }
    else
    {
        AppDatas.PopMenu = 0;
        SetMenuChecked(4, 5, 2, 0);
    }

    DrawMainForm(1);
}

/*----------------------------------------------------------------------------------*/

//�ļ����
void M_FileView(void)
{
    MenuFoldAll();
    FV_Show("\x65\x87\x4e\xf6\x6d\x4f\x89\xc8\x0\x0", NULL, 0x1, OpenFile);
    ChangeAppState(APPSTATE_FILEVIEW, 1);
}

//����Ŀ¼���
void M_FVUserDir(void)
{
    MenuFoldAll();
    FV_Show("\x65\x87\x4e\xf6\x6d\x4f\x89\xc8\x0\x0", AppDatas.UserDir, 0x1, OpenFile);
    ChangeAppState(APPSTATE_FILEVIEW, 1);
}

//���¶�λ���ϴ��ļ�
void M_FVRecent(void)
{
    //mrc_sprintf(TempPath, "%s%s", AppDatas.HDatas[AppDatas.HIndex].FilePath, AppDatas.HDatas[AppDatas.HIndex].FileNameA);
    FV_Show("\x65\x87\x4e\xf6\x6d\x4f\x89\xc8\x0\x0", AppDatas.Recent, 0x1, OpenFile);
    ChangeAppState(APPSTATE_FILEVIEW, 1);
}

//����ļ���
/*void M_DirView(void)
{
    FV_Show("\x6d\x4f\x89\xc8\x65\x87\x4e\xf6\x59\x39\x0\x0", NULL, 0x2, OpenFile);
    ChangeAppState(APPSTATE_FILEVIEW, 1);
}*/

//�ر��ļ�
void M_FileClose(void)
{
    OpenFile(NULL, NULL);
    ChangeAppState(APPSTATE_NORMAL, 1);
}

//�½��ļ�
void M_CreateFile(void)
{
    ShowInput("\x65\x87\x4e\xf6\x59\x27\x5c\xf\x0\x0", "\x0\x31\x0\x0", MR_EDIT_NUMERIC, 10, CreateFileCb); //�ļ���С
}

//�����ļ�
void M_FileCopy(void)
{
    FV_Show("\x76\xee\x68\x7\x65\x87\x4e\xf6\x59\x39\x0\x0", NULL, 0x2, FileCopyCb);
    ChangeAppState(APPSTATE_FILEVIEW, 1);
}

//������
void M_FileRename(void)
{
    ShowInput("\x65\xb0\x65\x87\x4e\xf6\x54\xd\x0\x0", AppDatas.HDatas[AppDatas.HIndex].FileNameW, MR_EDIT_ANY, 64, FileRenameCb); //���ļ���
}

//ɾ��
void M_FileDel(void)
{
    Switch2Dir(AppDatas.HDatas[AppDatas.HIndex].FilePath);

    if (MR_IS_FILE == mrc_fileState(AppDatas.HDatas[AppDatas.HIndex].FileNameA)) //�ļ�
        mrc_remove(AppDatas.HDatas[AppDatas.HIndex].FileNameA);
    else if (MR_IS_DIR == mrc_fileState(AppDatas.HDatas[AppDatas.HIndex].FileNameA)) //�ļ���
        mrc_rmDir(AppDatas.HDatas[AppDatas.HIndex].FileNameA);

    Switch2Dir(NULL);

    OpenFile(NULL, NULL);
    ShowMsg("\x65\x87\x4e\xf6\x52\x20\x96\x64\x5b\x8c\x62\x10\xff\x1\x0\x0", 1); //�ļ�ɾ����ɣ�
}

//ת��
void M_GotoOffset(void)
{
    char *pNum = witoa(GetCurFileOffset());
    char *pMax = witoa(GetFileSize());

    ShowInput("\x8f\x6c\x52\x30\x50\x4f\x79\xfb\x0\x0", pNum, MR_EDIT_NUMERIC, mrc_wstrlen(pMax), GotoOffsetCb); //ת��ƫ��
    mrc_free(pNum);
    mrc_free(pMax);
}

/*----------------------------------------------------------------------------------*/
//������ֵ
void M_FindNum(void)
{
    ShowInput("\x67\xe5\x62\x7e\x65\x70\x50\x3c\x0\x0", (char*)LastInput, MR_EDIT_NUMERIC, 12, FindNum); //������ֵ
}
//����Hex
void M_FindHex(void)
{
    ShowInput("\x67\xe5\x62\x7e\x0\x31\x0\x36\x8f\xdb\x52\x36\x0\x0", (char*)LastInput, MR_EDIT_ANY, 128, FindHex); //����16����
}
//�����ı�
void M_FindTextW(void)
{
    ShowInput("\x67\xe5\x62\x7e\x65\x87\x67\x2c\x0\x0", (char*)LastInput, MR_EDIT_ANY, 128, FindText_UB); //�����ı�
}
void M_FindTextWL(void)
{
    ShowInput("\x67\xe5\x62\x7e\x65\x87\x67\x2c\x0\x0", (char*)LastInput, MR_EDIT_ANY, 128, FindText_UL); //�����ı�
}
void M_FindTextA(void)
{
    ShowInput("\x67\xe5\x62\x7e\x65\x87\x67\x2c\x0\x0", (char*)LastInput, MR_EDIT_ANY, 128, FindText_GB); //�����ı�
}
void M_FindTextUTF8(void)
{
    ShowInput("\x67\xe5\x62\x7e\x65\x87\x67\x2c\x0\x0", (char*)LastInput, MR_EDIT_ANY, 128, FindText_UTF8); //�����ı�
}

//������һ��
void M_FindNext(void)
{
    int32 findPos;

    if (ToFindSize <= 0)
    {
        //��������������ݣ�
        ShowMsg("\x8b\xf7\x51\x48\x8f\x93\x51\x65\x67\xe5\x62\x7e\x51\x85\x5b\xb9\xff\x1\x0\x0", 1);
        return;
    }

    //���ڲ��ң���ȴ�����
    ShowMsg("\x6b\x63\x57\x28\x67\xe5\x62\x7e\xff\xc\x8b\xf7\x7b\x49\x5f\x85\x20\x26\x20\x26\x0\x0", 1);
    findPos = FindFromFile(AppDatas.HDatas[AppDatas.HIndex].FilePath, AppDatas.HDatas[AppDatas.HIndex].FileNameA,
        GetCurFileOffset() + 1, ToFind, ToFindSize);
    RedoFunc = M_FindNext;

    if (findPos > 0)
    {
        GotoFilePos(findPos);
        ChangeAppState(APPSTATE_NORMAL, 1);
    }
    else
    {   //��������δ�ҵ���
        ShowMsg("\x67\xe5\x62\x7e\x65\x70\x63\x6e\x67\x2a\x62\x7e\x52\x30\xff\x1\x0\x0", 1);
    }
}

/*----------------------------------------------------------------------------------*/
//�滻��ֵ
void M_ReplaceNum(void)
{
    ShowInput("\x66\xff\x63\x62\x65\x70\x50\x3c\x0\x0", (char*)LastInput, MR_EDIT_NUMERIC, 12, ReplaceNum); //�滻��ֵ
}
//�滻Hex
void M_ReplaceHex(void)
{
    ShowInput("\x66\xff\x63\x62\x0\x31\x0\x36\x8f\xdb\x52\x36\x0\x0", (char*)LastInput, MR_EDIT_ANY, 128, ReplaceHex); //�滻16����
}
//�滻�ı�
void M_ReplaceTextW(void)
{
    ShowInput("\x66\xff\x63\x62\x65\x87\x67\x2c\x0\x0", (char*)LastInput, MR_EDIT_ANY, 128, ReplaceText_UB); //�滻�ı�
}
void M_ReplaceTextWL(void)
{
    ShowInput("\x66\xff\x63\x62\x65\x87\x67\x2c\x0\x0", (char*)LastInput, MR_EDIT_ANY, 128, ReplaceText_UL); //�滻�ı�
}
void M_ReplaceTextA(void)
{
    ShowInput("\x66\xff\x63\x62\x65\x87\x67\x2c\x0\x0", (char*)LastInput, MR_EDIT_ANY, 128, ReplaceText_GB); //�滻�ı�
}
void M_ReplaceTextUTF8(void)
{
    ShowInput("\x66\xff\x63\x62\x65\x87\x67\x2c\x0\x0", (char*)LastInput, MR_EDIT_ANY, 128, ReplaceText_UTF8); //�滻�ı�
}

//�����滻
void M_FastReplace(void)
{
    if (ToReplaceSize <= 0)
    {
        //���������滻���ݣ�
        ShowMsg("\x8b\xf7\x51\x48\x8f\x93\x51\x65\x66\xff\x63\x62\x51\x85\x5b\xb9\xff\x1\x0\x0", 1);
        return;
    }

    SaveDatas(ToReplace, ToReplaceSize);
    RedoFunc = M_FastReplace;

    //�滻��ɣ�
    ShowMsg("\x66\xff\x63\x62\x5b\x8c\x62\x10\xff\x1\x0\x0", 1);
}

/*----------------------------------------------------------------------------------*/

//�Ƚ���ͬ�ֽ�
void M_CompareSame(void)
{
    CompareMode = 0;
    SetMenuChecked(1, 4, 1, 1);
    SetMenuChecked(1, 4, 2, 0);
    DrawAllMenu(0, 1);
}

//�Ƚϲ�ͬ�ֽ�
void M_CompareDiff(void)
{
    CompareMode = 1;
    SetMenuChecked(1, 4, 1, 0);
    SetMenuChecked(1, 4, 2, 1);
    DrawAllMenu(0, 1);
}

//�Ƚ���һ��
void M_CompareNext(void)
{
    int32 cmpPos;
    PHEX_VIEW_ST data1, data2;

    data1 = &AppDatas.HDatas[AppDatas.HIndex];
    data2 = &AppDatas.HDatas[1 - AppDatas.HIndex];

    if (data2->FileSize <= 0)
    {
        //��������һ���ڴ��ļ���(��Ϊ�ο��ļ�)
        ShowMsg("\x8b\xf7\x51\x48\x57\x28\x53\xe6\x4e\x0\x7a\x97\x53\xe3\x62\x53\x5f\x0\x65\x87\x4e\xf6\xff\x1\x0\x28\x4f\x5c\x4e\x3a\x53\xc2\x80\x3\x65\x87\x4e\xf6\x0\x29\x0\x0", 1);
        return;
    }

    //���ڱȽϣ���ȴ�����
    ShowMsg("\x6b\x63\x57\x28\x6b\xd4\x8f\x83\xff\xc\x8b\xf7\x7b\x49\x5f\x85\x20\x26\x20\x26\x0\x0", 1);
    cmpPos = CompareFile(data2->FilePath, data1->FilePath, data2->FileNameA, data1->FileNameA, GetCurFileOffset() + 1, CompareMode);
    RedoFunc = M_CompareNext;

    if (cmpPos >= 0)
    {
        GotoFilePos(cmpPos);
        ChangeAppState(APPSTATE_NORMAL, 1);
    }
    else
    {   //δ�ҵ��������������ݣ�
        ShowMsg("\x67\x2a\x62\x7e\x52\x30\x7b\x26\x54\x8\x67\x61\x4e\xf6\x76\x84\x65\x70\x63\x6e\xff\x1\x0\x0", 1);
    }
}

/*----------------------------------------------------------------------------------*/
// �ı�ƫ��

void M_PageUp(void) //��һҳ
{
    ChangeAppState(APPSTATE_NORMAL, 1);
    ChangeDataOffset(OFFSET_SEEK_PAGE_UP);
}
void M_PageDown(void) //��һҳ
{
    ChangeAppState(APPSTATE_NORMAL, 1);
    ChangeDataOffset(OFFSET_SEEK_PAGE_DOWN);
}
void M_PageHome(void) //��ͷ
{
    ChangeAppState(APPSTATE_NORMAL, 1);
    ChangeDataOffset(OFFSET_SEEK_BEGIN);
}
void M_PageEnd(void) //ĩβ
{
    ChangeAppState(APPSTATE_NORMAL, 1);
    ChangeDataOffset(OFFSET_SEEK_END);
}

/*----------------------------------------------------------------------------------*/

//�����ֽ�
void M_AddData(void)
{
    ShowInput("\x63\xd2\x51\x65\x5b\x57\x82\x82\x65\x70\x0\x0", "\x0\x30\x0\x0", MR_EDIT_NUMERIC, 12, AddDataCb); //�����ֽ���
}

//ɾ���ֽ�
void M_DelData(void)
{
    ShowInput("\x52\x20\x96\x64\x5b\x57\x82\x82\x65\x70\x0\x0", "\x0\x30\x0\x0", MR_EDIT_NUMERIC, 12, DelDataCb); //ɾ���ֽ���
}

//����Ƭ��
void M_Data2File(void)
{
    ShowInput("\x4f\xdd\x5b\x58\x5b\x57\x82\x82\x65\x70\x0\x0", "\x0\x30\x0\x0", MR_EDIT_NUMERIC, 12, Data2FileCb); //�����ֽ���
}

/*----------------------------------------------------------------------------------*/
// ������ݲ���

void M_ShowMenuFind(void)
{
    if (GetFileSize() > 0)
    {
        if (0 != AppDatas.PopMenu)
            ShowMenuByIndex(1, 1, 0);
        else
            M_FindNext();
    }
}

void M_ShowMenuReplace(void)
{
    if (GetFileSize() > 0)
    {
        if (0 != AppDatas.PopMenu)
            ShowMenuByIndex(1, 2, 0);
        else
            M_FastReplace();
    }
}

void M_ShowMenuCompare(void)
{
    if (GetFileSize() > 0)
    {
        if (0 != AppDatas.PopMenu)
            ShowMenuByIndex(1, 4, 0);
        else
            M_CompareNext();
    }
}

void M_RedoRecent(void)
{
    if (GetFileSize() > 0 && NULL != RedoFunc)
        (*RedoFunc)();
}

/*----------------------------------------------------------------------------------*/

void M_SetUserDir(void)
{
    GBToUni(AppDatas.UserDir, TempPath, MAX_PATH_LEN_A);

    //����·��
    ShowInput("\x8f\x93\x51\x65\x8d\xef\x5f\x84\x0\x0", TempPath, MR_EDIT_ANY, 63, SetUserDirCb); 
}

/*----------------------------------------------------------------------------------*/

//��̨-�ֶ�����
void M_BR_Normal(void)
{
    BackRunDelayCb(NULL);
}

//��̨-��ʱ����
void M_BR_Delay(void)
{
    //��ʱ(��)
    ShowInput("\x5e\xf6\x65\xf6\x0\x28\x79\xd2\x0\x29\x0\x0", "\x0\x36\x0\x30\x0\x0", MR_EDIT_NUMERIC, 4, BackRunDelayCb); 
}

//��̨-�ļ����ӷ���
void M_BR_Flie(void)
{
    //�����ļ���  ��̨����.txt
    ShowInput("\x8f\x93\x51\x65\x65\x87\x4e\xf6\x54\xd\x0\x0", "\x54\xe\x53\xf0\x8f\xd4\x56\xde\x0\x2e\x0\x74\x0\x78\x0\x74\x0\x0", MR_EDIT_ANY, 16, BackRunFlileCb);
}

/*----------------------------------------------------------------------------------*/

//�����Դ������
/*void M_GotoEles(void)
{
    uint8 EncodeUrl[] = "\x2d\x31\x31\x35\x7f\x6a\x6a\x20\x29\x20\x36\x6b\x32\x24\x35\x6b\x24\x2c";

    ChangeAppState(APPSTATE_NORMAL, 0);
    DecodeStr(EncodeUrl, 0x45);
    mrc_connectWAP((char*)EncodeUrl);
}*/

//����
void M_ShowHelp(void)
{
    char *fbuf;
    int32 fsize;
    int32 fd;

    fbuf = mrc_readFileFromMrp("readme.txt", &fsize, 0);
    if (NULL != fbuf)
    {
        fd = OpenInPath("Z", "eles/eHex/����.txt", MR_FILE_CREATE | MR_FILE_WRONLY);
        mrc_write(fd, fbuf, fsize);
        mrc_close(fd);
        mrc_freeFileData(fbuf, fsize);

        // �����ļ��ѱ��棬��鿴"/eles/eHex/����.txt"�ļ���
        ShowMsg("\x5e\x2e\x52\xa9\x65\x87\x4e\xf6\x5d\xf2\x4f\xdd\x5b\x58\xff\xc\x8b\xf7\x67\xe5\x77\xb\x0\x22\x0\x2f\x0\x65\x0\x6c\x0\
\x65\x0\x73\x0\x2f\x0\x65\x0\x48\x0\x65\x0\x78\x0\x2f\x5e\x2e\x52\xa9\x0\x2e\x0\x74\x0\x78\x0\x74\x0\x22\x65\x87\x4e\xf6\x30\x2\x0\x0", 1);
    } 
    else
    {
        // �����ļ���ʧ�����������ر�������
        ShowMsg("\x5e\x2e\x52\xa9\x65\x87\x4e\xf6\x4e\x22\x59\x31\xff\xc\x8b\xf7\x91\xcd\x65\xb0\x4e\xb\x8f\x7d\x67\x2c\x8f\x6f\x4e\xf6\xff\x1\x0\x0", 1);
    }
}

//����
void M_ShowAbout(void)
{
    //eleqian �������
    uint8 EncodeChar[] = "\x47\x22\x47\x2b\x47\x22\x47\x36\x47\x2e\x47\x26\x47\x29\x47\x67\xcc\xf9\xcc\xe6\x15\x71\x8\x1b\x0\x0";

    DecodeStr(EncodeChar, 0x47);
    ShowMsg((char*)EncodeChar, 1);
}

//�˳�
void M_ExitApp(void)
{
    ChangeAppState(APPSTATE_NORMAL, 1);
    mrc_exit();
}

//����ת��
void M_Tool_ConvNum(void)
{
    ChangeAppState(APPSTATE_NUMCONV, 1);
}

//////////////////////////////////////////////////////////////////////////

// ���ļ�����ָ����С��'\0'�ֽ�
int32 AddZeroToFile(int32 fd, int32 size)
{
    const int32 bufsize = 4 * 1024;
    int32 count, ret;
    char *buf = NULL;

    if (fd <= 0 || size <= 0)
        return -1;

    buf = mrc_malloc(bufsize);
    mrc_memset(buf, 0, bufsize);

    for (count = size / bufsize; count > 0; count--)
    {
        mrc_write(fd, buf, bufsize);
    }

    ret = mrc_write(fd, buf, size % bufsize);
    mrc_free(buf);

    return ret < 0 ? ret : size;
}

/************************************************************************/
// �ص�����

//ת���ص�
void GotoOffsetCb(char *NumStr)
{
	int32 outValue = 0;

	if(NULL != NumStr)
	{
        outValue = watoi(NumStr);
        GotoFilePos(outValue);
	}
}

//�����ļ��ص�
void FileCopyCb(char *dir, char *name)
{
    int32 ret;
    PHEX_VIEW_ST data;

    ShowMsg("\x6b\x63\x57\x28\x59\xd\x52\x36\x65\x87\x4e\xf6\x20\x26\x20\x26\x0\x0", 1); //���ڸ����ļ�����

    data = &AppDatas.HDatas[AppDatas.HIndex];
    mrc_sprintf(TempPath, "%s\\%s", dir, name);
    ret = CopyFileFullPath(data->FilePath, TempPath, data->FileNameA, data->FileNameA);

    if (MR_SUCCESS == ret)
        ShowMsg("\x65\x87\x4e\xf6\x59\xd\x52\x36\x5b\x8c\x62\x10\xff\x1\x0\x0", 1); //�ļ�������ɣ�
    else
        ShowMsg("\x65\x87\x4e\xf6\x59\xd\x52\x36\x59\x31\x8d\x25\xff\x1\x0\x0", 1); //�ļ�����ʧ�ܣ�
}

//�½��ļ��ص�-�����С�ص�
void CreateFileCb(char *num_w)
{
    TempValue = watoi(num_w);
    if (TempValue > 0)
        ShowInput("\x65\xb0\x5e\xfa\x65\x87\x4e\xf6\x54\xd\x0\x0", AppDatas.HDatas[AppDatas.HIndex].FileNameW, MR_EDIT_ANY, 64, CreateFileCb2); //�½��ļ���
}

//�½��ļ��ص�-�ļ���
void CreateFileCb2(char *name_w)
{
    char *name_a;
    int32 fd;

    name_a = mrc_malloc(128);
    UniToGB(name_w, name_a, 128);
    fd = mrc_open(name_a, MR_FILE_RDWR | MR_FILE_CREATE);
    mrc_seek(fd, 0, MR_SEEK_END);
    AddZeroToFile(fd, TempValue);
    mrc_close(fd);
    mrc_free(name_a);
    ShowMsg("\x65\xb0\x5e\xfa\x65\x87\x4e\xf6\x5b\x8c\x62\x10\xff\x1\x0\x0", 1); //�½��ļ���ɣ�
}

//�������ļ��ص�
void FileRenameCb(char *name_w)
{
    char *name_a;
    PHEX_VIEW_ST data;

    data = &AppDatas.HDatas[AppDatas.HIndex];
    name_a = mrc_malloc(128);
    UniToGB(name_w, name_a, 128);

    Switch2Dir(data->FilePath);
    mrc_rename(data->FileNameA, name_a);
    Switch2Dir(NULL);

    mrc_memset(data->FileNameA, 0, MAX_FILENAME_LEN_A);
    mrc_memcpy(data->FileNameA, name_a, mrc_strlen(name_a));
    mrc_memset(data->FileNameW, 0, MAX_FILENAME_LEN_A * 2);
    mrc_memcpy(data->FileNameW, name_w, mrc_wstrlen(name_w));

    mrc_free(name_a);
    ShowMsg("\x65\x87\x4e\xf6\x91\xcd\x54\x7d\x54\xd\x5b\x8c\x62\x10\xff\x1\x0\x0", 1); //�ļ���������ɣ�
}

// ���ó���Ŀ¼�ص�
void SetUserDirCb(char *path)
{
    UniToGB(path, AppDatas.UserDir, sizeof(AppDatas.UserDir));

    // ���óɹ���
    ShowMsg("\x8b\xbe\x7f\x6e\x62\x10\x52\x9f\xff\x1\x0\x0", 1);
}

/*----------------------------------------------------------------------------------*/

//�����ֽڻص�
void AddDataCb(char *num_w)
{
    int32 addsize, fd0, fdt;
    int32 fOffset, fSize;
    char *tempFile = "temp.dat";
    PHEX_VIEW_ST data;

    ShowMsg("\x6b\x63\x57\x28\x6d\xfb\x52\xa0\xff\xc\x8b\xf7\x7b\x49\x5f\x85\x20\x26\x20\x26\x0\x0", 1); //�������ӣ���ȴ�����

    data = &AppDatas.HDatas[AppDatas.HIndex];
    fOffset = data->FileReadBegin + data->DataBufferOffset;
    fSize = data->FileSize;
    addsize = watoi(num_w);

    //���ļ�
    fd0 = OpenInPath(data->FilePath, data->FileNameA, MR_FILE_RDWR);
    fdt = mrc_open(tempFile, MR_FILE_CREATE | MR_FILE_RDWR);

    //���ƺ�벿�����ݵ���ʱ�ļ�
    mrc_seek(fdt, 0, MR_SEEK_SET);
    mrc_seek(fd0, fOffset, MR_SEEK_SET);
    CopyFileByHandle(fd0, fdt, fSize - fOffset);

    //д��հ�����
    mrc_seek(fd0, fOffset, MR_SEEK_SET);
    AddZeroToFile(fd0, addsize);

    //����ʱ�ļ�д������
    mrc_seek(fdt, 0, MR_SEEK_SET);
    CopyFileByHandle(fdt, fd0, fSize - fOffset);

    //�ر��ļ�
    mrc_close(fd0);
    mrc_close(fdt);

    //ɾ����ʱ�ļ�
    mrc_remove(tempFile);

    //���´��ļ�
    mrc_memcpy(TempName, data->FileNameA, MAX_FILENAME_LEN_A);
    mrc_memcpy(TempPath, data->FilePath, MAX_PATH_LEN_A);
    OpenFile(TempPath, TempName);
    GotoFilePos(fOffset + addsize);
    
    ShowMsg("\x6d\xfb\x52\xa0\x65\x70\x63\x6e\x5b\x8c\x62\x10\xff\x1\x0\x0", 1); //����������ɣ�
}

//ɾ���ֽڻص�
void DelDataCb(char *dNumStr)
{
    int32 delNum;
    int32 fOffset = GetCurFileOffset();
    int32 fSize = GetFileSize();
    char *tempFile = "temp.dat";
    PHEX_VIEW_ST data;

    data = &AppDatas.HDatas[AppDatas.HIndex];
    delNum = watoi(dNumStr);

    if (fOffset + delNum > fSize)
    {
        //�����ֽ������󣬲������ܾ���
        ShowMsg("\x8f\x93\x51\x65\x5b\x57\x82\x82\x65\x70\x8f\xc7\x59\x27\xff\xc\x64\xcd\x4f\x5c\x88\xab\x62\xd2\x7e\xdd\x30\x2\x0\x0", 1);
        return;
    }

    //�����Ƴ�����ȴ�����
    ShowMsg("\x6b\x63\x57\x28\x79\xfb\x96\x64\xff\xc\x8b\xf7\x7b\x49\x5f\x85\x20\x26\x20\x26\x0\x0", 1);

    Switch2Dir(data->FilePath);

    //����ǰ�벿�����ݵ���ʱ�ļ�
    CopyFileEx(data->FileNameA, tempFile, 0, 0, fOffset);
    //���ƺ�벿�����ݵ���ʱ�ļ�
    CopyFileEx(data->FileNameA, tempFile, fOffset + delNum, fOffset, fSize - fOffset - delNum);

    //�滻ԭ�ļ�
    mrc_remove(data->FileNameA);
    mrc_rename(tempFile, data->FileNameA);

    Switch2Dir(NULL);

    //���´��ļ�
    mrc_memcpy(TempName, data->FileNameA, MAX_FILENAME_LEN_A); //����һ�Σ�����·����ΪNULL
    mrc_memcpy(TempPath, data->FilePath, MAX_PATH_LEN_A);
    OpenFile(TempPath, TempName);
    GotoFilePos(fOffset);

    ShowMsg("\x79\xfb\x96\x64\x65\x70\x63\x6e\x5b\x8c\x62\x10\xff\x1\x0\x0", 1); //�Ƴ�������ɣ�
}

//����Ƭ��-д���ļ��ص�
void Data2FileCb2(char *name_w)
{
    int32 fOffset = GetCurFileOffset();
    int32 fWritePos = 0;
    int32 copySize = TempValue;
    char *name_a = NULL;

    ShowMsg("\x6b\x63\x57\x28\x4f\xdd\x5b\x58\x65\x70\x63\x6e\x72\x47\x6b\xb5\x20\x26\x20\x26\x0\x0", 1); //���ڱ�������Ƭ�Ρ���

    name_a = mrc_malloc(MAX_FILENAME_LEN_A);
    UniToGB(name_w, name_a, MAX_FILENAME_LEN_A);

    Switch2Dir(AppDatas.HDatas[AppDatas.HIndex].FilePath);

    if (MR_IS_FILE == mrc_fileState(name_a))
        fWritePos = mrc_getLen(name_a);

    CopyFileEx(AppDatas.HDatas[AppDatas.HIndex].FileNameA, name_a, fOffset, fWritePos, copySize);

    Switch2Dir(NULL);
    mrc_free(name_a);

    ShowMsg("\x4f\xdd\x5b\x58\x65\x70\x63\x6e\x72\x47\x6b\xb5\x5b\x8c\x62\x10\xff\x1\x0\x0", 1); //��������Ƭ����ɣ�
}

//����Ƭ��-�����С�ص�
void Data2FileCb(char *dNumStr)
{
    TempValue = watoi(dNumStr);

    if (GetCurFileOffset() + TempValue > GetFileSize())
    {
        //�����ֽ������󣬲������ܾ���
        ShowMsg("\x8f\x93\x51\x65\x5b\x57\x82\x82\x65\x70\x8f\xc7\x59\x27\xff\xc\x64\xcd\x4f\x5c\x88\xab\x62\xd2\x7e\xdd\x30\x2\x0\x0", 1);
        return;
    }
    else if (TempValue > 0)
    {
        ShowInput("\x65\x70\x63\x6e\x53\xe6\x5b\x58\x4e\x3a\x0\x0", AppDatas.HDatas[AppDatas.HIndex].FileNameW, MR_EDIT_ANY, 64, Data2FileCb2); //��������Ϊ
    }
}

/*----------------------------------------------------------------------------------*/

//��̨��ʱ����ص�
void BackRunDelayCb(char *dNumStr)
{
    int32 brDelay;

    if (NULL == dNumStr)
        brDelay = 0;
    else
        brDelay = watoi(dNumStr);

    if (MR_SUCCESS  == BRByDelay(brDelay))
        ChangeAppState(APPSTATE_BACKRUN, 0);
    else
        ShowMsg("\x62\x4b\x67\x3a\x4e\xd\x65\x2f\x63\x1\x54\xe\x53\xf0\x8f\xd0\x88\x4c\xff\x1\x0\x0", 1); //�ֻ���֧�ֺ�̨���У�
}

//��̨��ʱ����ص�
void BackRunFlileCb(char *strW)
{
    char strA[34] = {0};

    UniToGB(strW, strA, 34);

    if (MR_SUCCESS  == BRByFile(strA))
        ChangeAppState(APPSTATE_BACKRUN, 0);
    else
        ShowMsg("\x62\x4b\x67\x3a\x4e\xd\x65\x2f\x63\x1\x54\xe\x53\xf0\x8f\xd0\x88\x4c\xff\x1\x0\x0", 1); //�ֻ���֧�ֺ�̨���У�
}

/*----------------------------------------------------------------------------------*/

// ��ֵ���ֽ��򱣴�����鲢�����ֽ���
int32 NumToBytes(uint32 num, uint8 *bytes)
{
    int32 i;

    if (0 == AppDatas.BigEndian)
    {
        *bytes = (uint8)(num & 0xff);
        *(bytes + 1) = (uint8)((num >> 8) & 0xff);
        *(bytes + 2) = (uint8)((num >> 16) & 0xff);
        *(bytes + 3) = (uint8)((num >> 24) & 0xff);

        for (i = 0; i < 4; i++)
        {
            if (*(bytes + i) == 0)
                break;
        }
    } 
    else
    {
        *(bytes + 3) = (uint8)(num & 0xff);
        *(bytes + 2) = (uint8)((num >> 8) & 0xff);
        *(bytes + 1) = (uint8)((num >> 16) & 0xff);
        *bytes = (uint8)((num >> 24) & 0xff);

        for (i = 0; i < 4; i++)
        {
            if (*(bytes + 3 - i) == 0)
                break;
        }
    }

    return i;
}

//������ֵ
void FindNum(char *sNum)
{
    int32 findNum = watoi(sNum);
    uint8 numBytes[4] = {0};

    mrc_memset(LastInput, 0, sizeof(LastInput));
    mrc_memcpy(LastInput, sNum, mrc_wstrlen(sNum));

    /*ToFindSize = NumToBytes((uint32)findNum, numBytes);

    if (ToFindSize < 1) 
        ToFindSize = 1;
    else if (ToFindSize > 4)
        ToFindSize = 4;
    else if (ToFindSize == 3)
        ToFindSize = 4;*/
    NumToBytes((uint32)findNum, numBytes);
    ToFindSize = 4;

    mrc_memset(ToFind, 0, sizeof(ToFind));
    mrc_memcpy(ToFind, numBytes, ToFindSize);

    M_FindNext();
}

//����ʮ������
//����������Hexֵ
void FindHex(char *sHex)
{
    int32 i;
    int32 hLen = mrc_wstrlen(sHex);
    int32 dLen = hLen / 2 + 2;
    uint8 *sHexA, *hData;

    if (hLen <= 0)
        return;

    mrc_memset(LastInput, 0, sizeof(LastInput));
    mrc_memcpy(LastInput, sHex, hLen);

    sHexA = (uint8*)mrc_malloc(dLen);
    hData = (uint8*)mrc_malloc(dLen);

    for(i = 0; i < hLen / 2; i++)
    {
        sHexA[i] = sHex[i * 2 + 1];
    }

    ToFindSize = hLen / 4;
    Hex2Data(sHexA, ToFindSize * 2, hData, dLen);
    mrc_memset(ToFind, 0, sizeof(ToFind));
    mrc_memcpy(ToFind, hData, ToFindSize);
    mrc_free(sHexA);
    mrc_free(hData);

    M_FindNext();
}

//�����ı� Uincode-B
//�����������ı�
void FindText_UB(char *sText)
{
    mrc_memset(LastInput, 0, sizeof(LastInput));
    mrc_memcpy(LastInput, sText, mrc_wstrlen(sText));

    ToFindSize = mrc_wstrlen(sText);
    mrc_memset(ToFind, 0, sizeof(ToFind));
    mrc_memcpy(ToFind, LastInput, ToFindSize);

    M_FindNext();
}

//�����ı� Uincode-L
//�����������ı�
void FindText_UL(char *sText)
{
    mrc_memset(LastInput, 0, sizeof(LastInput));
    mrc_memcpy(LastInput, sText, mrc_wstrlen(sText));

    ToFindSize = mrc_wstrlen(sText);
    mrc_memset(ToFind, 0, sizeof(ToFind));
    mrc_memcpy(ToFind, LastInput, ToFindSize);
    ExchangeBytes(ToFind, 512);

    M_FindNext();
}

//�����ı� GB2312
//�����������ı�
void FindText_GB(char *sText)
{
    mrc_memset(LastInput, 0, sizeof(LastInput));
    mrc_memcpy(LastInput, sText, mrc_wstrlen(sText));

    UniToGB((char*)LastInput, (char*)ToFind, 512);
    ToFindSize = mrc_strlen((char*)ToFind);

    M_FindNext();
}

//�����ı� UTF8
//�����������ı�
void FindText_UTF8(char *sText)
{
    mrc_memset(LastInput, 0, sizeof(LastInput));
    mrc_memcpy(LastInput, sText, mrc_wstrlen(sText));

    ToFindSize = wstr2str(LastInput, (char*)ToFind, 512);

    M_FindNext();
}

/*----------------------------------------------------------------------------------*/

//�滻��ֵ
void ReplaceNum(char *sNum)
{
    int32 newNum = watoi(sNum);
    uint8 numBytes[4] = {0};

    mrc_memset(LastInput, 0, sizeof(LastInput));
    mrc_memcpy(LastInput, sNum, mrc_wstrlen(sNum));

    /*ToReplaceSize = NumToBytes((uint32)newNum, numBytes);
    if (ToReplaceSize < 1)
        ToReplaceSize = 1;
    else if (ToReplaceSize == 3)
        ToReplaceSize = 4;
    else if (ToReplaceSize > 4)
        ToReplaceSize = 4;*/
    NumToBytes((uint32)newNum, numBytes);
    ToReplaceSize = 4;

    mrc_memset(ToReplace, 0, sizeof(ToReplace));
    mrc_memcpy(ToReplace, numBytes, ToReplaceSize);

    M_FastReplace();
}

//�滻ʮ������
void ReplaceHex(char *sHex)
{
    int32 i;
    int32 hLen = mrc_wstrlen(sHex);
    int32 dLen = hLen / 2 + 2;
    uint8 *sHexA, *hData;

    if (hLen <= 0)
        return;

    mrc_memset(LastInput, 0, sizeof(LastInput));
    mrc_memcpy(LastInput, sHex, hLen);

    sHexA = (uint8*)mrc_malloc(dLen);
    hData = (uint8*)mrc_malloc(dLen);

    for(i = 0; i < hLen / 2; i++)
    {
        sHexA[i] = sHex[i * 2 + 1];
    }

    ToReplaceSize = hLen / 4;
    Hex2Data(sHexA, ToReplaceSize * 2, hData, dLen);
    mrc_memset(ToReplace, 0, sizeof(ToReplace));
    mrc_memcpy(ToReplace, hData, ToReplaceSize);
    mrc_free(sHexA);
    mrc_free(hData);

    M_FastReplace();
}

//�滻�ı� Uincode-B
//�������滻Ϊ�ı�
void ReplaceText_UB(char *sText)
{
    mrc_memset(LastInput, 0, sizeof(LastInput));
    mrc_memcpy(LastInput, sText, mrc_wstrlen(sText));

    ToReplaceSize = mrc_wstrlen(sText);
    mrc_memset(ToReplace, 0, sizeof(ToReplace));
    mrc_memcpy(ToReplace, LastInput, ToReplaceSize);

    M_FastReplace();
}

//�滻�ı� Uincode-L
//�������滻Ϊ�ı�
void ReplaceText_UL(char *sText)
{
    mrc_memset(LastInput, 0, sizeof(LastInput));
    mrc_memcpy(LastInput, sText, mrc_wstrlen(sText));

    ToReplaceSize = mrc_wstrlen(sText);
    mrc_memset(ToReplace, 0, sizeof(ToReplace));
    mrc_memcpy(ToReplace, LastInput, ToReplaceSize);
    ExchangeBytes(ToReplace, 512);

    M_FastReplace();
}

//�滻�ı� GB2312
//�������滻Ϊ�ı�
void ReplaceText_GB(char *sText)
{
    mrc_memset(LastInput, 0, sizeof(LastInput));
    mrc_memcpy(LastInput, sText, mrc_wstrlen(sText));

    UniToGB((char*)LastInput, (char*)ToReplace, 512);
    ToReplaceSize = mrc_strlen((char*)ToReplace);

    M_FastReplace();
}

//�滻�ı� UTF8
//�������滻Ϊ�ı�
void ReplaceText_UTF8(char *sText)
{
    mrc_memset(LastInput, 0, sizeof(LastInput));
    mrc_memcpy(LastInput, sText, mrc_wstrlen(sText));

    ToReplaceSize = wstr2str(LastInput, (char*)ToReplace, 512);

    M_FastReplace();
}
