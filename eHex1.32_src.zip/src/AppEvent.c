/*
* �������¼������ļ�
*/

#include <mrc_base.h>

#include "AppMain.h"
#include "MenuFunc.h"
#include "FileView.h"
#include "LocalUI.h"
#include "Draw.h"
#include "Menu.h"
#include "VCmd.h"
#include "BackRun.h"
#include "NumConv.h"
#include "KeyTimer.h"

#define MR_LOCALUI_APPRESUME  2

extern mr_screenRectSt rectTitle, rectTool; //��������������
extern mr_screenRectSt rectMain, rectInfo; //����ʾ������Ϣ��
extern mr_screenRectSt rectTCmd1, rectTCmd2; //��������ť

static POSXY_ST MousePos; //��������λ��

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
//ģ����������
static void EKeyTimerDo(int32 data)
{
    ChangeDataOffset(data);
}

/*-----------------------------------------------------------------------------------*/
//��ͨ״̬����UP
void DoKeyUpMain(int32 KeyCode)
{
    int32 fSize = GetFileSize();

	switch (KeyCode)
	{
	case MR_KEY_SOFTRIGHT:
        ChangeAppState(APPSTATE_NORMAL, 1);
		break;
    case MR_KEY_SOFTLEFT:
        ChangeAppState(APPSTATE_MENU, 1);
        break;
    case MR_KEY_5:
    case MR_KEY_SELECT:
        if (fSize > 0)
            ChangeAppState(APPSTATE_HEXEDIT, 1);
        break;
    case MR_KEY_UP:
        if (fSize > 0)
            KeyTimerStop();
        break;
    case MR_KEY_DOWN:
        if (fSize > 0)
            KeyTimerStop();
        break;
    case MR_KEY_LEFT:
        if (fSize > 0)
            KeyTimerStop();
        break;
    case MR_KEY_RIGHT:
        if (fSize > 0)
            KeyTimerStop();
        break;
    case MR_KEY_1:
        if (fSize > 0)
            KeyTimerStop();
        break;
    case MR_KEY_4:
        if (fSize > 0)
            KeyTimerStop();
        break;
    case MR_KEY_3:
        if (fSize > 0)
            ChangeDataOffset(OFFSET_SEEK_BEGIN);
        break;
    case MR_KEY_6:
        if (fSize > 0)
            ChangeDataOffset(OFFSET_SEEK_END);
        break;
    case MR_KEY_2:
        if (fSize > 0)
            M_GotoOffset();
        break;
    case MR_KEY_7:
        M_ShowMenuFind();
        break;
    case MR_KEY_8:
        M_ShowMenuReplace();
        break;
    case MR_KEY_9:
        M_ShowMenuCompare();
        break;
    case MR_KEY_0:
        M_RedoRecent();
        break;
    case MR_KEY_STAR:
        ChangeAppColor();
        break;
    }
}

//��ͨ״̬����DOWN
void DoKeyDownMain(int32 KeyCode)
{
    int32 fSize = GetFileSize();

    KeyTimerStop();

	switch(KeyCode)
	{
    case MR_KEY_SOFTRIGHT:
        {
            if (0 == AppDatas.HIndex)
                AppDatas.HIndex = 1;
            else
                AppDatas.HIndex = 0;
            DrawTool(1, 2, 1);
        }
        break;
    case MR_KEY_SOFTLEFT:
        DrawTool(1, 1, 1);
        break;
    case MR_KEY_SELECT:
        break;
    case MR_KEY_UP:
        if (fSize > 0)
            KeyTimerStart(OFFSET_SEEK_LINE_UP, EKeyTimerDo);
        break;
    case MR_KEY_DOWN:
        if (fSize > 0)
            KeyTimerStart(OFFSET_SEEK_LINE_DOWN, EKeyTimerDo);
        break;
    case MR_KEY_LEFT:
        if (fSize > 0)
            KeyTimerStart(OFFSET_SEEK_BYTE_LAST, EKeyTimerDo);
        break;
    case MR_KEY_RIGHT:
        if (fSize > 0)
            KeyTimerStart(OFFSET_SEEK_BYTE_NEXT, EKeyTimerDo);
        break;
    case MR_KEY_1:
        if (fSize > 0)
            KeyTimerStart(OFFSET_SEEK_PAGE_UP, EKeyTimerDo);
        break;
    case MR_KEY_4:
        if (fSize > 0)
            KeyTimerStart(OFFSET_SEEK_PAGE_DOWN, EKeyTimerDo);
        break;
    case MR_KEY_3:
        break;
    case MR_KEY_6:
        break;
    case MR_KEY_7:
        break;
    case MR_KEY_8:
        break;
    case MR_KEY_9:
        break;
    case MR_KEY_0:
        break;
    default:
        break;
    }
}

//��ͨ״̬�����¼�-̧��
void DoMouseUpMain(int32 X, int32 Y)
{
    KeyTimerStop();

    if (Y < rectTitle.h)
    {
    }
    else if (Y >= rectMain.y && Y < rectMain.y + rectMain.h)
    {
        if (X - MousePos.X > (int32)rectMain.w / 4) //���һ���
        {
            ChangeDataOffset(OFFSET_SEEK_PAGE_UP);
        }
        else if (MousePos.X - X > (int32)rectMain.w / 4) //���󻬶�
        {
            ChangeDataOffset(OFFSET_SEEK_PAGE_DOWN);
        }
        else
        {
            MousePos2Offset(X, Y);
        }
    }
    else if (Y >= rectInfo.y && Y < rectInfo.y + rectInfo.h)
    {
    }
    else if (Y >= rectTool.y && Y < rectTool.y + rectTool.h)
    {
        if (X >= rectTCmd1.x && X < rectTCmd1.x + rectTCmd1.w)
        {
            DoKeyUpMain(MR_KEY_SOFTLEFT);
        }
        else if (X >= rectTCmd2.x && X < rectTCmd2.x + rectTCmd2.w)
        {
            DoKeyUpMain(MR_KEY_SOFTRIGHT);
        }
    }
}

//��ͨ״̬�����¼�-����
void DoMouseDownMain(int32 X, int32 Y)
{
    MousePos.X = (int16)X;
    MousePos.Y = (int16)Y;

    if (Y >= rectInfo.y && Y < rectInfo.y + rectInfo.h)
    {
        if (X < rectInfo.x + rectInfo.w / 4)
            KeyTimerStart(OFFSET_SEEK_BYTE_LAST, EKeyTimerDo);
        else if (X > rectInfo.x + (rectInfo.w / 4) * 3)
            KeyTimerStart(OFFSET_SEEK_BYTE_NEXT, EKeyTimerDo);
        else if (Y < rectInfo.y + rectInfo.h / 2)
            KeyTimerStart(OFFSET_SEEK_LINE_UP, EKeyTimerDo);
        else
            KeyTimerStart(OFFSET_SEEK_LINE_DOWN, EKeyTimerDo);
    }
    else if (Y >= rectTool.y && Y < rectTool.y + rectTool.h)
    {
        if (X >= rectTCmd1.x && X < rectTCmd1.x + rectTCmd1.w)
        {
            DoKeyDownMain(MR_KEY_SOFTLEFT);
        }
        else if (X >= rectTCmd2.x && X < rectTCmd2.x + rectTCmd2.w)
        {
            DoKeyDownMain(MR_KEY_SOFTRIGHT);
        }
    }
}

/*----------------------------------------------------------------------------------------------------*/
//�༭״̬�����¼�-̧��
void DoMouseUpHexEdit(int32 X, int32 Y)
{
    if (Y >= rectTool.y && Y < rectTool.y + rectTool.h)
    {
        if (X >= rectTCmd1.x && X < rectTCmd1.x + rectTCmd1.w)
        {
            DoKeyUpHexEdit(MR_KEY_SOFTLEFT);
        }
        else if (X >= rectTCmd2.x && X < rectTCmd2.x + rectTCmd2.w)
        {
            DoKeyUpHexEdit(MR_KEY_SOFTRIGHT);
        }
    }
    else
    {
        DoMouseHexEdit(X, Y, 0);
    }
}

//�༭״̬�����¼�-����
void DoMouseDownHexEdit(int32 X, int32 Y)
{
    if (Y >= rectTool.y && Y < rectTool.y + rectTool.h)
    {
        if (X >= rectTCmd1.x && X < rectTCmd1.x + rectTCmd1.w)
        {
            DoKeyDownHexEdit(MR_KEY_SOFTLEFT);
        }
        else if (X >= rectTCmd2.x && X < rectTCmd2.x + rectTCmd2.w)
        {
            DoKeyDownHexEdit(MR_KEY_SOFTRIGHT);
        }
    }
    else
    {
        DoMouseHexEdit(X, Y, 1);
    }
}

/*----------------------------------------------------------------------------------------------------*/
//�˵�״̬�����¼�-̧��
void DoMouseUpMenu(int32 X, int32 Y)
{
    if (Y >= rectTool.y && Y < rectTool.y + rectTool.h)
    {
        if (X >= rectTCmd1.x && X < rectTCmd1.x + rectTCmd1.w)
        {
            MenuEvent(MR_KEY_RELEASE, MR_KEY_SOFTLEFT, 0);
        }
        else if (X >= rectTCmd2.x && X < rectTCmd2.x + rectTCmd2.w)
        {
            MenuEvent(MR_KEY_RELEASE, MR_KEY_SOFTRIGHT, 0);
        }
    }
    else
    {
        MenuEvent(MR_MOUSE_UP, X, Y);
    }
}

//�˵�״̬�����¼�-����
void DoMouseDownMenu(int32 X, int32 Y)
{
    if (Y >= rectTool.y && Y < rectTool.y + rectTool.h)
    {
        if (X >= rectTCmd1.x && X < rectTCmd1.x + rectTCmd1.w)
        {
            MenuEvent(MR_KEY_PRESS, MR_KEY_SOFTLEFT, 0);
        }
        else if (X >= rectTCmd2.x && X < rectTCmd2.x + rectTCmd2.w)
        {
            MenuEvent(MR_KEY_PRESS, MR_KEY_SOFTRIGHT, 0);
        }
    }
    else
    {
        MenuEvent(MR_MOUSE_DOWN, X, Y);
    }
}

/*-------------------------------------------------------------------------------------*/
//�ļ����״̬����̧��
void DoMouseUpFV(int32 X, int32 Y)
{
    if (Y >= rectTool.y && Y < rectTool.y + rectTool.h)
    {
        if (X >= rectTCmd1.x && X < rectTCmd1.x + rectTCmd1.w)
        {
            FV_Event(MR_KEY_RELEASE, MR_KEY_SOFTLEFT, 0);
        }
        else if (X >= rectTCmd2.x && X < rectTCmd2.x + rectTCmd2.w)
        {
            FV_Event(MR_KEY_RELEASE, MR_KEY_SOFTRIGHT, 0);
        }
    }
    else
    {
        FV_Event(MR_MOUSE_UP, X, Y);
    }
}

//�ļ����״̬����̧��
void DoMouseDownFV(int32 X, int32 Y)
{
    if (Y >= rectTool.y && Y < rectTool.y + rectTool.h)
    {
        if (X >= rectTCmd1.x && X < rectTCmd1.x + rectTCmd1.w)
        {
            FV_Event(MR_KEY_PRESS, MR_KEY_SOFTLEFT, 0);
        }
        else if (X >= rectTCmd2.x && X < rectTCmd2.x + rectTCmd2.w)
        {
            FV_Event(MR_KEY_PRESS, MR_KEY_SOFTRIGHT, 0);
        }
    }
    else
    {
        FV_Event(MR_MOUSE_DOWN, X, Y);
    }
}

/*-------------------------------------------------------------------------------------*/
//����ת��״̬����̧��
void DoMouseUpNC(int32 X, int32 Y)
{
    if (Y >= rectTool.y && Y < rectTool.y + rectTool.h)
    {
        if (X >= rectTCmd1.x && X < rectTCmd1.x + rectTCmd1.w)
        {
            NC_Event(MR_KEY_RELEASE, MR_KEY_SOFTLEFT, 0);
        }
        else if (X >= rectTCmd2.x && X < rectTCmd2.x + rectTCmd2.w)
        {
            NC_Event(MR_KEY_RELEASE, MR_KEY_SOFTRIGHT, 0);
        }
    }
    else
    {
        NC_Event(MR_MOUSE_UP, X, Y);
    }
}

//����ת��״̬����̧��
void DoMouseDownNC(int32 X, int32 Y)
{
    if (Y >= rectTool.y && Y < rectTool.y + rectTool.h)
    {
        if (X >= rectTCmd1.x && X < rectTCmd1.x + rectTCmd1.w)
        {
            NC_Event(MR_KEY_PRESS, MR_KEY_SOFTLEFT, 0);
        }
        else if (X >= rectTCmd2.x && X < rectTCmd2.x + rectTCmd2.w)
        {
            NC_Event(MR_KEY_PRESS, MR_KEY_SOFTRIGHT, 0);
        }
    }
    else
    {
        NC_Event(MR_MOUSE_DOWN, X, Y);
    }
}

/*---------------------------------------------------------------------------------------*/

//�����¼�
void AppKeyWinEvent(int32 type, int32 p1, int32 p2)
{
    APPSTATE aState = GetAppState();

    //���������������ȼ�
    if (MR_KEY_RELEASE == type && MR_KEY_SEND == p1)
    {
        SnapScreen();
        return;
    }
    else if (MR_MOUSE_DOWN == type && p2 < rectTitle.y + rectTitle.h)
    {
        SnapScreen();
        return;
    }

    switch(aState)
    {
    case APPSTATE_NORMAL: //��ͨ״̬
        switch(type)
        {
        case MR_KEY_RELEASE:
            DoKeyUpMain(p1);
            break;
        case MR_KEY_PRESS:
            DoKeyDownMain(p1);
            break;
        case MR_MOUSE_UP:
            DoMouseUpMain(p1, p2);
            break;
        case MR_MOUSE_DOWN:
            DoMouseDownMain(p1, p2);
            break;
        case MR_MOUSE_MOVE:
            break;
        }
        break;
    case APPSTATE_HEXEDIT: //Hex�༭״̬
        switch(type)
        {
        case MR_KEY_RELEASE:
            DoKeyUpHexEdit(p1);
            break;
        case MR_KEY_PRESS:
            DoKeyDownHexEdit(p1);
            break;
        case MR_MOUSE_UP:
            DoMouseUpHexEdit(p1, p2);
            break;
        case MR_MOUSE_DOWN:
            DoMouseDownHexEdit(p1, p2);
            break;
        case MR_MOUSE_MOVE:
            break;
        }
        break;
    case APPSTATE_MENU: //��ʾ�˵�״̬
        switch(type)
        {
        case MR_KEY_RELEASE:
        case MR_KEY_PRESS:
            MenuEvent(type, p1, p2);
            break;
        case MR_MOUSE_UP:
            DoMouseUpMenu(p1, p2);
            break;
        case MR_MOUSE_DOWN:
            DoMouseDownMenu(p1, p2);
            break;
        case MR_MOUSE_MOVE:
            break;
        }
        break;
    case APPSTATE_MSG: //��ʾ��Ϣ״̬
        switch(type)
        {
        case MR_KEY_RELEASE:
            ChangeAppState(APPSTATE_NORMAL, 1);
            break;
        case MR_KEY_PRESS:
            break;
        case MR_MOUSE_UP:
            ChangeAppState(APPSTATE_NORMAL, 1);
            break;
        case MR_MOUSE_DOWN:
            break;
        case MR_MOUSE_MOVE:
            break;
        }
        break;
    //case APPSTATE_SET: //���ý���
    //    switch(type)
    //    {
    //    case MR_KEY_RELEASE:
    //        break;
    //    case MR_KEY_PRESS:
    //        break;
    //    case MR_MOUSE_UP:
    //        break;
    //    case MR_MOUSE_DOWN:
    //        break;
    //    }
    //    break;
    case APPSTATE_FILEVIEW: //�ļ��������
        switch(type)
        {
        case MR_KEY_RELEASE:
        case MR_KEY_PRESS:
            FV_Event(type, p1, p2);
            break;
        case MR_MOUSE_UP:
            DoMouseUpFV(p1, p2);
            break;
        case MR_MOUSE_DOWN:
            DoMouseDownFV(p1, p2);
            break;
        case MR_MOUSE_MOVE:
            break;
        }
        break;
    case APPSTATE_LOCALUI: //���ؿؼ��¼�
        switch(type)
        {
        case MR_DIALOG_EVENT: //�Ի����¼����༭��
		    DoDialogEvent(p1);
            break;
        case MR_LOCALUI_EVENT: //���ش����¼�
            break;
        }
        break;
    case APPSTATE_BACKRUN: //��̨�����¼�
        switch(type)
        {
        case MR_LOCALUI_EVENT: //���ش����¼�
            if (MR_LOCALUI_APPRESUME == p1)
            {
                HideStateIcon();
                ChangeAppState(APPSTATE_NORMAL, 1);
            }
            break;
        }
        break;
    case APPSTATE_NUMCONV:
        switch(type)
        {
        case MR_KEY_RELEASE:
        case MR_KEY_PRESS:
            NC_Event(type, p1, p2);
            break;
        case MR_MOUSE_UP:
            DoMouseUpNC(p1, p2);
            break;
        case MR_MOUSE_DOWN:
            DoMouseDownNC(p1, p2);
            break;
        case MR_MOUSE_MOVE:
            break;
        }
        break;
    }
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
//Ӧ�ó�ʼ������
int32 MRC_EXT_INIT(void)
{
    MainInit();
    ChangeAppState(APPSTATE_NORMAL, 1);

	return MR_SUCCESS;
}

//�ú�����Ӧ�������ڼ䣬ÿ��mythroadƽ̨�յ��¼�ʱ�����á�
int32 mrc_appEvent(int32 code, int32 param0, int32 param1)
{
	AppKeyWinEvent(code, param0, param1);
	return MR_SUCCESS;
}

//�ú�����Ӧ����ͣʱ��mythroadƽ̨���á�
int32 mrc_appPause(void)
{
	return MR_SUCCESS;
}

//�ú�����Ӧ�ûָ�����ʱ��mythroadƽ̨���á�
int32 mrc_appResume(void)
{
    DrawMainForm(1);
	return MR_SUCCESS;
}

//�ú�����Ӧ���˳�ʱ��mythroadƽ̨���á�
int32 MRC_EXT_EXIT(void)
{
    MainEnd();

	return 0;
}

/************************************************************************/
/* �����°������                                                       */
/************************************************************************/

#include "mrc_mrpverify.h"

E_MRPVERIFY_RESULT  mrc_verifyMrpCertificate_V1(const char *mrpName)
{
    return E_VERIFY_RESULT_SUC;
}