/*
* Hex�༭������������
*/

#include <mrc_base.h>

#include "VCmd.h"
#include "AppMain.h"
#include "Draw.h"
#include "KeyTimer.h"

extern mr_screenRectSt rectInfo; //��Ϣ����

static mr_screenRectSt rectVCmd[4], rectVCmdAll; //��Ļ���ⰴ��
static uint8 VCmdClass; //��Ļ���ⰴ�����

//��ʼ�����ⰴť��С��λ��
void InitVCmd(void)
{
    int16 i;
    int32 fw, fh;
    uint16 cmdHeight, cmdWidth;

    mrc_unicodeTextWidthHeight((uint16*)"\x65\x87\x67\x2c\x0\x0", AppDatas.AppFont, &fw, &fh); //"�ı�"
    cmdHeight = (uint16)fh + 4;
    mrc_unicodeTextWidthHeight((uint16*)"\x0\x30\x0\x41\x0\x0", AppDatas.AppFont, &fw, &fh); //"0A"
    cmdWidth = (uint16)(fw / 2) * 5 + 4;

    rectVCmdAll.x = rectInfo.x;
    rectVCmdAll.y = rectInfo.y;
    rectVCmdAll.w = rectInfo.w;
    rectVCmdAll.h = rectInfo.h;

    for (i = 0; i < 4; i++)
    {
        rectVCmd[i].w = cmdWidth;
        rectVCmd[i].h = cmdHeight;
    }

    rectVCmd[0].x = (rectVCmdAll.w - cmdWidth) / 2;
    rectVCmd[0].y = rectVCmdAll.y + 1;

    rectVCmd[1].x = (rectVCmdAll.w - cmdWidth) / 2;
    rectVCmd[1].y = rectVCmdAll.y + rectVCmdAll.h - cmdHeight - 1;

    rectVCmd[2].x = rectVCmdAll.x + 1;
    rectVCmd[2].y = rectVCmdAll.y + (rectVCmdAll.h - cmdHeight) / 2;

    rectVCmd[3].x = rectVCmdAll.x + rectVCmdAll.w - cmdWidth - 1;
    rectVCmd[3].y = rectVCmdAll.y + (rectVCmdAll.h - cmdHeight) / 2;
}

//�������ⰴ��
//�������飺0 - ȫ����1 - 0-3�� 2 - 4-7�� 3 - 8-B��4 - C-F
//      ����������ţ�0 - 3
void DrawVCmd(uint8 cIndex, uint8 pIndex, uint8 Refresh)
{
    char *cText[4];

    switch(cIndex)
    {
    case 1:
        cText[0] = "\x0\x30\x0\x0";
        cText[1] = "\x0\x31\x0\x0";
        cText[2] = "\x0\x32\x0\x0";
        cText[3] = "\x0\x33\x0\x0";
        break;
    case 2:
        cText[0] = "\x0\x34\x0\x0";
        cText[1] = "\x0\x35\x0\x0";
        cText[2] = "\x0\x36\x0\x0";
        cText[3] = "\x0\x37\x0\x0";
        break;
    case 3:
        cText[0] = "\x0\x38\x0\x0";
        cText[1] = "\x0\x39\x0\x0";
        cText[2] = "\x0\x41\x0\x0";
        cText[3] = "\x0\x42\x0\x0";
        break;
    case 4:
        cText[0] = "\x0\x43\x0\x0";
        cText[1] = "\x0\x44\x0\x0";
        cText[2] = "\x0\x45\x0\x0";
        cText[3] = "\x0\x46\x0\x0";
        break;
    default:
        cText[0] = "\x0\x30\x0\x31\x0\x32\x0\x33\x0\x0";
        cText[1] = "\x0\x34\x0\x35\x0\x36\x0\x37\x0\x0";
        cText[2] = "\x0\x38\x0\x39\x0\x41\x0\x42\x0\x0";
        cText[3] = "\x0\x43\x0\x44\x0\x45\x0\x46\x0\x0";
        break;
    }

    DrawFillRect(rectVCmdAll, AppColor.backColor);

    DrawCmd(rectVCmd[0], cText[0], 1, (0 == pIndex) ? 1 : 0, 0);
    DrawCmd(rectVCmd[1], cText[1], 1, (1 == pIndex) ? 1 : 0, 0);
    DrawCmd(rectVCmd[2], cText[2], 1, (2 == pIndex) ? 1 : 0, 0);
    DrawCmd(rectVCmd[3], cText[3], 1, (3 == pIndex) ? 1 : 0, 0);

    DrawRoundRect(rectVCmdAll);

    if (Refresh > 0)
    {
        mrc_refreshScreen(rectVCmdAll.x, rectVCmdAll.y, rectVCmdAll.w, rectVCmdAll.h);
    }
}

//����
void ChangeVCmd(int32 KeyCode)
{
    if (0 == VCmdClass)
    {
        VCmdClass = (uint8)KeyCode;
        DrawVCmd(VCmdClass, 4, 1);
    }
    else
    {
        SaveData((VCmdClass - 1) * 4 + (uint8)KeyCode - 1);
        VCmdClass = 0;
        DrawVCmd(VCmdClass, 4, 1);
    }
}

//�ػ�
void ReDrawVCmd(void)
{
    DrawVCmd(VCmdClass, 4, 0);
}

// ���ּ�ֱ������ֵ�ص�
static void InputValueCb(int32 data)
{
    SaveData((uint8)data);
}

/*-------------------------------------------------------------------------------------------*/
//Hex�༭״̬����UP
void DoKeyUpHexEdit(int32 KeyCode)
{
	switch(KeyCode)
	{
    case MR_KEY_UP:
        DrawVCmd(VCmdClass, 0, 1);
        ChangeVCmd(1);
        break;
    case MR_KEY_DOWN:
        DrawVCmd(VCmdClass, 1, 1);
        ChangeVCmd(2);
        break;
    case MR_KEY_LEFT:
        DrawVCmd(VCmdClass, 2, 1);
        ChangeVCmd(3);
        break;
    case MR_KEY_RIGHT:
        DrawVCmd(VCmdClass, 3, 1);
        ChangeVCmd(4);
        break;
    case MR_KEY_0:
    case MR_KEY_1:
    case MR_KEY_2:
    case MR_KEY_3:
    case MR_KEY_4:
    case MR_KEY_5:
    case MR_KEY_6:
    case MR_KEY_7:
    case MR_KEY_8:
    case MR_KEY_9:
        KeyTimerStop();
        break;
    case MR_KEY_SELECT:
    case MR_KEY_SOFTLEFT:
        ChangeAppState(APPSTATE_NORMAL, 1);
        break;
    case MR_KEY_SOFTRIGHT:
        if (0 == VCmdClass)
        {
            ChangeAppState(APPSTATE_NORMAL, 1);
        }
        else
        {
            DrawTool(0, 0, 1);
            DrawVCmd(0, 4, 1);
        }
        VCmdClass = 0;
        break;
    case MR_KEY_STAR:
        ChangeAppColor();
        break;
    }
}

//Hex�༭״̬����DOWN
void DoKeyDownHexEdit(int32 KeyCode)
{
	switch(KeyCode)
	{
    case MR_KEY_UP:
        DrawVCmd(VCmdClass, 0, 1);
        break;
    case MR_KEY_DOWN:
        DrawVCmd(VCmdClass, 1, 1);
        break;
    case MR_KEY_LEFT:
        DrawVCmd(VCmdClass, 2, 1);
        break;
    case MR_KEY_RIGHT:
        DrawVCmd(VCmdClass, 3, 1);
        break;
    case MR_KEY_0:
    case MR_KEY_1:
    case MR_KEY_2:
    case MR_KEY_3:
    case MR_KEY_4:
    case MR_KEY_5:
    case MR_KEY_6:
    case MR_KEY_7:
    case MR_KEY_8:
    case MR_KEY_9:
        KeyTimerStart(KeyCode, InputValueCb);
        break;
    case MR_KEY_SELECT:
    case MR_KEY_SOFTLEFT:
        DrawTool(0, 1, 1);
        break;
    case MR_KEY_SOFTRIGHT:
        DrawTool(0, 2, 1);
        break;
    }
}

//��������
void DoMouseHexEdit(int32 X, int32 Y, uint8 IsMouseDown)
{
    uint8 i;

    if (X >= rectVCmdAll.x && X < rectVCmdAll.x + rectVCmdAll.w && Y>= rectVCmdAll.y && Y <= rectVCmdAll.y + rectVCmdAll.h)
    {
        for(i = 0; i < 4; i++)
        {
            if (X >= rectVCmd[i].x && X < rectVCmd[i].x + rectVCmd[i].w && Y>= rectVCmd[i].y && Y <= rectVCmd[i].y + rectVCmd[i].h)
            {
                if (0 == IsMouseDown)
                {
                    DrawVCmd(VCmdClass, i, 1);
                    ChangeVCmd(i + 1);
                }
                else
                {
                    DrawVCmd(VCmdClass, i, 1);
                }
                break;
            }
        }
    }
    else
    {
        if (0 == IsMouseDown)
        {
            DoKeyUpHexEdit(MR_KEY_SOFTRIGHT);
        }
        else
        {
            DoKeyDownHexEdit(MR_KEY_SOFTRIGHT);
        }
    }
}
