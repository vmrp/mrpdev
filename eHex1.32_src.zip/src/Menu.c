/*
* ����˵�����
*/

#include <mrc_base.h>

#include "Menu.h"
#include "Draw.h"
#include "MenuFunc.h"
#include "AppMain.h"
#include "KeyTimer.h"

static mr_screenRectSt rectMenus[4];
static mr_screenRectSt rectSpace;
static PMENU_LINK ActiveMenu;
static PMENU_LINK RootMenu;
static uint16 ItemHeight;
static int8 MenuLayer;

void InitMenuRect(void)
{
    int32 fw, fh;

    mrc_unicodeTextWidthHeight((uint16*)"\x68\x39\x0\x0", AppDatas.AppFont, &fw, &fh);
    ItemHeight = (uint16)(fh + 4);
}

//��ʼ���˵���
void InitMenuItem(void)
{
    PMENU_LINK TempMenu, TempMenu2;

    RootMenu = MenuAdd("\x68\x39\x76\xee\x5f\x55\x0\x0", NULL, NULL, 0, 0, 1); //��Ŀ¼

    TempMenu = MenuAdd("\x7f\x16\x8f\x91\x0\x0", NULL, RootMenu, 0, 0, 1); //�༭
        TempMenu2 = MenuAdd("\x67\xe5\x62\x7e\x0\x0", NULL, TempMenu, 1, 0, 1); //����
            MenuAdd("\x0\x47\x0\x42\x0\x32\x0\x33\x0\x31\x0\x32\x0\x0", M_FindTextA, TempMenu2, 1, 0, 1); //GB2312
            MenuAdd("\x0\x55\x0\x43\x0\x53\x0\x32\x0\x42\x0\x45\x0\x0", M_FindTextW, TempMenu2, 1, 0, 1); //UCS2BE
            MenuAdd("\x0\x55\x0\x43\x0\x53\x0\x32\x0\x4c\x0\x45\x0\x0", M_FindTextWL, TempMenu2, 1, 0, 1); //UCS2LE
            MenuAdd("\x0\x55\x0\x54\x0\x46\x0\x2d\x0\x38\x0\x0", M_FindTextUTF8, TempMenu2, 1, 0, 1); //UTF-8
            MenuAdd("\x0\x31\x0\x30\x8f\xdb\x52\x36\x0\x0", M_FindNum, TempMenu2, 1, 0, 1); //10����
            MenuAdd("\x0\x31\x0\x36\x8f\xdb\x52\x36\x0\x0", M_FindHex, TempMenu2, 1, 0, 1); //16����
            MenuAdd("\x4e\xb\x4e\x0\x4e\x2a\x0\x0", M_FindNext, TempMenu2, 1, 0, 1); //��һ��

        TempMenu2 = MenuAdd("\x66\xff\x63\x62\x0\x0", NULL, TempMenu, 1, 0, 1); //�滻
            MenuAdd("\x0\x47\x0\x42\x0\x32\x0\x33\x0\x31\x0\x32\x0\x0", M_ReplaceTextA, TempMenu2, 1, 0, 1); //GB2312
            MenuAdd("\x0\x55\x0\x43\x0\x53\x0\x32\x0\x42\x0\x45\x0\x0", M_ReplaceTextW, TempMenu2, 1, 0, 1); //UCS2BE
            MenuAdd("\x0\x55\x0\x43\x0\x53\x0\x32\x0\x4c\x0\x45\x0\x0", M_ReplaceTextWL, TempMenu2, 1, 0, 1); //UCS2LE
            MenuAdd("\x0\x55\x0\x54\x0\x46\x0\x2d\x0\x38\x0\x0", M_ReplaceTextUTF8, TempMenu2, 1, 0, 1); //UTF-8
            MenuAdd("\x0\x31\x0\x30\x8f\xdb\x52\x36\x0\x0", M_ReplaceNum, TempMenu2, 1, 0, 1); //10����
            MenuAdd("\x0\x31\x0\x36\x8f\xdb\x52\x36\x0\x0", M_ReplaceHex, TempMenu2, 1, 0, 1); //16����
            MenuAdd("\x7e\xe7\x7e\xed\x0\x0", M_FastReplace, TempMenu2, 1, 0, 1); //����

        TempMenu2 = MenuAdd("\x4f\x4d\x7f\x6e\x0\x0", NULL, TempMenu, 1, 0, 1); //λ��
            MenuAdd("\x4e\xa\x98\x75\x0\x0", M_PageUp, TempMenu2, 1, 0, 1); //��ҳ
            MenuAdd("\x4e\xb\x98\x75\x0\x0", M_PageDown, TempMenu2, 1, 0, 1); //��ҳ
            MenuAdd("\x5f\x0\x59\x34\x0\x0", M_PageHome, TempMenu2, 1, 0, 1); //��ͷ
            MenuAdd("\x67\x2b\x5c\x3e\x0\x0", M_PageEnd, TempMenu2, 1, 0, 1); //ĩβ
            MenuAdd("\x8f\x6c\x52\x30\x0\x0", M_GotoOffset, TempMenu2, 1, 0, 1); //ת��

        TempMenu2 = MenuAdd("\x6b\xd4\x8f\x83\x0\x0", NULL, TempMenu, 1, 0, 1); //�Ƚ�
            MenuAdd("\x76\xf8\x54\xc\x5b\x57\x82\x82\x0\x0", M_CompareSame, TempMenu2, 1, 1, 0); //��ͬ�ֽ�
            MenuAdd("\x4e\xd\x54\xc\x5b\x57\x82\x82\x0\x0", M_CompareDiff, TempMenu2, 1, 0, 0); //��ͬ�ֽ�
            MenuAdd("\x4e\xb\x4e\x0\x4e\x2a\x0\x0", M_CompareNext, TempMenu2, 1, 0, 1); //��һ��

        TempMenu2 = MenuAdd("\x65\x70\x63\x6e\x0\x0", NULL, TempMenu, 1, 0, 1); //����
            MenuAdd("\x63\xd2\x51\x65\x0\x0", M_AddData, TempMenu2, 1, 0, 1); //����
            MenuAdd("\x79\xfb\x96\x64\x0\x0", M_DelData, TempMenu2, 1, 0, 1); //�Ƴ�
            MenuAdd("\x62\x2a\x53\xd6\x0\x0", M_Data2File, TempMenu2, 1, 0, 1); //��ȡ

    TempMenu = MenuAdd("\x65\x87\x4e\xf6\x0\x0", NULL, RootMenu, 1, 0, 1); //�ļ�
        TempMenu2 = MenuAdd("\x62\x53\x5f\x0\x0\x0", NULL, TempMenu, 1, 0, 1); //��
            MenuAdd("\x6d\x4f\x89\xc8\x0\x0", M_FileView, TempMenu2, 1, 0, 0); //���
            MenuAdd("\x5e\x38\x75\x28\x0\x0", M_FVUserDir, TempMenu2, 1, 0, 1); //����
            //MenuAdd("\x76\xee\x5f\x55\x0\x0", M_DirView, TempMenu2, 1, 0, 1); //Ŀ¼
            MenuAdd("\x53\x86\x53\xf2\x0\x0", M_FVRecent, TempMenu2, 1, 0, 1); //��ʷ
            
        TempMenu2 = MenuAdd("\x64\xcd\x4f\x5c\x0\x0", NULL, TempMenu, 0, 0, 1); //����
            MenuAdd("\x65\x39\x54\xd\x0\x0", M_FileRename, TempMenu2, 1, 0, 1); //����
            MenuAdd("\x59\xd\x52\x36\x0\x0", M_FileCopy, TempMenu2, 1, 0, 1); //����
            MenuAdd("\x52\x20\x96\x64\x0\x0", M_FileDel, TempMenu2, 1, 0, 1); //ɾ��

            MenuAdd("\x51\x73\x95\xed\x0\x0", M_FileClose, TempMenu, 0, 0, 1); //�ر�
            MenuAdd("\x65\xb0\x5e\xfa\x0\x0", M_CreateFile, TempMenu, 1, 0, 1); //�½�

    TempMenu = MenuAdd("\x5d\xe5\x51\x77\x0\x0", NULL, RootMenu, 1, 0, 1); //����
        TempMenu2 = MenuAdd("\x54\xe\x53\xf0\x8f\xd0\x88\x4c\x0\x0", NULL, TempMenu, 1, 0, 1); //��̨����
            MenuAdd("\x65\x87\x4e\xf6\x76\xd1\x89\xc6\x0\x0", M_BR_Flie, TempMenu2, 1, 0, 1); //�ļ�����
            MenuAdd("\x66\x6e\x90\x1a\x6a\x21\x5f\x0f\x0\x0", M_BR_Normal, TempMenu2, 1, 0, 1); //��ͨģʽ
            MenuAdd("\x5e\xf6\x65\xf6\x8f\xd4\x56\xde\x0\x0", M_BR_Delay, TempMenu2, 1, 0, 1); //��ʱ����

        MenuAdd("\x8f\xdb\x52\x36\x8f\x6c\x63\x62\x0\x0", M_Tool_ConvNum, TempMenu, 1, 0, 1); //����ת��
        //MenuAdd("\x72\x79\x6b\x8a\x5b\x57\x7b\x26\x0\x0", M_Tool_CharView, TempMenu, 1, 0, 1); //�����ַ�
        //MenuAdd("\x65\x87\x4e\xf6\x54\x8\x5e\x76\x0\x0", NULL, TempMenu, 0, 0, 1); //�ļ��ϲ�
        //MenuAdd("\x76\x7e\x5e\xa6\x4e\x0\x4e\xb\x0\x0", M_Tool_Baidu, TempMenu, 1, 0, 1); //�ٶ�һ��

    TempMenu = MenuAdd("\x8b\xbe\x7f\x6e\x0\x0", NULL, RootMenu, 1, 0, 1); //����
        TempMenu2 = MenuAdd("\x65\x70\x50\x3c\x0\x0", NULL, TempMenu, 1, 0, 1); //��ֵ
            MenuAdd("\x0\x2b\x0\x38\x4f\x4d\x0\x0", M_SetInfo_uint8, TempMenu2, 1, ((AppDatas.InfoType & 0x0001) != 0) ? 1 : 0, 0); //+8λ
            MenuAdd("\x0\xb1\x0\x38\x4f\x4d\x0\x0", M_SetInfo_int8, TempMenu2, 1, ((AppDatas.InfoType & 0x0002) != 0) ? 1 : 0, 0); //��8λ
            MenuAdd("\x0\x2b\x0\x31\x0\x36\x4f\x4d\x0\x0", M_SetInfo_uint16, TempMenu2, 1, ((AppDatas.InfoType & 0x0004) != 0) ? 1 : 0, 0); //+16λ
            MenuAdd("\x0\xb1\x0\x31\x0\x36\x4f\x4d\x0\x0", M_SetInfo_int16, TempMenu2, 1, ((AppDatas.InfoType & 0x0008) != 0) ? 1 : 0, 0); //��16λ
            MenuAdd("\x0\x2b\x0\x33\x0\x32\x4f\x4d\x0\x0", M_SetInfo_uint32, TempMenu2, 1, ((AppDatas.InfoType & 0x0010) != 0) ? 1 : 0, 0); //+32λ
            MenuAdd("\x0\xb1\x0\x33\x0\x32\x4f\x4d\x0\x0", M_SetInfo_int32, TempMenu2, 1, ((AppDatas.InfoType & 0x0020) != 0) ? 1 : 0, 0); //��32λ

        TempMenu2 = MenuAdd("\x65\x87\x67\x2c\x0\x0", NULL, TempMenu, 1, 0, 1); //�ı�
            MenuAdd("\x0\x55\x0\x43\x0\x53\x0\x32\x0\x42\x0\x45\x0\x0", M_SetInfo_UCS2BE, TempMenu2, 1, ((AppDatas.InfoType & 0x0040) != 0) ? 1 : 0, 0); //UCS2BE
            MenuAdd("\x0\x55\x0\x43\x0\x53\x0\x32\x0\x4c\x0\x45\x0\x0", M_SetInfo_UCS2LE, TempMenu2, 1, ((AppDatas.InfoType & 0x0080) != 0) ? 1 : 0, 0); //UCS2LE
            MenuAdd("\x0\x47\x0\x42\x0\x32\x0\x33\x0\x31\x0\x32\x0\x0", M_SetInfo_GB2312, TempMenu2, 1, ((AppDatas.InfoType & 0x0100) != 0) ? 1 : 0, 0); //GB2312
            MenuAdd("\x0\x55\x0\x54\x0\x46\x0\x2d\x0\x38\x0\x0", M_SetInfo_UTF8, TempMenu2, 1, ((AppDatas.InfoType & 0x0200) != 0) ? 1 : 0, 0); //UTF-8

        TempMenu2 = MenuAdd("\x5b\x57\x4f\x53\x0\x0", NULL, TempMenu, 1, 0, 1); //����
            MenuAdd("\x5c\xf\x0\x0", M_SetFont_S, TempMenu2, 1, (0 == AppDatas.AppFont) ? 1 : 0, 1); //С
            MenuAdd("\x4e\x2d\x0\x0", M_SetFont_M, TempMenu2, 1, (1 == AppDatas.AppFont) ? 1 : 0, 1); //��
            MenuAdd("\x59\x27\x0\x0", M_SetFont_B, TempMenu2, 1, (2 == AppDatas.AppFont) ? 1 : 0, 1); //��

        TempMenu2 = MenuAdd("\x76\xae\x80\xa4\x0\x0", NULL, TempMenu, 1, 0, 1); //Ƥ��
            MenuAdd("\x6e\x5\x84\xdd\x0\x0", M_SetColor_Blue, TempMenu2, 1, (0 == AppColor.ColorType) ? 1: 0, 0); //����
            MenuAdd("\x91\x77\x9e\xd1\x0\x0", M_SetColor_Black, TempMenu2, 1, (1 == AppColor.ColorType) ? 1: 0, 0); //���

        TempMenu2 = MenuAdd("\x66\xf4\x59\x1a\x0\x0", NULL, TempMenu, 1, 0, 1); //����
            MenuAdd("\x59\x27\x7a\xef\x5b\x57\x5e\x8f\x0\x0", M_SetEndian, TempMenu2, 1, (AppDatas.BigEndian == 0 ? 0 : 1), 0); //�������
            MenuAdd("\x5f\xeb\x63\x77\x83\xdc\x53\x55\x0\x0", M_SetPopMenu, TempMenu2, 1, (AppDatas.PopMenu == 0 ? 0 : 1), 0); //��ݲ˵�
            MenuAdd("\x5e\x38\x75\x28\x76\xee\x5f\x55\x0\x0", M_SetUserDir, TempMenu2, 1, 0, 1); //����Ŀ¼
            //MenuAdd("\x80\xcc\x51\x49\x5e\x38\x4e\xae\x0\x0", M_LightOn, TempMenu2, 1, 0, 1); //���ⳣ��
            //MenuAdd("\x79\x81\x6b\x62\x63\x2\x67\x3a\x0\x0", M_IdleOff, TempMenu2, 1, 0, 1); //��ֹ�һ�

    TempMenu = MenuAdd("\x5e\x2e\x52\xa9\x0\x0", NULL, RootMenu, 1, 0, 1); //����
        //MenuAdd("\x4e\x2a\x4e\xba\x7f\x51\x7a\xd9\x0\x0", M_GotoEles, TempMenu, 1, 0, 1); //������վ
        MenuAdd("\x4f\x7f\x75\x28\x5e\x2e\x52\xa9\x0\x0", M_ShowHelp, TempMenu, 1, 0, 1); //ʹ�ð���
        MenuAdd("\x51\x73\x4e\x8e\x8f\x6f\x4e\xf6\x0\x0", M_ShowAbout, TempMenu, 1, 0, 1); //��������

    TempMenu = MenuAdd("\x90\x0\x51\xfa\x0\x0", M_ExitApp, RootMenu, 1, 0, 1); //�˳�

    ActiveMenu = RootMenu->Child;
}

//���Ӳ˵�
//�������ı����ص����������˵�����Ч����ѡ
//���أ����ӵĲ˵���
PMENU_LINK MenuAdd(char *Title, MENU_CBF CBF, PMENU_LINK Parent, uint8 Enable, uint8 Check, uint8 AutoFold)
{
    PMENU_LINK mla = Parent;
    PMENU_LINK ml = (MENU_LINK*)mrc_malloc(sizeof(MENU_LINK));

    mrc_memset(ml->Title, 0, sizeof(ml->Title));
    mrc_memcpy(ml->Title, Title, mrc_wstrlen(Title));

    ml->Active = Enable;
    ml->Enabled = Enable;
    ml->Checked = Check;
    ml->AutoFold = AutoFold;
    ml->CBF = CBF;
    ml->Next = NULL;
    ml->Child = NULL;
    ml->Children = 0;
    ml->Active = 0;

    if (mla) //�и��˵�
    {
        mla->Children++; //�Ӳ˵���+1
        ml->Index = mla->Children; //���=����
        ml->Parent = mla;

        if (mla->Child) //�����Ӳ˵������ӵ����
        {
            mla = mla->Child;

            //���˵���
            while(NULL != mla->Next)
                mla = mla->Next;

            ml->Before = mla;
            mla->Next = ml;
        }
        else //���Ӳ˵���ֱ������
        {
            ml->Before = NULL;
            mla->Child = ml;
        }
    }
    else //�޸��˵�
    {
        ml->Index = 1;
        ml->Before = NULL;
        ml->Parent = NULL;
    }

    return ml;
}

//��ʾĳ���˵�
//���������˵����ɻ��Ʒ�Χ��λ����Ϣ��x-��,y-��,h-��,w-����
void MenuDraw(PMENU_LINK mParent, mr_screenRectSt rectCanDraw, mr_screenRectSt *rectMenu)
{
    PMENU_LINK aMenu;
    mr_screenRectSt rectDraw, rectCheck, rectText, rectSub;
    int32 fw, fh, mfw = 0;
    int16 wChange;
    uint8 HaveCheck = 0, HaveChild = 0;
    uint8 dColor = 0;

    if (NULL == mParent)
        return;

    aMenu = mParent->Child;

    while(aMenu) //�����˵����������Ʋ���
    {
        mrc_unicodeTextWidthHeight((uint16*)aMenu->Title, AppDatas.AppFont, &fw, &fh);
        if (aMenu->Checked) HaveCheck = 1;
        if (aMenu->Child) HaveChild = 1;
        if (fw > mfw) mfw = fw;
        aMenu = aMenu->Next;
    }

    if (rectMenu->y + rectMenu->h > rectCanDraw.y + rectCanDraw.h - 1)
    {
        rectMenu->y = rectCanDraw.y + rectCanDraw.h - rectMenu->h - 1;
    }

    rectDraw.x = rectMenu->x + 2;
    rectDraw.y = rectMenu->y + 2;
    rectDraw.h = (rectMenu->h - 4) / mParent->Children;
    rectDraw.w = (uint16)(mfw + 8);

    rectText.x = rectDraw.x + 1;
    rectText.y = rectDraw.y + 1;
    rectText.h = rectDraw.h;
    rectText.w = rectDraw.w - 2;

    if (HaveCheck) //�и�ѡ
    {
        rectCheck.w = 8;
        rectCheck.x = rectText.x;
        rectCheck.h = rectDraw.h;
        rectText.x += rectCheck.w;
        rectDraw.w += rectCheck.w;
    }

    if (HaveChild) //���Ӳ˵�
    {
        rectSub.w = 8;
        rectSub.x = rectText.x + rectText.w;
        rectSub.h = rectDraw.h;
        rectDraw.w += rectSub.w;
    }

    rectMenu->w = rectDraw.w + 4;

    if (rectMenu->x + rectMenu->w > rectCanDraw.x + rectCanDraw.w)
    {
        wChange = rectCanDraw.x + rectCanDraw.w - rectMenu->w - rectMenu->x;
        rectMenu->x += wChange;
        rectDraw.x += wChange;
        rectText.x += wChange;
        if (HaveCheck)
            rectCheck.x += wChange;
        if (HaveChild)
            rectSub.x += wChange;
    }

    //�˵��߿�
    DrawFillRect(*rectMenu, AppColor.backColor);
    DrawRoundRect(*rectMenu);

    aMenu = mParent->Child;

    while(aMenu)
    {
        rectCheck.y = rectDraw.y;
        rectText.y = rectDraw.y;
        rectSub.y = rectDraw.y;

        //���Ʋ˵����
        if (0 != aMenu->Active && 0 != aMenu->Enabled) //�
        {
            DrawShadeRect(rectDraw);
        }

        //������
        dColor = (0 == aMenu->Enabled) ? (uint8)(AppColor.unableColor & 0xff) : (uint8)(AppColor.textdColor & 0xff);

        //���Ʋ˵�����
        DrawTextMid(rectText, aMenu->Title, ((0 == aMenu->Enabled) ? AppColor.unableColor : AppColor.textdColor));

        if (aMenu->Checked) //���Ƹ�ѡ��
        {
            mrc_drawLine(rectCheck.x + 1, rectCheck.y + rectCheck.h / 2 - 2, rectCheck.x + 1, rectCheck.y + rectCheck.h / 2 + 1, dColor, dColor, dColor);
            mrc_drawLine(rectCheck.x + 2, rectCheck.y + rectCheck.h / 2 - 1, rectCheck.x + 2, rectCheck.y + rectCheck.h / 2 + 2, dColor, dColor, dColor);
            mrc_drawLine(rectCheck.x + 3, rectCheck.y + rectCheck.h / 2 - 0, rectCheck.x + 3, rectCheck.y + rectCheck.h / 2 + 3, dColor, dColor, dColor);
            mrc_drawLine(rectCheck.x + 4, rectCheck.y + rectCheck.h / 2 - 1, rectCheck.x + 4, rectCheck.y + rectCheck.h / 2 + 2, dColor, dColor, dColor);
            mrc_drawLine(rectCheck.x + 5, rectCheck.y + rectCheck.h / 2 - 2, rectCheck.x + 5, rectCheck.y + rectCheck.h / 2 + 1, dColor, dColor, dColor);
            mrc_drawLine(rectCheck.x + 6, rectCheck.y + rectCheck.h / 2 - 3, rectCheck.x + 6, rectCheck.y + rectCheck.h / 2 - 0, dColor, dColor, dColor);
            mrc_drawLine(rectCheck.x + 7, rectCheck.y + rectCheck.h / 2 - 4, rectCheck.x + 7, rectCheck.y + rectCheck.h / 2 - 1, dColor, dColor, dColor);
        }

        if (aMenu->Child) //�����¼��˵���ͷ
        {
            mrc_drawLine(rectSub.x + 1, rectSub.y + rectSub.h / 2 - 5, rectSub.x + 1, rectSub.y + rectSub.h / 2 + 4, dColor, dColor, dColor);
            mrc_drawLine(rectSub.x + 2, rectSub.y + rectSub.h / 2 - 4, rectSub.x + 2, rectSub.y + rectSub.h / 2 + 3, dColor, dColor, dColor);
            mrc_drawLine(rectSub.x + 3, rectSub.y + rectSub.h / 2 - 3, rectSub.x + 3, rectSub.y + rectSub.h / 2 + 2, dColor, dColor, dColor);
            mrc_drawLine(rectSub.x + 4, rectSub.y + rectSub.h / 2 - 2, rectSub.x + 4, rectSub.y + rectSub.h / 2 + 1, dColor, dColor, dColor);
            mrc_drawLine(rectSub.x + 5, rectSub.y + rectSub.h / 2 - 1, rectSub.x + 5, rectSub.y + rectSub.h / 2 + 0, dColor, dColor, dColor);
        }

        aMenu = aMenu->Next;
        rectDraw.y += rectDraw.h;
    }

    //mrc_refreshScreen(rectMenu->x, rectMenu->y, rectMenu->w, rectMenu->h);
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
//��ʾ���˵�
void ShowMenu(int16 x, int16 y, int16 w, int16 h)
{
    if (NULL == RootMenu)
        InitMenuItem();

    if (0 == AppDatas.HDatas[AppDatas.HIndex].FileSize)
    {
        SetMenuEnabled(1, 0, 0, 0);
        SetMenuEnabled(2, 1, 0, 1);
        SetMenuEnabled(2, 2, 0, 0);
        SetMenuEnabled(2, 3, 0, 0);
    }
    else
    {
        SetMenuEnabled(1, 0, 0, 1);
        SetMenuEnabled(2, 1, 0, 0);
        SetMenuEnabled(2, 2, 0, 1);
        SetMenuEnabled(2, 3, 0, 1);
    }

    rectSpace.x = x + 1;
    rectSpace.y = y;
    rectSpace.w = w - 2;
    rectSpace.h = h;

    rectMenus[0].x = 1;
    rectMenus[0].y = rectSpace.y + rectSpace.h - RootMenu->Children * ItemHeight - 5;
    rectMenus[0].w = 0;
    rectMenus[0].h = 0;

    MenuLayer = 0;
    MenuExpand(RootMenu, 0);
    DrawAllMenu(1, 0);
}

//�ݹ�����˵�����Ӳ˵�
void MenuDelEx(PMENU_LINK fMenu)
{
    PMENU_LINK ml = fMenu, p1;

    while (NULL != ml)
    {
        if (NULL != ml->Child)
            MenuDelEx(ml->Child);
        p1 = ml->Next;
        mrc_free(ml);
        ml = p1;
    }
}

//������в˵�
void MenuDestroy(void)
{
    MenuDelEx(RootMenu);
}

//�ػ����в˵�
void DrawAllMenu(uint8 DrawBack, uint8 Refresh)
{
    PMENU_LINK mp = ActiveMenu;
    PMENU_LINK dm[4] = {NULL, NULL, NULL, NULL};
    int16 i;

    if (NULL == mp)
        return;

    if (DrawBack > 0)
    {
        DrawFillRect(rectSpace, AppColor.backColor);
        DrawHex(1, 0);
        DrawInfo(0);
    }

    //׷�ݸ��˵�
    for(i = MenuLayer; i > 0; i--)
    {
        if (mp)
            mp = mp->Parent;
        dm[i] = mp;
    }

    //����ÿ���˵�
    for(i = 1; i <= MenuLayer; i++)
    {
        MenuDraw(dm[i], rectSpace, &rectMenus[i]);
    }

    if (Refresh > 0)
        RefreshRect(rectSpace);
}

//չ���˵�
void MenuExpand(PMENU_LINK mParent, uint8 Refresh)
{
    if(NULL == mParent || NULL == mParent->Child)
        return;
    
    rectMenus[MenuLayer + 1].x = rectMenus[MenuLayer].x + rectMenus[MenuLayer].w;
    rectMenus[MenuLayer + 1].y = rectMenus[MenuLayer].y + (mParent->Index - 1) * ItemHeight;
    rectMenus[MenuLayer + 1].w = 0;
    rectMenus[MenuLayer + 1].h = mParent->Children * ItemHeight + 4;
    MenuLayer++;

    ActiveMenu = mParent->Child;

    while(ActiveMenu->Next)
    {
        if (ActiveMenu->Enabled)
            break;
        ActiveMenu = ActiveMenu->Next;
    }

    if (ActiveMenu)
        ActiveMenu->Active = 1;

    DrawAllMenu(0, Refresh);
}

//�۵��˵�
void MenuFold(PMENU_LINK Menu, uint8 Refresh)
{
    if (NULL == Menu)
        return;

    MenuLayer--;
    Menu->Active = 0;
    ActiveMenu = Menu->Parent;

    if (ActiveMenu == RootMenu)
    {
        ChangeAppState(APPSTATE_NORMAL, 1);
    }
    else
    {
        DrawAllMenu(1, Refresh);
    }
}

//�ݹ��۵������Ӳ˵�
void MenuFoldEx(PMENU_LINK fMenu)
{
    PMENU_LINK ml = fMenu;

    while (ml)
    {
        if (NULL != ml->Child)
        {
            MenuFoldEx(ml->Child);
        }
        ml->Active = 0;
        ml = ml->Next;
    }
}

//�۵����в˵�
void MenuFoldAll(void)
{
    MenuFoldEx(RootMenu);
    MenuLayer = 0;
}

//��һ�˵�
void MenuNext(PMENU_LINK Menu, uint8 Refresh)
{
    PMENU_LINK mp = Menu;

    if (NULL == mp)
        return;

    mp->Active = 0;

    do
    {
        mp = mp->Next;
        if(NULL == mp)
            mp = Menu->Parent->Child;
    }while(0 == mp->Enabled);

    mp->Active = 1;
    ActiveMenu = mp;

    DrawAllMenu(0, Refresh);
}

//��һ�˵�
void MenuBefore(PMENU_LINK Menu, uint8 Refresh)
{
    PMENU_LINK mp = Menu;

    if (NULL == mp)
        return;

    mp->Active = 0;

    do
    {
        mp = mp->Before;
        if(NULL == mp)
        {
            mp = Menu->Parent->Child;
            while(mp->Next)
            {
                mp = mp->Next;
            }
        }
    }while(0 == mp->Enabled);

    mp->Active = 1;
    ActiveMenu = mp;

    DrawAllMenu(0, Refresh);
}

//�������ȡ�ò˵���
//���������˵������
PMENU_LINK Index2Menu(PMENU_LINK mParent, uint8 Index)
{
    PMENU_LINK mp;

    if (NULL == mParent)
        return NULL;

    mp = mParent->Child;
    while(mp)
    {
        if(mp->Index == Index)
        {
            return mp;
        }
        mp = mp->Next;
    }

    return NULL;
}

//����ĳЩ�˵��Ƿ�ѡ��
//��������1��˵���ţ���2��˵���ţ���3��˵���ţ��Ƿ�ѡ��
void SetMenuChecked(uint8 Index1, uint8 Index2, uint8 Index3, uint8 IsChecked)
{
    PMENU_LINK mp = NULL, mpl = NULL;

    mp = Index2Menu(RootMenu, Index1);

    if (NULL == mp)
    {
        return;
    }

    mpl = mp;
    mp = Index2Menu(mp, Index2);

    if (NULL == mp)
    {
        mpl->Checked = IsChecked;
        return;
    }

    mpl = mp;
    mp = Index2Menu(mp, Index3);

    if (NULL == mp)
    {
        mpl->Checked = IsChecked;
        return;
    }

    mp->Checked = IsChecked;
}

//����ĳЩ�˵��Ƿ���Ч
//��������1��˵���ţ���2��˵���ţ���3��˵���ţ��Ƿ���Ч
void SetMenuEnabled(uint8 Index1, uint8 Index2, uint8 Index3, uint8 IsEnabled)
{
    PMENU_LINK mp = NULL, mpl = NULL;

    mp = Index2Menu(RootMenu, Index1);

    if (NULL == mp)
        return;

    mpl = mp;
    mp = Index2Menu(mp, Index2);

    if (NULL == mp)
    {
        mpl->Enabled = IsEnabled;
        return;
    }

    mpl = mp;
    mp = Index2Menu(mp, Index3);

    if (NULL == mp)
    {
        mpl->Enabled = IsEnabled;
        return;
    }

    mp->Enabled = IsEnabled;
}

//����ĳ���˵���ָ������Ӳ˵�
//���������˵������
void ActiveMenuByIndex(PMENU_LINK mParent, uint8 Index)
{
    PMENU_LINK mp = NULL;

    mp = Index2Menu(mParent, Index);

    if (NULL != mp && mp->Enabled)
    {
        ActiveMenu->Active = 0;
        ActiveMenu = mp;
        ActiveMenu->Active = 1;
    }
    else
    {
        return;
    }

    MenuLayer = -1;
    while (NULL != mp)
    {
        MenuLayer++;
        mp = mp->Parent;
    }
}

//�ж�ĳ���˵��Ƿ����
//���������˵������
uint8 IsEnabledByIndex(PMENU_LINK mParent, uint8 Index)
{
    PMENU_LINK mp = NULL;

    mp = Index2Menu(mParent, Index);

    if (NULL != mp)
        return mp->Enabled;
    else
        return 0;
}

//��ÿ�����չ���˵�
//��������1��˵���ţ���2��˵���ţ���3��˵���ţ�
void ShowMenuByIndex(uint8 Index1, uint8 Index2, uint8 Index3)
{
    ChangeAppState(APPSTATE_MENU, 0);
    ActiveMenuByIndex(RootMenu, Index1);
    MenuExpand(ActiveMenu, 0);
    ActiveMenuByIndex(ActiveMenu->Parent, Index2);
    MenuExpand(ActiveMenu, 0);
    ActiveMenuByIndex(ActiveMenu->Parent, Index3);
    DrawAllMenu(0, 0);
    RefreshFullScreen();
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
//ģ����������
static void MKeyTimerDo(int32 data)
{
    switch(data)
    {
    case MR_KEY_UP: //��
        MenuBefore(ActiveMenu, 1);
        break;
    case MR_KEY_DOWN: //��
        MenuNext(ActiveMenu, 1);
        break;
    }
}

/*---------------------------------------------------------------------------------------*/
//�˵��¼�����
int32 MenuEvent(int32 code, int32 p0, int32 p1)
{
    int8 i, j;
    PMENU_LINK mp;

    if(ActiveMenu != NULL)
    {
        switch(code)
        {
        case MR_KEY_PRESS://ѡ���˵�
            switch(p0)
            {
            case MR_KEY_UP: //��
                KeyTimerStart(MR_KEY_UP, MKeyTimerDo);
                break;
            case MR_KEY_DOWN: //��
                KeyTimerStart(MR_KEY_DOWN, MKeyTimerDo);
                break;
            case MR_KEY_LEFT: //��
                MenuFold(ActiveMenu, 1);
                break;
            case MR_KEY_RIGHT: //��
                MenuExpand(ActiveMenu, 1);
                break;
            case MR_KEY_SOFTLEFT:
                DrawTool(0, 1, 1);
                break;
            case MR_KEY_SOFTRIGHT:
                DrawTool(0, 2, 1);
                break;
            default:
                if (p0 >= MR_KEY_1 && p0 <= ActiveMenu->Parent->Children) //�����������
                {
                    ActiveMenuByIndex(ActiveMenu->Parent, (uint8)p0);
                    DrawAllMenu(1, 1);
                }
                break;
            }
            break;
        case MR_KEY_RELEASE:
            switch(p0)
            {
            case MR_KEY_UP: //��
                KeyTimerStop();
                break;
            case MR_KEY_DOWN: //��
                KeyTimerStop();
                break;
            case MR_KEY_SOFTLEFT:
                DrawTool(0, 0, 1);
            case MR_KEY_SELECT: //OK
                if(ActiveMenu->Child)
                {
                    MenuExpand(ActiveMenu, 1);
                }
                else
                {
                    if (1 == ActiveMenu->AutoFold)
                    {
                        MenuFoldAll();
                        ChangeAppState(APPSTATE_NORMAL, 1);
                    }

                    if (ActiveMenu->CBF)
                    {
                        (*ActiveMenu->CBF)(); //ִ�лص�
                    }
                }
                break;
            case MR_KEY_SOFTRIGHT: //ȡ��
                DrawTool(0, 0, 1);
                MenuFoldAll();
                ChangeAppState(APPSTATE_NORMAL, 1);
                return 0;
                break;
            case MR_KEY_STAR: //�л�Ƥ��
                ChangeAppColor();
                break;
            default:
                if (p0 >= MR_KEY_1 && p0 <= ActiveMenu->Parent->Children) //�����������
                {
                    MenuEvent(MR_KEY_RELEASE, MR_KEY_SELECT, 0);
                }
                break;
            }
            break;
        case MR_MOUSE_UP: //����̧��
            if (p0 >= rectMenus[MenuLayer].x && p0 < rectMenus[MenuLayer].x + rectMenus[MenuLayer].w && p1 >= rectMenus[MenuLayer].y && p1 < rectMenus[MenuLayer].y + rectMenus[MenuLayer].h)
            {
                if (NULL == ActiveMenu->Child && ActiveMenu->Index == (uint8)((p1 - rectMenus[MenuLayer].y) / ItemHeight + 1)) //�Ǽ���������Ӳ˵�
                {
                    MenuEvent(MR_KEY_RELEASE, MR_KEY_SELECT, 0);
                }
            }
            else //���ǵ�ǰ���˵�
            {
                for(i = MenuLayer - 1; i > 0; i--) //�������в˵�����
                {
                    if (p0 >= rectMenus[i].x && p0 < rectMenus[i].x + rectMenus[i].w && p1 >= rectMenus[i].y && p1 < rectMenus[i].y + rectMenus[i].h)
                        break;
                }

                if (i <= 0) //���ڲ˵������˳��˵�
                {
                    MenuFoldAll();
                    ChangeAppState(APPSTATE_NORMAL, 1);
                }
            }
            break;
        case MR_MOUSE_DOWN: //��������
            mp = ActiveMenu;

            for(i = MenuLayer; i > 0; i--) //�������в˵�����
            {
                if (p0 >= rectMenus[i].x && p0 < rectMenus[i].x + rectMenus[i].w && p1 >= rectMenus[i].y && p1 < rectMenus[i].y + rectMenus[i].h)
                    break;
                mp = mp->Parent;
            }

            if (i > 0) //�ڲ˵�����
            {
                if (0 == IsEnabledByIndex(mp->Parent, (uint8)((p1 - rectMenus[i].y) / ItemHeight + 1))) //��Ч�˵���
                    return 0;

                for(j = MenuLayer; j > i; j--) //ȡ����ǰ�Ľ���
                {
                    ActiveMenu->Active = 0;
                    ActiveMenu = ActiveMenu->Parent;
                }

                ActiveMenuByIndex(mp->Parent, (uint8)((p1 - rectMenus[i].y) / ItemHeight + 1)); //����˵���
                mp = ActiveMenu;

                if (mp->Child && mp->Index == (uint8)((p1 - rectMenus[i].y) / ItemHeight + 1))
                    MenuExpand(mp, 0); //չ���Ӳ˵�

                DrawAllMenu((i == MenuLayer) ? 0 : 1, 1); //�����ͬ���˵��Ͳ�ˢ�±���
            }
            break;
        }
    }

    return 0;
}
