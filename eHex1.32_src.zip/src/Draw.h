#ifndef DRAW_H
#define DRAW_H

/* ������ɫ��RGBֵ */
#define PIXEL888RED(pixel) (uint8)(((pixel) >> 16) & 0xff)
#define PIXEL888GREEN(pixel) (uint8)(((pixel) >> 8) & 0xff)
#define PIXEL888BLUE(pixel) (uint8)((pixel) & 0xff)

typedef struct
{
    uint8 ColorType; //��ɫģʽ
    uint32 lightColor; //��ɫ
    uint32 deepColor; //��ɫ
    uint32 focusColor; //����ɫ
    uint32 backColor; //����ɫ
    uint32 textlColor; //�ı�ɫ-��
    uint32 textdColor; //�ı�ɫ-��
    uint32 unableColor; //������ɫ
} COLORSET;

extern COLORSET AppColor; //��ɫģʽ

void InitColor(uint8 cType);

void DrawFillRect(mr_screenRectSt drawRect, uint32 dColor);
void DrawRoundRect(mr_screenRectSt drawRect);
void DrawShadeRect(mr_screenRectSt drawRect);

void DrawRoundRectEx(int16 x, int16 y, int16 w, int16 h, uint32 ulFrame);
void DrawShadeRectEx(int16 x, int16 y, int16 w, int16 h, uint32 ulLight, uint32 ulDark);

void DrawTextMid(mr_screenRectSt drawRect, char *drawText, uint32 ulColor);
void DrawTextMidLeft(mr_screenRectSt drawRect, char *drawText, uint32 ulColor);
void DrawTextMidRight(mr_screenRectSt drawRect, char *drawText, uint32 ulColor);

void DrawTextMidA(mr_screenRectSt drawRect, char *drawText, uint32 ulColor);
void DrawTextMidLeftA(mr_screenRectSt drawRect, char *drawText, uint32 ulColor);
void DrawTextMidRightA(mr_screenRectSt drawRect, char *drawText, uint32 ulColor);

void DrawCmd(mr_screenRectSt cmdRect, char *Tile, uint8 IsFocus, uint8 IsPress, uint8 Refresh);

#endif