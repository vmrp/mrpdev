#ifndef VCMD_H
#define VCMD_H


void InitVCmd(void);
void ReDrawVCmd(void);

void DoKeyUpHexEdit(int32 KeyCode);
void DoKeyDownHexEdit(int32 KeyCode);
void DoMouseHexEdit(int32 X, int32 Y, uint8 IsMouseDown);

#endif