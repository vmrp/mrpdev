#ifndef FileCmp_h__
#define FileCmp_h__

int32 CompareFile(char *srcPath, char *destPath, char *srcFile, char *destFile, uint32 cmpPos, uint8 cmpMode);

#endif // FileCmp_h__