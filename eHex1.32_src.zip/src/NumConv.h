void NC_Init(void);
void NC_Draw(int32 Refresh);

void NC_Event(int32 type, int32 p1, int32 p2);