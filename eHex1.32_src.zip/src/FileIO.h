#ifndef FileIO_h__
#define FileIO_h__

//ʹ���滻·���ָ�������ļ���������
#define USE_SAFE_PATH_FUNC 

#ifdef USE_SAFE_PATH_FUNC

#define mrc_open mrc_open_s
#define mrc_mkDir mrc_mkDir_s
#define mrc_rmDir mrc_rmDir_s
#define mrc_rename mrc_rename_s
#define mrc_remove mrc_remove_s
#define mrc_fileState mrc_fileState_s
#define mrc_getLen mrc_getLen_s
#define mrc_readAll mrc_readAll_s

int32 mrc_open_s(const char *filename, uint32 mode);
int32 mrc_mkDir_s(const char *name);
int32 mrc_rmDir_s(const char *name);
int32 mrc_rename_s(const char* oldname, const char* newname);
int32 mrc_remove_s(const char* filename);
int32 mrc_fileState_s(const char* filename);
int32 mrc_getLen_s(const char* filename);
void* mrc_readAll_s(const char* filename, uint32 *len);

#endif

#endif // FileIO_h__
