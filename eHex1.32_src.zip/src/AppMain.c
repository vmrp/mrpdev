/*
* �����������ļ�
*/

#include <mrc_base.h>
#include <mrc_exb.h>

#include "AppMain.h"
#include "AppEvent.h"
#include "Functions.h"
#include "MenuFunc.h"
#include "FileView.h"
#include "LocalUI.h"
#include "Draw.h"
#include "Menu.h"
#include "VCmd.h"
#include "NumConv.h"

// �������ýṹ��(������/��ȡ����ʱ��)
typedef struct
{
    uint32 AppVer; //����汾
    uint16 InfoType; //��Ϣ����(��λ����)
    uint8 ColorType; //��ɫģʽ
    uint8 AppFont; //��������
    uint8 BigEndian; //�ֽ���
    uint8 PopMenu; //��ݼ����˵�
    uint8 UserDirLen; //����Ŀ¼����
    uint8 RecentLen; //��ʷ��¼����
} APPSETTING_ST;

// Hex��ʾҳ����Ϣ�ṹ��
typedef struct
{
    //uint16 Font; //�����С
    uint8 Width; //�ַ���
    uint8 Height; //�ַ���
    uint16 ColCount; //����(ÿ���ֽ���)
    uint16 LineCount; //����
    uint16 CharCount; //ÿҳ�ֽ���
} PAGEINFO_ST;

static const uint8 HexS[] = "0123456789ABCDEF"; //Hex��׼�ַ���
static const int32 DataBufferSize = 16 * 1024; //���ݻ�������С
static const int32 HexBufferSize = 32 * 1024; //Hex�ַ���������С

static APPSTATE AppState; //����״̬
static PAGEINFO_ST PageInfo; //Hex�ַ���Ϣ
static POSXY_ST PosMap[64][64]; //����Hex�ַ�λ��
static char InfoBuffers[10][64]; //��ʾ��Ϣ������

mr_screenRectSt rectTitle, rectTool; //��������������
mr_screenRectSt rectMain, rectInfo; //����ʾ������Ϣ��
mr_screenRectSt rectTCmd1, rectTCmd2; //��������ť

static int32 TimeTimerHandle; //ʱ����ʾ��ʱ��
static mr_datetime NowTime; //��ǰʱ��

APPDATAS_ST AppDatas; //��������ȫ������

void DrawTitleMain(uint8 Refresh);

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
//��ʼ��
void MainInit(void)
{
    //����ͼ��
    mrc_bitmapLoad(0, "fvicons.bmp", 0, 0, 16, 80, 16);

    AppDatas.AppId = GetAppId();
    AppDatas.AppVer = GetAppVer();

    ReadAppSet();
    AppState = APPSTATE_NORMAL;

    AppDatas.HDatas[0].DataBuffer = (uint8*)mrc_malloc(DataBufferSize + 32); //�Ӵ�㣬�����ڴ�Խ��
    AppDatas.HDatas[0].HexBuffer = (uint8*)mrc_malloc(HexBufferSize + 64);
    mrc_memset(AppDatas.HDatas[0].DataBuffer, 0, DataBufferSize + 32);
    mrc_memset(AppDatas.HDatas[0].HexBuffer, 0, HexBufferSize + 64);

    AppDatas.HDatas[1].DataBuffer = (uint8*)mrc_malloc(DataBufferSize + 32); //�Ӵ�㣬�����ڴ�Խ��
    AppDatas.HDatas[1].HexBuffer = (uint8*)mrc_malloc(HexBufferSize + 64);
    mrc_memset(AppDatas.HDatas[1].DataBuffer, 0, DataBufferSize + 32);
    mrc_memset(AppDatas.HDatas[1].HexBuffer, 0, HexBufferSize + 64);

    AppDatas.HDatas[AppDatas.HIndex].CurPos.X = 0; AppDatas.HDatas[AppDatas.HIndex].CurPos.Y = 0;

    InitColor(AppColor.ColorType);
    InitForm();
    InitPosMap();
    InitVCmd();
    InitMenuRect();
    InitMenuItem();
    FV_Init();
    NC_Init();

    StartShowTime();
}

//�������
void MainEnd(void)
{
    ShowMsg("\x6b\x63\x57\x28\x90\x0\x51\xfa\x20\x26\x20\x26\x0\x0", 0); //�����˳�����
    mrc_refreshScreen(0, 0, (uint16)AppDatas.ScnInfo.width, (uint16)AppDatas.ScnInfo.height);

    StopShowTime();
    MenuDestroy();
    FV_End();

    TRYFREE(AppDatas.HDatas[0].DataBuffer);
    TRYFREE(AppDatas.HDatas[0].HexBuffer);
    TRYFREE(AppDatas.HDatas[1].DataBuffer);
    TRYFREE(AppDatas.HDatas[1].HexBuffer);

    mrc_bitmapLoad(0, "*", 0, 0, 0, 0, 0);
    WriteAppSet();
}

//��ʼ��������
void InitForm(void)
{
    int32 fw, fh;
    uint16 scnWidth, scnHeight;
    uint16 cmdWidth, cmdHeight;

    mrc_getScreenInfo(&AppDatas.ScnInfo); //��ȡ��Ļ�ߴ���Ϣ
    mrc_unicodeTextWidthHeight((uint16*)"\x65\x87\x67\x2c\x0\x0", AppDatas.AppFont, &fw, &fh); //"�ı�"

    //�趨����
    scnWidth = (uint16)AppDatas.ScnInfo.width;
    scnHeight = (uint16)AppDatas.ScnInfo.height;
    cmdWidth = (uint16)(fw + 8);
    cmdHeight = (uint16)(fh + 4);

    //�趨������Ϣ
    rectTitle.x = 0; rectTitle.y = 0; rectTitle.w = scnWidth; rectTitle.h = cmdHeight;
    rectInfo.x = 0; rectInfo.y = scnHeight - cmdHeight * (AppDatas.InfoCount + 1) - 1; rectInfo.w = scnWidth; rectInfo.h = cmdHeight * AppDatas.InfoCount;
	rectMain.x = 0; rectMain.y = cmdHeight + 1; rectMain.w = scnWidth; rectMain.h = rectInfo.y - rectMain.y - 1;
    rectTool.x = 0; rectTool.y = scnHeight - cmdHeight; rectTool.w = scnWidth; rectTool.h = cmdHeight;
	rectTCmd1.x = 0; rectTCmd1.y = rectTool.y; rectTCmd1.w = cmdWidth; rectTCmd1.h = rectTool.h;
	rectTCmd2.x = scnWidth - cmdWidth; rectTCmd2.y = rectTool.y; rectTCmd2.w = cmdWidth; rectTCmd2.h = rectTool.h;
}

//��ʼ�������ַ�λ��
void InitPosMap(void)
{
    int16 i, j;
    uint8 uniChar[4] = {0};
    int32 fw, fh, mfw = 0, mfh = 0;

    //���㵥��Hex�ַ���������
    for(i = 0; i < 16; i++) 
    {
        uniChar[1] = HexS[i];
        mrc_unicodeTextWidthHeight((uint16*)uniChar, AppDatas.AppFont, &fw, &fh);
        if (fw > mfw) mfw = fw;
        if (fh > mfh) mfh = fh;
    }

    PageInfo.Width = (uint8)mfw;
    PageInfo.Height = (uint8)mfh;
    PageInfo.ColCount = (rectMain.w - 4) / (PageInfo.Width * 2 + PageInfo.Width / 2 + 1); 
    PageInfo.LineCount = (rectMain.h - 4) / (PageInfo.Height + 1);
    PageInfo.CharCount = PageInfo.ColCount * PageInfo.LineCount;

    //����ÿ���ַ���λ����Ϣ
    for(i = 0; i < 64; i++)
    {
        for(j = 0; j <= PageInfo.ColCount * 2; j++)
        {
            PosMap[i][j].X = rectMain.x + 2 + (j / 2) * (PageInfo.Width * 2 + PageInfo.Width / 2 + 1) + (j % 2) * (PageInfo.Width + 1);
            PosMap[i][j].Y = rectMain.y + 2 + i * (PageInfo.Height + 1);
        }
    }
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
//�ı����״̬
void ChangeAppState(APPSTATE NewState, uint8 Refresh)
{
    AppState = NewState;

    switch(AppState)
    {
    case APPSTATE_NORMAL:
        break;
    case APPSTATE_HEXEDIT:
        if (AppDatas.HDatas[AppDatas.HIndex].DataBufferUsed < AppDatas.HDatas[AppDatas.HIndex].DataBufferOffset)
        {
            AppState = APPSTATE_NORMAL;
        }
        break;
    case APPSTATE_MENU:
        ShowMenu(rectMain.x, rectMain.y, rectMain.w, rectMain.h + rectInfo.h + 1);
        DrawTool(0, 0, Refresh);
        DrawAllMenu(0, Refresh);
        return;
        break;
    case APPSTATE_SET:
        break;
    case APPSTATE_MSG:
        break;
    case APPSTATE_FILEVIEW:
        break;
    case APPSTATE_LOCALUI:
        return;
        break;
    case APPSTATE_BACKRUN:
        return;
        break;
    case APPSTATE_NUMCONV:
        break;
    default:
        return;
    }
    
    DrawMainForm(Refresh);
}

//���������ڣ��������Ƿ�ˢ��
void DrawMainForm(uint8 Refresh)
{
	mrc_clearScreen((AppColor.backColor >> 16) & 0xff, (AppColor.backColor >> 8) & 0xff, AppColor.backColor & 0xff);

    switch(AppState)
    {
    case APPSTATE_NORMAL:
        DrawTitleMain(0);
        DrawInfo(0);
        DrawTool(1, 0, 0);
        DrawHex(1, 0);
        break;
    case APPSTATE_HEXEDIT:
        DrawTitleMain(0);
        DrawInfo(0);
        DrawTool(0, 0, 0);
        DrawHex(1, 0);
        ReDrawVCmd();
        break;
    case APPSTATE_MENU:
        DrawTitleMain(0);
        DrawHex(1, 0);
        DrawInfo(0);
        DrawTool(0, 0, 0);
        DrawAllMenu(0, 0);
        break;
    case APPSTATE_SET:
        break;
    case APPSTATE_MSG:
        DrawTitleMain(0);
        DrawHex(1, 0);
        DrawInfo(0);
        DrawTool(0, 0, 0);
        break;
    case APPSTATE_FILEVIEW:
        FV_Draw(0);
        break;
    case APPSTATE_LOCALUI:
        return;
    case APPSTATE_NUMCONV:
        NC_Draw(0);
        break;
    /*case APPSTATE_ADVSHOW:
        break;*/
    }

	if (Refresh > 0)
        RefreshFullScreen();
}

//��ʾʱ��
void DrawTime(uint8 Refresh)
{
    mr_screenRectSt tRect;
    char TimeStr[8] = {0};
    int32 fw, fh;

    mrc_sprintf(TimeStr, "%2d:%02d", NowTime.hour, NowTime.minute);
    mrc_unicodeTextWidthHeight((uint16*)"\x0\x30\x0\x30\x0\x3a\x0\x30\x0\x30\x0\x0", AppDatas.AppFont, &fw, &fh);
    tRect.w = (uint16)fw;
    mrc_unicodeTextWidthHeight((uint16*)"\x65\x87\x67\x2c\x0\x0", AppDatas.AppFont, &fw, &fh);
    tRect.h = (uint16)fh + 2;
    tRect.x = (uint16)AppDatas.ScnInfo.width - tRect.w - 2; tRect.y = 1;
    DrawShadeRect(tRect);
    DrawTextMidRightA(tRect, TimeStr, 0x00ffffff);

    if (Refresh > 0)
        RefreshRect(tRect);
}

//���Ʊ�����
void DrawTitle(char* Title, uint8 Refresh)
{
    mr_screenRectSt tRect;
    int32 fw, fh;

    DrawShadeRect(rectTitle);
    DrawRoundRect(rectTitle);
    DrawTime(0);
    mrc_unicodeTextWidthHeight((uint16*)"\x0\x30\x0\x30\x0\x3a\x0\x30\x0\x30\x0\x0", AppDatas.AppFont, &fw, &fh); //00:00
    tRect.x = rectTitle.x; tRect.y = rectTitle.y; tRect.h = rectTitle.h; tRect.w = rectTitle.w - (uint16)fw - 2;
    DrawTextMidLeft(tRect, Title, 0x00ffffff);

    if (Refresh > 0)
        RefreshRect(rectTitle);
}

void DrawTitleMain(uint8 Refresh)
{
    if (AppDatas.HDatas[AppDatas.HIndex].FileSize > 0)
    {
        DrawTitle(AppDatas.HDatas[AppDatas.HIndex].FileNameW, Refresh);
    }
    else
    {
        // ����1-eHex
        char title[] = "\x7a\x97\x53\xe3\x0\x31\x0\x2d\x0\x65\x0\x48\x0\x65\x0\x78\x0\x0";

        title[5] += (char)AppDatas.HIndex;
        DrawTitle(title, Refresh);
    }
}

//���Ƶײ�������
//���������ͣ�0 - ȷ��/ȡ����1 - �˵�
//      ״̬��0 - ��ͨ��1 - ��������2 - ������
void DrawTool(uint8 Type, uint8 State, uint8 Refresh)
{
    mr_screenRectSt tRect;
    char tOffset[16] = {0};

    DrawCmd(rectTool, "\x0\x0", 0, 0, 0);

    tRect.x = rectTCmd1.x + (1 == State ? 1 : 0); tRect.y = rectTCmd1.y + (1 == State ? 1 : 0); tRect.w = rectTCmd1.w; tRect.h = rectTCmd1.h;
    DrawTextMid(tRect, (0 == Type) ? "\x78\x6e\x5b\x9a\x0\x0" : "\x83\xdc\x53\x55\x0\x0", 0x00ffffff);

    tRect.x = rectTCmd2.x + (2 == State ? 1 : 0); tRect.y = rectTCmd2.y + (2 == State ? 1 : 0); tRect.w = rectTCmd2.w; tRect.h = rectTCmd2.h;
    DrawTextMid(tRect, (0 == Type) ? "\x53\xd6\x6d\x88\x0\x0" : "\x52\x7\x63\x62\x0\x0", 0x00ffffff);

    if (AppDatas.HDatas[AppDatas.HIndex].FileSize > 0 && (APPSTATE_FILEVIEW != AppState && APPSTATE_NUMCONV != AppState))
    {
        mrc_sprintf(tOffset, "[%d]", AppDatas.HDatas[AppDatas.HIndex].FileReadBegin + AppDatas.HDatas[AppDatas.HIndex].DataBufferOffset);
        DrawTextMidA(rectTool, tOffset, AppColor.focusColor);
    }

    if (Refresh > 0)
        RefreshRect(rectTool);
}

/*--------------------------------------------------------------------------------------------*/
//��ʾHex����
void DrawHex(uint8 ShowFocus, uint8 Refresh)
{
    int32 i, j;
    uint8 hexChars[4] = {0};
    mr_colourSt tColor;
    mr_screenRectSt tRect;

    ColorUL2ST(AppColor.textdColor, &tColor);
    tRect.x = rectMain.x + 2;
    tRect.y = rectMain.y + 2;
    tRect.w = rectMain.w - 4;
    tRect.h = rectMain.h - 4;

    DrawFillRect(rectMain, AppColor.backColor);

    //ѭ�����������ַ�
    for(i = 0; i <= PageInfo.LineCount; i++)
    {
        for(j = 0; j < PageInfo.ColCount * 2; j++)
        {
            hexChars[1] = AppDatas.HDatas[AppDatas.HIndex].HexBuffer[(AppDatas.HDatas[AppDatas.HIndex].DataShowBegin  + i * PageInfo.ColCount) * 2 + j];
            if (0 == hexChars[1]) break;
            mrc_drawChar(hexChars, PosMap[i][j].X, PosMap[i][j].Y, tRect, tColor, AppDatas.AppFont);
        }
    }

    if (ShowFocus > 0)
    {
        if (0 == AppDatas.HDatas[AppDatas.HIndex].CurPos.X % 2 && APPSTATE_HEXEDIT != AppState)
            DrawHexFocus(AppDatas.HDatas[AppDatas.HIndex].CurPos, 3, 0);
        else
            DrawHexFocus(AppDatas.HDatas[AppDatas.HIndex].CurPos, 1, 0);
    }

    DrawRoundRect(rectMain); //���ı���

    if (Refresh > 0)
        RefreshRect(rectMain);
}

//�����ַ�����
//��������Ļλ�ã��ַ����Ƿ񽹵�
void DrawCharFocus(POSXY_ST dPos, uint8 dChar, uint8 IsFocus)
{
    uint8 hexChars[4] = {0};
    mr_colourSt tColor;
    mr_screenRectSt tRect;

    //�����ǰ���ַ�
    tRect.x = dPos.X; tRect.y = dPos.Y; tRect.w = PageInfo.Width; tRect.h = PageInfo.Height;
    DrawFillRect(tRect, AppColor.backColor);

    //�����ַ�
    hexChars[1] = dChar;
    ColorUL2ST((IsFocus > 0) ? AppColor.focusColor : AppColor.textdColor, &tColor);
    mrc_drawChar(hexChars, dPos.X, dPos.Y, rectMain, tColor, AppDatas.AppFont);
}

//����Hex����
//������λ�ã�����ģʽ���Ƿ�ˢ��
void DrawHexFocus(POSXY_ST dPos, uint8 FocusType, uint8 Refresh)
{
    mr_screenRectSt tRect;
    int16 X = dPos.X, Y = dPos.Y;
    PHEX_VIEW_ST data;

    data = &AppDatas.HDatas[AppDatas.HIndex];

    if (data->FileSize <= 0)
        return;

    DrawCharFocus(PosMap[Y][X], data->HexBuffer[(data->DataShowBegin + Y * PageInfo.ColCount) * 2 + X], FocusType & 0x1); //�ַ�1

    if (0 == X % 2)
        DrawCharFocus(PosMap[Y][X + 1], data->HexBuffer[(data->DataShowBegin + Y * PageInfo.ColCount) * 2 + X + 1], FocusType & 0x2); //�ַ�2

    //����
    tRect.x = PosMap[Y][X - X % 2].X - 1; tRect.y = PosMap[Y][X - X % 2].Y - 1; tRect.w = PageInfo.Width * 2 + 3;tRect.h = PageInfo.Height + 2;
    DrawRoundRectEx(tRect.x, tRect.y, tRect.w, tRect.h, (0 == FocusType) ? AppColor.backColor : AppColor.focusColor);

    if (data->FileSize > 0)
    {
        mrc_drawRect(rectMain.x + rectMain.w - 3, rectMain.y + 1, 2, rectMain.h - 2, 
            PIXEL888RED(AppColor.backColor), PIXEL888GREEN(AppColor.backColor), PIXEL888BLUE(AppColor.backColor));

        //�����ȡ���
        mrc_drawRect(rectMain.x + rectMain.w - 3, rectMain.y + 1, 2, (int16)((rectMain.h - 2) * (data->FileReadBegin + data->DataBufferOffset + 1) / data->FileSize), 
             PIXEL888RED(AppColor.deepColor), PIXEL888GREEN(AppColor.deepColor), PIXEL888BLUE(AppColor.deepColor));

        if (Refresh > 0)
            mrc_refreshScreen(rectMain.x + rectMain.w - 3, rectMain.y + 1, 2, rectMain.h - 2);
    }

    if (Refresh > 0)
        RefreshRect(tRect);
}

/*---------------------------------------------------------------------------------------*/
//��ʾ��ǰλ��������Ϣ
void DrawInfo(uint8 Refresh)
{
    uint8 bufCount = 0, infoCount = 0, i = 0;
    uint8 infoTextCode[10] = {0};
    char *infoTextA = NULL, *infoTextW = NULL;
    int32 uSize = 0, errPos = 0;
    uint32 infoNum = 0;
    uint16 infoType = 0;
    mr_colourSt tColor;
    PHEX_VIEW_ST data;
    uint8 *readpos;

    ColorUL2ST(AppColor.textdColor, &tColor);
    DrawFillRect(rectInfo, AppColor.backColor);

    data = &AppDatas.HDatas[AppDatas.HIndex];
    readpos = data->DataBuffer + data->DataBufferOffset;
    infoType = AppDatas.InfoType;
    infoCount = (uint8)AppDatas.InfoCount;

    if (data->FileSize > 0 && infoCount > 0 && infoCount < 11)
    {
        mrc_memset(InfoBuffers, 0, 10 * 64);

        if ((infoType & 0x0001) && bufCount < infoCount) //uint8
        {
            infoNum = *readpos;
            mrc_sprintf(&InfoBuffers[bufCount][0], "+8λ��%d", infoNum); 
            infoTextCode[bufCount] = 0;
            bufCount++;
        }

        if ((infoType & 0x0002) && bufCount < infoCount) //int8
        {
            infoNum = *readpos;
            mrc_sprintf(&InfoBuffers[bufCount][0], "��8λ��%d", (int8)infoNum); 
            infoTextCode[bufCount] = 0;
            bufCount++;
        }

        if ((infoType & 0x0004) && bufCount < infoCount) //uint16
        {
            if (0 == AppDatas.BigEndian)
                infoNum = readLittleEndianUint16(readpos);
            else
                infoNum = readBigEndianUint16(readpos);
            mrc_sprintf(&InfoBuffers[bufCount][0], "+16λ��%d", infoNum); 
            infoTextCode[bufCount] = 0;
            bufCount++;
        }

        if ((infoType & 0x0008) && bufCount < infoCount) //int16
        {
            if (0 == AppDatas.BigEndian)
                infoNum = readLittleEndianUint16(readpos);
            else
                infoNum = readBigEndianUint16(readpos);
            mrc_sprintf(&InfoBuffers[bufCount][0], "��16λ��%d", (int16)infoNum); 
            infoTextCode[bufCount] = 0;
            bufCount++;
        }

        if ((infoType & 0x0010) && bufCount < infoCount) //uint32
        {
            if (0 == AppDatas.BigEndian)
                infoNum = readLittleEndianUint32(readpos);
            else
                infoNum = readBigEndianUint32(readpos);
            mrc_sprintf(&InfoBuffers[bufCount][0], "+32λ��%u", infoNum); 
            infoTextCode[bufCount] = 0;
            bufCount++;
        }

        if ((infoType & 0x0020) && bufCount < infoCount) //int32
        {
            if (0 == AppDatas.BigEndian)
                infoNum = readLittleEndianUint32(readpos);
            else
                infoNum = readBigEndianUint32(readpos);
            mrc_sprintf(&InfoBuffers[bufCount][0], "��32λ��%d", (int32)infoNum); 
            infoTextCode[bufCount] = 0;
            bufCount++;
        }

        if ((infoType & 0x0040) && bufCount < infoCount) //Unicode-B
        {
            mrc_memcpy(&InfoBuffers[bufCount][0], "\x0\x55\x0\x43\x0\x53\x0\x32\x0\x42\x0\x45\xff\x1a\x0\x0", 14);
            mrc_memcpy(&InfoBuffers[bufCount][14], readpos, 16);
            infoTextCode[bufCount] = 1;
            bufCount++;
        }

        if ((infoType & 0x0080) && bufCount < infoCount) //Unicode-L
        {
            mrc_memcpy(&InfoBuffers[bufCount][0], "\x0\x55\x0\x43\x0\x53\x0\x32\x0\x4c\x0\x45\xff\x1a\x0\x0", 14);
            mrc_memcpy(&InfoBuffers[bufCount][14], readpos, 16);
            ExchangeBytes((uint8*)&InfoBuffers[bufCount][14], 16);
            infoTextCode[bufCount] = 1;
            bufCount++;
        }

        if ((infoType & 0x0100) && bufCount < infoCount) //GB2312
        {
            infoTextA = (char*)mrc_malloc(32);
            mrc_memset(infoTextA, 0, 32);
            mrc_memcpy(infoTextA, readpos, 16);

            do{
                infoTextW = (char*)mrc_c2uVM(infoTextA, &errPos, &uSize);
                if (errPos >= 0)
                    infoTextA[errPos] = 0x20;
            }while(NULL == infoTextW);

            mrc_freeFileData(infoTextW, uSize);
            mrc_memcpy(&InfoBuffers[bufCount][0], "GB2312��", 8);
            mrc_memcpy(&InfoBuffers[bufCount][8], infoTextA, 16);
            mrc_free(infoTextA);
            infoTextCode[bufCount] = 0;
            bufCount++;
        }

        if ((infoType & 0x0200) && bufCount < infoCount) //UTF-8
        {
            mrc_memcpy(&InfoBuffers[bufCount][0], "\x0\x55\x0\x54\x0\x46\x0\x2d\x0\x38\xff\x1a\x0\x0", 12);
            infoTextA = (char*)mrc_malloc(32);
            mrc_memset(infoTextA, 0, 32);
            mrc_memcpy(infoTextA, readpos, 18);
            str2wstr(infoTextA, (uint8*)&InfoBuffers[bufCount][12], 36);
            mrc_free(infoTextA);
            infoTextCode[bufCount] = 1;
            bufCount++;
        }

        //��ʾÿ����Ϣ
        for (i = 0; i < infoCount; i++)
        {
            if (infoTextCode[i] == 0)
            {
                infoTextW = (char *)mrc_c2uVM(&InfoBuffers[i][0], NULL, &uSize);
                mrc_drawTextLeft(infoTextW, rectInfo.x + 2, rectInfo.y + 2 + rectInfo.h * i / infoCount, rectInfo, tColor, 0, AppDatas.AppFont);
                mrc_freeFileData(infoTextW, uSize);
            }
            else
            {
                mrc_drawTextLeft(&InfoBuffers[i][0], rectInfo.x + 2, rectInfo.y + 2 + rectInfo.h * i / infoCount, rectInfo, tColor, 0, AppDatas.AppFont);
            }
        }
    }

    DrawRoundRect(rectInfo); //�߿�

    if (Refresh > 0)
        RefreshRect(rectInfo);
}

//��ʾ��ʾ��Ϣ
void ShowMsg(char *sText, uint8 Refresh)
{
    mr_colourSt tColor;

    ChangeAppState(APPSTATE_MSG, 1);

    ColorUL2ST(AppColor.focusColor, &tColor);
    DrawFillRect(rectInfo, AppColor.backColor);
    mrc_drawTextLeft(sText, rectInfo.x + 2, rectInfo.y + 2, rectInfo, tColor, DRAW_TEXT_EX_IS_AUTO_NEWLINE, AppDatas.AppFont);
    DrawRoundRect(rectInfo); //�߿�

    if (Refresh > 0)
        RefreshRect(rectInfo);
}

//ˢ��ȫ��
void RefreshFullScreen(void)
{
    mrc_refreshScreen(0, 0, (uint16)AppDatas.ScnInfo.width, (uint16)AppDatas.ScnInfo.height);
}

//ˢ������
void RefreshRect(mr_screenRectSt fRect)
{
    mrc_refreshScreen(fRect.x, fRect.y, fRect.w, fRect.h);
}

/*--------------------------------------------------------------------------------------*/
//ȡ�õ�ǰ�ļ�ƫ��
int32 GetCurFileOffset(void)
{
    return AppDatas.HDatas[AppDatas.HIndex].FileReadBegin + AppDatas.HDatas[AppDatas.HIndex].DataBufferOffset;
}

//ȡ�õ�ǰ���ݻ�����ƫ��
int32 GetCurDataOffset(void)
{
    return AppDatas.HDatas[AppDatas.HIndex].DataBufferOffset;
}

//ȡ���ļ���С
int32 GetFileSize(void)
{
    return AppDatas.HDatas[AppDatas.HIndex].FileSize;
}

//ȡ�õ�ǰ���λ��
POSXY_ST GetCurPos(void)
{
    return AppDatas.HDatas[AppDatas.HIndex].CurPos;
}

//ȡ�ó���״̬
APPSTATE GetAppState(void)
{
    return AppState;
}

//���ó���״̬
void SetAppState(APPSTATE NewState, uint8 Refresh)
{
    AppState = NewState;
    DrawMainForm(Refresh);
}

/*--------------------------------------------------------------------------------------*/
//��������
void SetAppFont(uint16 NewFont)
{
    AppDatas.AppFont = NewFont;
    InitForm();
    InitPosMap();
    InitVCmd();
    InitMenuRect();
    SetMenuChecked(4, 3, 1, (MR_FONT_SMALL == AppDatas.AppFont) ? 1 : 0);
    SetMenuChecked(4, 3, 2, (MR_FONT_MEDIUM == AppDatas.AppFont) ? 1 : 0);
    SetMenuChecked(4, 3, 3, (MR_FONT_BIG == AppDatas.AppFont) ? 1 : 0);
    FV_Init();

    GotoFilePos(AppDatas.HDatas[AppDatas.HIndex].FileReadBegin + AppDatas.HDatas[AppDatas.HIndex].DataBufferOffset);
    DrawMainForm(1);
    //ChangeAppState(APPSTATE_NORMAL, 1);
}

//������ʾ��Ϣ����
void SetShowInfo(uint16 Index)
{
    uint16 iType;

    AppDatas.InfoType ^= Index;

    //�ж���Ϣ��
    iType = AppDatas.InfoType;
    AppDatas.InfoCount = 0;
    while(iType)
    {
        if (iType & 0x0001)
            AppDatas.InfoCount++;

        iType>>=1;
    }

    if (AppDatas.InfoCount < 2)
        AppDatas.InfoCount = 2;

    InitForm();
    PageInfo.LineCount = (rectMain.h - 4) / (PageInfo.Height + 1);
    PageInfo.CharCount = PageInfo.ColCount * PageInfo.LineCount;

    InitVCmd();
    SetMenuChecked(4, 1, 1, ((AppDatas.InfoType & 0x0001) > 0) ? 1 : 0);
    SetMenuChecked(4, 1, 2, ((AppDatas.InfoType & 0x0002) > 0) ? 1 : 0);
    SetMenuChecked(4, 1, 3, ((AppDatas.InfoType & 0x0004) > 0) ? 1 : 0);
    SetMenuChecked(4, 1, 4, ((AppDatas.InfoType & 0x0008) > 0) ? 1 : 0);
    SetMenuChecked(4, 1, 5, ((AppDatas.InfoType & 0x0010) > 0) ? 1 : 0);
    SetMenuChecked(4, 1, 6, ((AppDatas.InfoType & 0x0020) > 0) ? 1 : 0);
    SetMenuChecked(4, 2, 1, ((AppDatas.InfoType & 0x0040) > 0) ? 1 : 0);
    SetMenuChecked(4, 2, 2, ((AppDatas.InfoType & 0x0080) > 0) ? 1 : 0);
    SetMenuChecked(4, 2, 3, ((AppDatas.InfoType & 0x0100) > 0) ? 1 : 0);
    SetMenuChecked(4, 2, 4, ((AppDatas.InfoType & 0x0200) > 0) ? 1 : 0);

    DrawMainForm(1);
    //ChangeAppState(APPSTATE_NORMAL, 1);
    //GotoFilePos(GetCurFileOffset());
}

//�ı���ɫ����
void ChangeAppColor(void)
{
    if (0 == AppColor.ColorType)
    {
        InitColor(1);
        SetMenuChecked(4, 4, 1, 0);
        SetMenuChecked(4, 4, 2, 1);
    }
    else
    {
        InitColor(0);
        SetMenuChecked(4, 4, 1, 1);
        SetMenuChecked(4, 4, 2, 0);
    }

    DrawMainForm(1);
}

//��ȡ��������
void ReadAppSet(void)
{
    uint16 infoType;
    char *setFile = "eles/eHex/config.cfg";
    APPSETTING_ST appset;

    ReadFile("Z", setFile, 0, (uint8*)&appset, sizeof(appset));
    ReadFile("Z", setFile, sizeof(appset), (uint8*)AppDatas.UserDir, appset.UserDirLen);
    ReadFile("Z", setFile, sizeof(appset) + appset.UserDirLen, (uint8*)AppDatas.Recent, appset.RecentLen);

    //AppDatas.AppVer = appset.AppVer;
    AppDatas.InfoType = appset.InfoType;
    AppDatas.AppFont = appset.AppFont;
    AppColor.ColorType = appset.ColorType;
    AppDatas.BigEndian = appset.BigEndian;
    AppDatas.PopMenu = appset.PopMenu;

    if (AppDatas.InfoType >= 0x4000 || appset.AppVer != AppDatas.AppVer)
    {
        AppDatas.InfoType = 0x0160;
    }

    //�ж���Ϣ��
    infoType = AppDatas.InfoType;
    AppDatas.InfoCount = 0;
    while (0 != infoType)
    {
        if (infoType & 0x0001)
            AppDatas.InfoCount++;

        infoType >>= 1;
    }

    if (AppDatas.InfoCount < 2)
        AppDatas.InfoCount = 2;

    if (AppDatas.AppFont > 2 || appset.AppVer != AppDatas.AppVer)
    {
        AppDatas.AppFont = MR_FONT_MEDIUM;
    }

    if (AppColor.ColorType > 1 || appset.AppVer != AppDatas.AppVer)
    {
        AppColor.ColorType = 0;
    }

    if (AppDatas.PopMenu > 1 || appset.AppVer != AppDatas.AppVer)
    {
        AppDatas.PopMenu = 1;
    }

    if (AppDatas.BigEndian > 1 || appset.AppVer != AppDatas.AppVer)
    {
#ifdef MR_SPREADTRUM_MOD
        AppDatas.BigEndian = 1;
#else
        AppDatas.BigEndian = 0;
#endif
    }

    if (AppDatas.UserDir[0] == '\0' || appset.AppVer != AppDatas.AppVer)
    {
        mrc_memcpy(AppDatas.UserDir, "C:\\", 4);
    }

    if (AppDatas.Recent[0] == '\0' || appset.AppVer != AppDatas.AppVer)
    {
        mrc_memcpy(AppDatas.Recent, "C:\\", 4);
    }
}

//�����������
void WriteAppSet(void)
{
    char *cfgFile = NULL; //"eles/eHex/config.cfg";
    APPSETTING_ST appset;

    cfgFile = (char*)mrc_malloc(128);
    mrc_memset(cfgFile, 0, 128);

    mrc_strcat(cfgFile, "eles");
    if (MR_IS_FILE == mrc_fileState(cfgFile)) //�����ͬ���ļ���Kill
        mrc_remove(cfgFile);
    if (MR_IS_DIR != mrc_fileState(cfgFile)) //������ļ��У�Make
        mrc_mkDir(cfgFile);

    mrc_strcat(cfgFile, "/eHex");
    if (MR_IS_FILE == mrc_fileState(cfgFile)) //�����ͬ���ļ���Kill
        mrc_remove(cfgFile);
    if (MR_IS_DIR != mrc_fileState(cfgFile)) //������ļ��У�Make
        mrc_mkDir(cfgFile);

    appset.AppVer = AppDatas.AppVer;
    appset.InfoType = AppDatas.InfoType;
    appset.AppFont = (uint8)AppDatas.AppFont;
    appset.ColorType = AppColor.ColorType;
    appset.BigEndian = AppDatas.BigEndian;
    appset.PopMenu = AppDatas.PopMenu;
    appset.UserDirLen = mrc_strlen(AppDatas.UserDir) + 1;
    appset.RecentLen = mrc_strlen(AppDatas.Recent) + 1;

    mrc_strcat(cfgFile, "/config.cfg");
    SaveFile("Z", cfgFile, 0, (uint8*)&appset, sizeof(appset));
    SaveFile("Z", cfgFile, sizeof(appset), (uint8*)AppDatas.UserDir, appset.UserDirLen);
    SaveFile("Z", cfgFile, sizeof(appset) + appset.UserDirLen, (uint8*)AppDatas.Recent, appset.RecentLen);
    mrc_free(cfgFile);
}

//����
void SnapScreen(void)
{
    char *picName, *picNameA;
    int32 nLen = 0;

    picName = (char*)mrc_malloc(128);
    mrc_memset(picName, 0, 128);
    nLen = mrc_wstrlen(AppDatas.HDatas[AppDatas.HIndex].FileNameW);
    if (nLen > 0)
    {
        mrc_memcpy(picName, AppDatas.HDatas[AppDatas.HIndex].FileNameW, nLen);
        mrc_memcpy(picName + nLen, "\x0\x2e\x0\x62\x0\x6d\x0\x70\x0\x0", 10); //.bmp
    }
    else
    {
        picNameA = (char*)mrc_malloc(128);
        mrc_memset(picNameA, 0, 128);
        mrc_sprintf(picNameA, "%d%02d%02d%02d%02d%s", NowTime.year, NowTime.month, NowTime.day, NowTime.hour, NowTime.minute, ".bmp");
        GBToUni(picNameA, picName, 128);
        mrc_free(picNameA);
    }
    ShowInput("\x62\x2a\x56\xfe\x65\x87\x4e\xf6\x54\xd\x0\x0", picName, MR_EDIT_ANY, 64, Screen2File); //��ͼ�ļ���
    mrc_free(picName);
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
//���ļ���������·��(GB2312����)
void OpenFile(char *dir, char *name)
{
    PHEX_VIEW_ST data;

    data = &AppDatas.HDatas[AppDatas.HIndex];

    //ΪNULL�ر��ļ�
    if (NULL == name)
    {
        //mrc_memset(data->FileNameA, 0, MAX_FILENAME_LEN_A);
        //mrc_memset(data->FileNameW, 0, MAX_FILENAME_LEN_A * 2);
        mrc_memset(data->DataBuffer, 0, DataBufferSize);
        mrc_memset(data->HexBuffer, 0, HexBufferSize);
        data->FileSize = 0;
        data->FileReadBegin = 0;
        ChangeAppState(APPSTATE_NORMAL, 1);

        return;
    }

    //��¼·��
    mrc_memset(data->FilePath, 0, MAX_PATH_LEN_A);
    mrc_strcpy(data->FilePath, dir);
    mrc_memset(data->FileNameA, 0, MAX_FILENAME_LEN_A);
    mrc_strcpy(data->FileNameA, name);
    GBToUni(name, data->FileNameW, MAX_FILENAME_LEN_A * 2);

    data->FileSize = FileLenInPath(data->FilePath, data->FileNameA);
    if (data->FileSize <= 0)
    {
        OpenFile(NULL, NULL);
        return;
    }

    //��¼��ʷ
    mrc_sprintf(AppDatas.Recent, "%s%s", dir, name);

    //��ʼ��
    data->FileReadBegin = DataBufferSize * 2; //������Ϊ���������Զ�ˢ�»�����
    data->CurPos.X = 0;
    data->CurPos.Y = 0;
    AppState = APPSTATE_NORMAL;
    GotoFilePos(0);
    //ChangeAppState(APPSTATE_NORMAL);
}

//�����޸�����
//������������
void SaveData(uint8 NewValue)
{
    uint8 NewData;
    PHEX_VIEW_ST data;

    data = &AppDatas.HDatas[AppDatas.HIndex];

    if ((data->FileSize <= 0 || data->DataBufferOffset < 0) || (data->DataBufferOffset > data->DataBufferUsed) || (data->DataBufferUsed <= 0))
        return;

    NewData = data->DataBuffer[data->DataBufferOffset];

    if (0 == AppDatas.HDatas[AppDatas.HIndex].CurPos.X % 2)
    {
        NewData = (NewData & 0x0f) + (NewValue<<4);
        data->HexBuffer[data->DataBufferOffset * 2] = HexS[NewValue];
    }
    else
    {
        NewData = (NewData & 0xf0) + NewValue;
        data->HexBuffer[data->DataBufferOffset * 2 + 1] = HexS[NewValue];
    }

    data->DataBuffer[data->DataBufferOffset] = NewData;
    SaveFile(data->FilePath, data->FileNameA, data->FileReadBegin + data->DataBufferOffset, &NewData, 1);

    if (1 == data->CurPos.X % 2)
    {
        GotoFilePos(data->FileReadBegin + data->DataBufferOffset + 1);
    }
    else
    {
        DrawHexFocus(data->CurPos, 2, 1);
        data->CurPos.X++;
    }
}

//�������ݶ�
//�����������ݻ���������������С
void SaveDatas(uint8 dBuffer[], int32 bufSize)
{
    PHEX_VIEW_ST data;

    data = &AppDatas.HDatas[AppDatas.HIndex];

    if (data->DataBufferOffset < 0 || data->DataBufferOffset > data->DataBufferUsed || 0 == data->DataBufferUsed)
        return;

    SaveFile(data->FilePath, data->FileNameA, data->FileReadBegin + data->DataBufferOffset, dBuffer, bufSize);
    data->DataBufferUsed = ReadFile(data->FilePath, data->FileNameA, data->FileReadBegin, data->DataBuffer, DataBufferSize);
    Data2Hex(data->DataBuffer, data->DataBufferUsed, data->HexBuffer, HexBufferSize);
    data->FileSize = FileLenInPath(data->FilePath, data->FileNameA);
}

//ת���ļ���ַ
//������λ��
void GotoFilePos(int32 fPos)
{
    POSXY_ST NewPos;
    int32 OldFileShowBegin;
    PHEX_VIEW_ST data;

    data = &AppDatas.HDatas[AppDatas.HIndex];

    if (fPos < 0)
        fPos = 0;

    if (fPos > data->FileSize - 1)
        fPos = data->FileSize - 1;

    OldFileShowBegin = data->FileReadBegin + data->DataShowBegin;

    if (fPos < data->FileReadBegin + 512 || fPos >  data->FileReadBegin + data->DataBufferUsed - 512) //�ڵ�ǰ��������
    {
        data->DataBufferOffset = (fPos - 1024) % (DataBufferSize - 512 * 3) + 1024;
        if (data->FileReadBegin != fPos - data->DataBufferOffset)
        {
            data->FileReadBegin = fPos - data->DataBufferOffset;
            data->DataBufferUsed = ReadFile(data->FilePath, data->FileNameA, data->FileReadBegin, data->DataBuffer, DataBufferSize);
            Data2Hex(data->DataBuffer, data->DataBufferUsed, data->HexBuffer, HexBufferSize);
        }
    }
    else //�ڵ�ǰ��������
    {
        data->DataBufferOffset = fPos - data->FileReadBegin;
    }

    NewPos.X = (int16)(fPos % PageInfo.ColCount);

    if ((fPos >= OldFileShowBegin) && (fPos - OldFileShowBegin < PageInfo.CharCount)) //���ڵ�ǰҳ
    {
        NewPos.Y = (int16)((fPos - OldFileShowBegin) / PageInfo.ColCount);
    }
    else
    {
        NewPos.Y = AppDatas.HDatas[AppDatas.HIndex].CurPos.Y;
        if (NewPos.Y > PageInfo.LineCount - 1) //���ⳬ��Hex����
            NewPos.Y = PageInfo.LineCount - 1;

        data->DataShowBegin = data->DataBufferOffset - NewPos.Y * PageInfo.ColCount - NewPos.X;

        if (data->DataShowBegin < 0)
        {
            NewPos.X = 0;
            NewPos.Y = 0;
            data->DataShowBegin = 0;
        }
    }

    if (OldFileShowBegin == data->FileReadBegin + data->DataShowBegin) //�����ػ��ַ�
    {
        DrawHexFocus(AppDatas.HDatas[AppDatas.HIndex].CurPos, 0, 0);
        AppDatas.HDatas[AppDatas.HIndex].CurPos.X = NewPos.X * 2;
        AppDatas.HDatas[AppDatas.HIndex].CurPos.Y = NewPos.Y;
        if (APPSTATE_NORMAL == AppState)
            DrawHexFocus(AppDatas.HDatas[AppDatas.HIndex].CurPos, 3, 0);
        else
            DrawHexFocus(AppDatas.HDatas[AppDatas.HIndex].CurPos, 1, 0);
    }
    else
    {
        AppDatas.HDatas[AppDatas.HIndex].CurPos.X = NewPos.X * 2;
        AppDatas.HDatas[AppDatas.HIndex].CurPos.Y = NewPos.Y;
        DrawHex(1, 0);
    }

    if (APPSTATE_NORMAL == AppState)
    {
        DrawInfo(0);
        DrawTool(1, 0, 0);
    }
    else
    {
        DrawTool(0, 0, 0);
    }

    mrc_refreshScreen(0, 0, (uint16)AppDatas.ScnInfo.width, (uint16)AppDatas.ScnInfo.height);
}

//�ı䵱ǰ����ƫ��
//����������
void ChangeDataOffset(int32 KeyCode)
{
    int32 OldFilePos;

    if (AppDatas.HDatas[AppDatas.HIndex].DataBufferUsed <= 0 || AppDatas.HDatas[AppDatas.HIndex].FileSize <=0)
        return;

    OldFilePos = AppDatas.HDatas[AppDatas.HIndex].FileReadBegin + AppDatas.HDatas[AppDatas.HIndex].DataBufferOffset;

    switch (KeyCode)
    {
    case OFFSET_SEEK_LINE_UP: //��
        GotoFilePos(OldFilePos - PageInfo.ColCount);
        break;
    case OFFSET_SEEK_LINE_DOWN: //��
        GotoFilePos(OldFilePos + PageInfo.ColCount);
        break;
    case OFFSET_SEEK_BYTE_LAST: //��
        GotoFilePos(OldFilePos - 1);
        break;
    case OFFSET_SEEK_BYTE_NEXT: //��
        GotoFilePos(OldFilePos + 1);
        break;
    case OFFSET_SEEK_PAGE_UP: //��һҳ
        GotoFilePos(OldFilePos - PageInfo.CharCount);
        break;
    case OFFSET_SEEK_PAGE_DOWN: //��һҳ
        GotoFilePos(OldFilePos + PageInfo.CharCount);
        break;
    case OFFSET_SEEK_BEGIN: //��ͷ
        GotoFilePos(0);
        break;
    case OFFSET_SEEK_END: //ĩβ
        GotoFilePos(AppDatas.HDatas[AppDatas.HIndex].FileSize - 1);
        break;
    }
}

//���ݴ���λ��ȷ������ƫ��
//������λ������
void MousePos2Offset(int32 X, int32 Y)
{
    int16 i;
    POSXY_ST NewPos;

    NewPos.X = 0;
    NewPos.Y = 0;

    //����X����
    for(i = 0; i < PageInfo.ColCount * 2; i++)
    {
        if (X >= PosMap[0][i].X && X < PosMap[0][i + 1].X)
        {
            NewPos.X = i;
            break;
        }
    }

    //����Y����
    for(i = 0; i < PageInfo.LineCount; i++)
    {
        if (Y >= PosMap[i][0].Y && Y < PosMap[i + 1][0].Y)
        {
            NewPos.Y = i;
            break;
        }
    }

    if (AppDatas.HDatas[AppDatas.HIndex].CurPos.X == NewPos.X && AppDatas.HDatas[AppDatas.HIndex].CurPos.Y == NewPos.Y) //�ٴ�ѡ��
    {
        ChangeAppState(APPSTATE_HEXEDIT, 1);
    }
    else if (AppDatas.HDatas[AppDatas.HIndex].FileReadBegin + AppDatas.HDatas[AppDatas.HIndex].DataShowBegin + NewPos.X / 2 + NewPos.Y * PageInfo.ColCount < AppDatas.HDatas[AppDatas.HIndex].FileSize) //�����ݷ�Χ��
    {
        DrawHexFocus(AppDatas.HDatas[AppDatas.HIndex].CurPos, 0, 1);
        AppDatas.HDatas[AppDatas.HIndex].CurPos.X = NewPos.X;
        AppDatas.HDatas[AppDatas.HIndex].CurPos.Y = NewPos.Y;
        AppDatas.HDatas[AppDatas.HIndex].DataBufferOffset = AppDatas.HDatas[AppDatas.HIndex].DataShowBegin + NewPos.X / 2 + NewPos.Y * PageInfo.ColCount;
        DrawHexFocus(AppDatas.HDatas[AppDatas.HIndex].CurPos, 1, 1);
        DrawInfo(1);
        if (APPSTATE_NORMAL == AppState)
            DrawTool(1, 0, 1);
        else
            DrawTool(0, 0, 1);
    }
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
//��ʼ��ʾʱ��
void StartShowTime(void)
{
    mrc_getDatetime(&NowTime);
    TimeTimerHandle = mrc_timerCreate();
    mrc_timerStart(TimeTimerHandle, 500, 0, RefreshTime, 1);
}

//ˢ��ʱ��
void RefreshTime(int32 data)
{
    mr_datetime t_dt;

    mrc_getDatetime(&t_dt);
    if (t_dt.minute != NowTime.minute || t_dt.hour != NowTime.hour)
    {
        mrc_getDatetime(&NowTime);
        if (AppState != APPSTATE_LOCALUI)
        {
            DrawTime(1);
        }
    }
}

//����ʱ����ʾ
void StopShowTime(void)
{
    if (TimeTimerHandle != 0)
    {
        mrc_timerStop(TimeTimerHandle);
        mrc_timerDelete(TimeTimerHandle);
    }
}