#ifndef MENU_H
#define MENU_H

typedef void(*MENU_CBF)(void);

typedef struct Menu //�˵���Ŀ��Ϣ
{
	char Title[16]; //��ʾ����
    uint8 Index; //��ͬ���˵����
	uint8 Active; //�Ƿ�ѡ��
	uint8 Enabled; //�Ƿ����
    uint8 Checked; //�Ƿ�ѡ
    uint8 Children; //�Ӳ˵���
    uint8 AutoFold; //�Ƿ��Զ��رղ˵�
	MENU_CBF CBF; //�ص�����
	struct Menu *Before; //��һ�˵���
	struct Menu *Next; //��һ�˵���
    struct Menu *Parent; //���˵���
	struct Menu *Child; //��һ���Ӳ˵���
}MENU_LINK, *PMENU_LINK;

PMENU_LINK MenuAdd(char *Title, MENU_CBF CBF, PMENU_LINK Parent, uint8 Enable, uint8 Check, uint8 AutoFold);
void MenuDraw(PMENU_LINK mParent, mr_screenRectSt rectCanDraw, mr_screenRectSt *rectMenus);

void InitMenuRect(void);
void InitMenuItem(void);
void MenuDestroy(void);
void MenuFoldAll(void);
void DrawAllMenu(uint8 DrawBack, uint8 Refresh);

void MenuBefore(PMENU_LINK Menu, uint8 Refresh);
void MenuNext(PMENU_LINK Menu, uint8 Refresh);
void MenuExpand(PMENU_LINK mParent, uint8 Refresh);
void MenuFold(PMENU_LINK mParent, uint8 Refresh);

void ShowMenu(int16 x, int16 y, int16 w, int16 h);
int32 MenuEvent(int32 code, int32 p0, int32 p1);

PMENU_LINK Index2Menu(PMENU_LINK mParent, uint8 Index);
void ActiveMenuByIndex(PMENU_LINK mParent, uint8 Index);
void ShowMenuByIndex(uint8 Index1, uint8 Index2, uint8 Index3);
void SetMenuChecked(uint8 Index1, uint8 Index2, uint8 Index3, uint8 IsChecked);
void SetMenuEnabled(uint8 Index1, uint8 Index2, uint8 Index3, uint8 IsEnabled);

#endif