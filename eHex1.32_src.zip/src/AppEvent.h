#ifndef APPEVENT_H
#define APPEVENT_H

void AppKeyWinEvent(int32 type, int32 p1, int32 p2);

#endif