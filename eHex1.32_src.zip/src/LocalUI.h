#ifndef LOCALUI_H
#define LOCALUI_H

typedef void (*INPUT_CB)(char *inputStr);

void ShowInput(char *Title, char *lastText, int32 Type, int32 MaxSize, INPUT_CB cbFunc);
void GetEditText(char sBuffer[], int32 bufSize);
void DestoryEdit(void);

void DoDialogEvent(int32 KeyCode);

#endif