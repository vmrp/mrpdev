#ifndef KEYTIMER_H
#define KEYTIMER_H

void KeyTimerStart(int32 data, mrc_timerCB timercb);
void KeyTimerStop(void);

#endif