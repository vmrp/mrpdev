/************************************************************************/
/* gzip�ļ�ѹ����ѹ                                                     */
/************************************************************************/

#include <mrc_base.h>
#include <mrc_exb.h>

#include "string.h"

#include "..\zlib\zlib.h"
#include "gzip.h"

#define TRYFREE(p) \
    if (NULL != p) \
    { \
         mrc_free(p); \
         p = NULL; \
    }

#define TRYCLOSE(fd) \
    if (0 != fd) \
    { \
        mrc_close(fd); \
        fd = 0; \
    }

typedef struct
{
    int32 ifd; //�����ļ����
    int32 ofd; //����ļ����

    uint32 bufSize; //���ݻ�������С
    uint8 *inBuf; //���뻺����
    uint8 *outBuf; //���������

    z_stream strm; //zlib�ṹ��

    int32 timer; //���ж�ʱ��
    GzCb cb; //���Ȼص�
}GZ_PROCESS_ST;

static GZ_PROCESS_ST GzProcess; //ѹ����ѹ�����Ϣ

/************************************************************************/
/* ��ѹgzip�ļ�����                                                     */
/************************************************************************/

//����ʵ�ʽ�ѹ
static int32 UnGzipDo(void)
{
    int32 ret;

    ret = mrc_read(GzProcess.ifd, GzProcess.inBuf, GzProcess.bufSize);
    if (ret > 0) //�и�������
    {
        GzProcess.strm.avail_in = (uint32)ret;
        GzProcess.strm.next_in = GzProcess.inBuf;

        do { //ѭ��ֱ����ѹ��һ�����뻺����
            GzProcess.strm.avail_out = GzProcess.bufSize;
            GzProcess.strm.next_out = GzProcess.outBuf;
            ret = inflate(&GzProcess.strm, Z_NO_FLUSH);
            mrc_write(GzProcess.ofd, GzProcess.outBuf, GzProcess.bufSize - GzProcess.strm.avail_out);
        } while (0 == GzProcess.strm.avail_out);
    }
    else if (ret == 0)
    {
        ret = Z_STREAM_END;
    }

    return ret;
}

//���м��ʽ��ѹ
static void UnGzipTimerCb(int32 data)
{
    int32 ret, usedtime;

    usedtime = mrc_getUptime();

    do {
        ret = UnGzipDo();

        if (ret == Z_OK)
        {
            (*GzProcess.cb)(GzProcess.strm.total_in, GzProcess.strm.total_out, GZ_RESULT_PROCESSING);
        }
        else
        {
            (*GzProcess.cb)(GzProcess.strm.total_in, GzProcess.strm.total_out, ret > 0 ? GZ_RESULT_END_OK : GZ_RESULT_END_ERROR);
            UnGzipFileStop();
            return;
        }
    } while (mrc_getUptime() - usedtime < 1000); //ÿ��ѹ1s��ͣ50ms�����ⴥ�����Ź�

    mrc_timerStart(GzProcess.timer, 50, 0, UnGzipTimerCb, 0);
}

//������Ŀ���ļ���ԭʼ�ļ������Ȼص�
int32 UnGzipFile(const char *destfile, const char *srcfile, GzCb pscb)
{
    int32 ret;

    //��ʼ������
    mrc_memset(&GzProcess, 0, sizeof(GzProcess));

    GzProcess.strm.zalloc = (alloc_func)0;
    GzProcess.strm.zfree = (free_func)0;
    GzProcess.strm.opaque = (voidpf)0;

    GzProcess.cb = pscb;
    GzProcess.bufSize = 32 * 1024;

    //���ļ�
    GzProcess.ifd = mrc_open(srcfile, MR_FILE_RDONLY);
    GzProcess.ofd = mrc_open(destfile, MR_FILE_RDWR | MR_FILE_CREATE);
    if (0 == GzProcess.ifd || 0 == GzProcess.ofd)
    {
        TRYCLOSE(GzProcess.ifd);
        TRYCLOSE(GzProcess.ofd);

        return GZ_RESULT_END_ERROR;
    }

    //��ʼ����ѹ����
    ret = inflateInit2(&GzProcess.strm, MAX_WBITS + 16);
    if (Z_OK == ret)
    {
        GzProcess.inBuf = (uint8 *)mrc_malloc(GzProcess.bufSize);
        GzProcess.outBuf = (uint8 *)mrc_malloc(GzProcess.bufSize);

        GzProcess.timer = mrc_timerCreate();
        mrc_timerStart(GzProcess.timer, 10, 0, UnGzipTimerCb, 0);

        return GZ_RESULT_PROCESSING;
    }
    else
    {
        TRYCLOSE(GzProcess.ifd);
        TRYCLOSE(GzProcess.ofd);

        return GZ_RESULT_END_ERROR;
    }
}

//ֹͣGzip��ѹ
int32 UnGzipFileStop(void)
{
    int32 ret;

    TRYFREE(GzProcess.inBuf);
    TRYFREE(GzProcess.outBuf);

    TRYCLOSE(GzProcess.ifd);
    TRYCLOSE(GzProcess.ofd);

    if (0 != GzProcess.timer)
    {
        mrc_timerStop(GzProcess.timer);
        mrc_timerDelete(GzProcess.timer);
        GzProcess.timer = 0;
    }

    ret = inflateEnd(&GzProcess.strm);

    return ret;
}

//��ȡgz�ļ���ѹ�ļ���
char *UnGzip_GetOutName(const char *srcfile)
{
    char *name = NULL, *p = NULL;
    int32 fd, slen;
    uint8 flag = 0, buf[3] = {0};

    //���Զ�ȡ�ڲ���������
    fd = mrc_open(srcfile, MR_FILE_RDONLY);
    if (0 != fd)
    {
        mrc_seek(fd, 0, MR_SEEK_SET);
        mrc_read(fd, buf, 2); //gzipͷ
        mrc_seek(fd, 1, MR_SEEK_CUR); //ѹ������
        mrc_read(fd, &flag, 1); //��־λ

        if (31 == buf[0] && 139 == buf[1] && (flag & 0x08) != 0) //��ԭʼ�ļ���
        {
            mrc_seek(fd, 6, MR_SEEK_CUR); //ĳЩ��Ϣ

            if ((flag & 0x04) != 0) //�и�������
            {
                mrc_read(fd, buf, 2);
                slen = readLittleEndianUint16(buf);
                mrc_seek(fd, slen, MR_SEEK_CUR); //��������
            }

            slen = 0;
            while (mrc_read(fd, buf, 1) == 1 && buf[0] != 0)
                slen++;

            name = (char *)mrc_malloc(slen + 1);
            mrc_seek(fd, -(slen + 1), MR_SEEK_CUR);
            mrc_read(fd, name, slen + 1);

            return name;
        }

        mrc_close(fd);
    }

    //��ȡ�ļ���
    p = mrc_strrchr(srcfile, '\\');
    if (NULL == p)
        p = (char*)srcfile;
    else
        p++;

    name = strDup(p);

    //�ı���չ��
    p = mrc_strrchr(name, '.');
    if (NULL != p)
    {
        if (0 == stricmp(p + 1, "tgz"))
        {
            mrc_memcpy(p + 1, "tar", 3);
        }
        else
        {
            *p = '\0';
        }
    }

    return name;
}

/************************************************************************/
/* ѹ��Ϊgzip�ļ�                                                       */
/************************************************************************/

//����ʵ��ѹ��
static int32 GzipDo(void)
{
    int32 ret, flush;

    ret = mrc_read(GzProcess.ifd, GzProcess.inBuf, GzProcess.bufSize);
    if (ret > 0) //�и�������
    {
        GzProcess.strm.avail_in = (uint32)ret;
        GzProcess.strm.next_in = GzProcess.inBuf;
        flush = (GzProcess.strm.avail_in < GzProcess.bufSize) ? Z_FINISH : Z_NO_FLUSH;

        do { //ѭ��ֱ��ѹ����һ�����뻺����
            GzProcess.strm.avail_out = GzProcess.bufSize;
            GzProcess.strm.next_out = GzProcess.outBuf;
            ret = deflate(&GzProcess.strm, flush);
            mrc_write(GzProcess.ofd, GzProcess.outBuf, GzProcess.bufSize - GzProcess.strm.avail_out);
        } while (0 == GzProcess.strm.avail_out);
    }
    else if (ret == 0)
    {
        ret = Z_STREAM_END;
    }

    return ret;
}

//���м��ʽѹ��
static void GzipTimerCb(int32 data)
{
    int32 ret, usedtime;

    usedtime = mrc_getUptime();

    do {
        ret = GzipDo();

        if (ret == Z_OK)
        {
            (*GzProcess.cb)(GzProcess.strm.total_in, GzProcess.strm.total_out, GZ_RESULT_PROCESSING);
        }
        else
        {
            (*GzProcess.cb)(GzProcess.strm.total_in, GzProcess.strm.total_out, ret > 0 ? GZ_RESULT_END_OK : GZ_RESULT_END_ERROR);
            GzipFileStop();
            return;
        }
    } while (mrc_getUptime() - usedtime < 1000); //ÿѹ��1s��ͣ50ms�����ⴥ�����Ź�

    mrc_timerStart(GzProcess.timer, 50, 0, GzipTimerCb, 0);
}

//������Ŀ���ļ���ԭʼ�ļ���ѹ���ʣ����Ȼص�
//���أ�ѹ�����С��-1Ϊʧ��
int32 GzipFile(const char *destfile, const char *srcfile, int32 level, GzCb pscb)
{
    int32 ret;

    //��ʼ������
    mrc_memset(&GzProcess, 0, sizeof(GzProcess));

    GzProcess.strm.zalloc = (alloc_func)0;
    GzProcess.strm.zfree = (free_func)0;
    GzProcess.strm.opaque = (voidpf)0;

    GzProcess.cb = pscb;
    GzProcess.bufSize = 32 * 1024;

    //���ļ�
    GzProcess.ifd = mrc_open(srcfile, MR_FILE_RDONLY);
    GzProcess.ofd = mrc_open(destfile, MR_FILE_RDWR | MR_FILE_CREATE);
    if (0 == GzProcess.ifd || 0 == GzProcess.ofd)
    {
        TRYCLOSE(GzProcess.ifd);
        TRYCLOSE(GzProcess.ofd);

        return GZ_RESULT_END_ERROR;
    }

    //��ʼ��ѹ������
    ret = deflateInit2(&GzProcess.strm, level, Z_DEFLATED, MAX_WBITS + 16, 8, Z_DEFAULT_STRATEGY);
    if (Z_OK == ret)
    {
        GzProcess.inBuf = (uint8 *)mrc_malloc(GzProcess.bufSize);
        GzProcess.outBuf = (uint8 *)mrc_malloc(GzProcess.bufSize);

        GzProcess.timer = mrc_timerCreate();
        mrc_timerStart(GzProcess.timer, 10, 0, GzipTimerCb, 1);

        return GZ_RESULT_PROCESSING;
    }
    else
    {
        TRYCLOSE(GzProcess.ifd);
        TRYCLOSE(GzProcess.ofd);

        return GZ_RESULT_END_ERROR;
    }
}

//ֹͣGzipѹ��
int32 GzipFileStop(void)
{
    int32 ret;

    TRYFREE(GzProcess.inBuf);
    TRYFREE(GzProcess.outBuf);

    TRYCLOSE(GzProcess.ifd);
    TRYCLOSE(GzProcess.ofd);

    if (0 != GzProcess.timer)
    {
        mrc_timerStop(GzProcess.timer);
        mrc_timerDelete(GzProcess.timer);
        GzProcess.timer = 0;
    }

    ret = deflateEnd(&GzProcess.strm);

    return ret;
}