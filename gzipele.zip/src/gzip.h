#ifndef GZIP_H
#define GZIP_H

enum
{
    GZ_RESULT_PROCESSING = 0,
    GZ_RESULT_END_OK,
    GZ_RESULT_END_ERROR
};

typedef void (*GzCb)(int32 TotalIn, int32 TotalOut, int32 Result); //ѹ��/��ѹ���Ȼص�

int32 UnGzipFile(const char *destfile, const char *srcfile, GzCb pscb);
int32 UnGzipFileStop(void);
char *UnGzip_GetOutName(const char *srcfile);

int32 GzipFile(const char *destfile, const char *srcfile, int32 level, GzCb pscb);
int32 GzipFileStop(void);

#endif