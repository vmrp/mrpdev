/*
* ���ļ����� by eleqian
*/

#include "mrc_base.h"
#include "mrc_win.h"

#include <Web.h>
#include <Draw.h>
#include <Functions.h>
#include <EditBox.h>

#define HTTP_BUFFER_SIZE 4096
#define HTTP_HEAD_LEN 1024

#define HTTP_HEADER_FORMAT "%s %s HTTP/1.1\r\n"
#define HTTP_FIELD_HOST "Host: %s\r\n"
#define HTTP_FIELD_RANGE "Range: %s\r\n"
#define HTTP_FIELD_CONTENTLENGTH "Content-Length:"
#define HTTP_FIELD_UA "User-Agent: %s\r\n"
#define HTTP_VALUE_UA "Nokia6681/2.0 (3.10.6) SymbianOS/8.0 Series60/2.6 Profile/MIDP-2.0 Configuration/CLDC-1.1"
#define HTTP_FIELD_ACCEPT "Accept: %s\r\n"
#define HTTP_VALUE_ACCEPT "*/*"
#define HTTP_FIELD_CONTENTTYPE "Content-Type: %s\r\n"
#define HTTP_VALUE_CONTENTTYPE "application/octet-stream"
#define HTTP_FIELD_CONNECTION "Connection: %s\r\n"
#define HTTP_VALUE_CONNECTION_KEEPALIVE "Keep-Alive"
#define HTTP_VALUE_CONNECTION_CLOSED "close"
#define HTTP_FIELD_PROXYCONNECTION "Proxy-Connection: %s\r\n"

typedef int32 (*MR_INIT_NETWORK_CB)(int32 result);
typedef int32 (*MR_GET_HOST_CB)(int32 ip);

mr_screeninfo scnInfo; //��Ļ�ߴ���Ϣ
mr_screenRectSt rectListFile, rectListIndex;
mr_screenRectSt rectUrl, rectMode, rectSavePath;
mr_screenRectSt rectMsg;

int32 FocusIndex;
APPSTATE AppState;

int32 socketHandle, timerHandle;
int32 websiteIP;
int32 usedTime, recvCount, headSize;
uint32 resultSize;
uint16 connectPort;
char RecvBuffer[HTTP_BUFFER_SIZE];
char strHost[128], strUrl[1024], strMode[8];
char strSaveFile[512], strMsg[64];
const char strTempFile[64] = "XDownload\\xDown.tmp";

//
void ChangeAppState(APPSTATE NewState)
{
    AppState = NewState;

    if (APPSTATE_NORMAL == AppState)
    {
        DrawForm();
    }
}

//�趨�ؼ�λ��
void InitRects(void)
{
    uint16 scnWidth, scnHeight;
    uint16 itemWidth, itemHeight;
    int32 fw, fh;

    mrc_getScreenInfo(&scnInfo);//��ȡ��Ļ�ߴ���Ϣ
    mrc_unicodeTextWidthHeight((uint16*)"\x65\x87\x67\x2c", MR_FONT_MEDIUM, &fw, &fh);//"�ı�"
    scnWidth = (uint16)scnInfo.width;
    scnHeight = (uint16)scnInfo.height;
    itemWidth = (uint16)(fw + 4);
    itemHeight = (uint16)(fh + 4);

    rectListFile.x = 0; rectListFile.y = 0; rectListFile.w = scnWidth; rectListFile.h = itemHeight;
    rectListIndex.x = 0; rectListIndex.y = itemHeight + 1; rectListIndex.w = scnWidth; rectListIndex.h = itemHeight;
    rectUrl.x = 0; rectUrl.y = itemHeight * 2 + 2; rectUrl.w = scnWidth; rectUrl.h = scnHeight - itemHeight * 5 - 5;
    rectMode.x = 0; rectMode.y = scnHeight - itemHeight * 3 - 2; rectMode.w = scnWidth; rectMode.h = itemHeight;
    rectSavePath.x = 0; rectSavePath.y = scnHeight - itemHeight * 2 - 1; rectSavePath.w = scnWidth; rectSavePath.h = itemHeight;
    rectMsg.x = 0; rectMsg.y = scnHeight - itemHeight; rectMsg.w = scnWidth; rectMsg.h = itemHeight;
}

mr_screenRectSt Index2Rect(int32 Index)
{
    switch(Index)
    {
    case 0:
        return rectListFile;
        break;
    case 1:
        return rectListIndex;
        break;
    case 2:
        return rectUrl;
        break;
    case 3:
        return rectMode;
        break;
    case 4:
        return rectSavePath;
        break;
    case 5:
        return rectMsg;
        break;
    default:
        return rectMsg;
        break;
    }
}

//���ƴ���
void DrawForm(void)
{
    int32 i;

    mrc_clearScreen(255, 255, 255);

    for (i = 0; i < 6; i++)
    {
        if (i == FocusIndex)
        {
            DrawRoundRect1(Index2Rect(i));
        } 
        else
        {
            DrawRoundRect(Index2Rect(i));
        }
    }

    DrawTextMidLeftA(rectListFile, "<", 0x00000000);
    DrawTextMidA(rectListFile, "���ز���", 0x00000000);
    DrawTextMidRightA(rectListFile, ">", 0x00000000);
    DrawTextMidLeftA(rectListIndex, "<", 0x00000000);
    DrawTextMidA(rectListIndex, "0/3", 0x00000000);
    DrawTextMidRightA(rectListIndex, ">", 0x00000000);
    DrawTextAVM(rectUrl, strUrl, 0x00000000);
    DrawTextMidLeftA(rectMode, "�����:", 0x00000000);
    DrawTextMidRightA(rectMode, strMode, 0x00000000);
    DrawTextMidLeftA(rectSavePath, "����:", 0x00000000);
    DrawTextMidRightA(rectSavePath, strSaveFile, 0x00000000);
    DrawTextMidA(rectMsg, strMsg, 0x00ff0000);

    mrc_refreshScreen(0, 0, (uint16)scnInfo.width, (uint16)scnInfo.height);
}

//��ʾ��Ϣ
void ShowMsg(char *strText)
{
    int32 fHwnd;

    mrc_drawRect(rectMsg.x + 1, rectMsg.y + 1, rectMsg.w - 2, rectMsg.h - 2, 255, 255, 255);
    DrawTextMidA(rectMsg, strText, 0x00ff0000);
    RefreshRect(rectMsg);

    mrc_memset(strMsg, 0, sizeof(strMsg));
    mrc_strcat(strMsg, strText);

    fHwnd = mrc_open("XDownload\\log_msg.txt", MR_FILE_RDWR | MR_FILE_CREATE);
    mrc_seek(fHwnd, 0, MR_SEEK_END);
    mrc_write(fHwnd, strText, mrc_strlen(strText));
    mrc_write(fHwnd, "\xd\xa", 2);
    mrc_close(fHwnd);
}

void InputCb_Url(char *url)
{
    UniToGB(url, strUrl, sizeof(strUrl));
}

void InputCb_Mode(char *mode)
{
    UniToGB(mode, strMode, sizeof(strMode));
}

void InputCb_Save(char *sfile)
{
    UniToGB(sfile, strSaveFile, sizeof(strSaveFile));
}

void DoByFocus(void)
{
    char uniStr[512];

    switch(FocusIndex)
    {
    case 0:
        break;
    case 1:
        break;
    case 2:
        GBToUni(strUrl, uniStr, 512);
        ShowInput("\x8f\x93\x51\x65\x7f\x51\x57\x40\x0\x0", uniStr, MR_EDIT_ANY, 255, InputCb_Url);
        break;
    case 3:
        GBToUni(strMode, uniStr, 512);
        ShowInput("\x63\xa5\x51\x65\x70\xb9\x0\x0", uniStr, MR_EDIT_ANY, 7, InputCb_Mode);
        break;
    case 4:
        GBToUni(strSaveFile, uniStr, 512);
        ShowInput("\x4f\xdd\x5b\x58\x65\x87\x4e\xf6\x0\x0", uniStr, MR_EDIT_ANY, 255, InputCb_Save);
        break;
    case 5:
        StartDownLoad();
        break;
    default:
        break;
    }
}

//�ı�ؼ�����
void ChangeFocus(int32 Action)
{
    DrawRoundRect(Index2Rect(FocusIndex));
    RefreshRect(Index2Rect(FocusIndex));

    if (-1 == Action)
    {
        FocusIndex--;
        if (FocusIndex < 0)
            FocusIndex = 5;
    } 
    else if (-2 == Action)
    {
        FocusIndex++;
        if (FocusIndex > 5)
            FocusIndex = 0;
    }
    else
    {
        FocusIndex = Action;
    }

    DrawRoundRect1(Index2Rect(FocusIndex));
    RefreshRect(Index2Rect(FocusIndex));
}

/************************************************************************/
//��Urlȡ��������
void Url2Host(char *sUrl, char *sHost)
{
    int32 sLen = 0;
    const char *findPos = mrc_strchr(&sUrl[7], '/');

    if (NULL != findPos)
    {
        sLen = findPos - &sUrl[7];
    }
    else
    {
        sLen = mrc_strlen(sUrl) - 7;
    }

    mrc_memcpy(sHost, &sUrl[7], sLen);
    sHost[sLen] = 0;
}

//ȡ����Ӧ����
int32 GetRespondCode(char *httpFile)
{
    int32 fHwnd = 0;
    uint32 resCode = 0;
    char fBuffer[4] = {0};

    fHwnd = mrc_open(httpFile, MR_FILE_RDONLY);
    if (fHwnd > 0)
    {
        mrc_seek(fHwnd, 9, MR_SEEK_SET);
        mrc_read(fHwnd, fBuffer, 3);
        mrc_close(fHwnd);

        resCode = mrc_atoi(fBuffer);
    }

    return resCode;
}

//�ӽ��յ��ļ�ȡ�����ݴ�С
uint32 GetContentLength(char *httpFile)
{
    int32 fHwnd = 0;
    int32 bufSize = 1024 * 4, readSize = 0, findPos = -1;
    uint32 destSize = 0;
    uint8 *fBuffer = NULL;
    char *headType = "\r\nContent-Length:";

    fHwnd = mrc_open(httpFile, MR_FILE_RDONLY);
    if (fHwnd > 0)
    {
        fBuffer = (uint8*)mrc_malloc(bufSize);
        mrc_seek(fHwnd, 0, MR_SEEK_SET);
        readSize = mrc_read(fHwnd, fBuffer, bufSize);
        mrc_close(fHwnd);

        findPos = BM(fBuffer, (uint8*)headType, readSize, mrc_strlen(headType));
        if (findPos >= 0)
        {
            findPos += mrc_strlen(headType);
            destSize = mrc_strtoul((char*)&fBuffer[findPos], NULL, 10);
        }
    }

    return destSize;
}

//�ӽ��յ�������ȡ�ļ�
void ExtractFile(char *srcFile, char *destFile)
{
    int32 srcSize = 0, destSize = 0;
 
    srcSize = mrc_getLen(srcFile);
    destSize = resultSize; //GetContentLength(srcFile);
    CopyFileEx(srcFile, destFile, srcSize - destSize, 0, destSize);

    ShowMsg("��ȡ�ļ���ɣ�");
}

//�������ݻص�
void ReceiveCb(int32 data)
{
    int32 fHwnd;
    int32 recvLen = 0, resCode = 0;

    mrc_memset(RecvBuffer, 0, HTTP_BUFFER_SIZE);
    recvLen = mrc_recv(socketHandle, RecvBuffer, HTTP_BUFFER_SIZE);

    if (0 == recvLen)
    {
        ShowMsg("�ȴ��������ݡ���"); 
        usedTime++;
        if (usedTime > 200)
        {
            ShowMsg("�������ݳ�ʱ��");
            StopDownload();
        }
    }
    else if (MR_FAILED == recvLen)
    {
        ShowMsg("��������ʧ�ܣ�");
        StopDownload();
    }
    else
    {
        ShowMsg("���������С���");
        WLog("���ν������ݴ�С��", recvLen);
        usedTime = 0;
        recvCount += recvLen;
        fHwnd = mrc_open(strTempFile, MR_FILE_RDWR | MR_FILE_CREATE);
        mrc_seek(fHwnd, 0, MR_SEEK_END);
        mrc_write(fHwnd, RecvBuffer, recvLen);
        mrc_close(fHwnd);

        if (0 == resultSize) //�ڽ�������ͷ
        {
            headSize = FindFromFile((char*)strTempFile, 0, (uint8*)"\r\n\r\n", 4);
            if (headSize > 0) //ͷ���������
            {
                headSize += 4;
                WLog("HTTPͷ����С��", headSize);

                resCode = GetRespondCode((char*)strTempFile);
                if (200 != resCode)
                {
                    ShowMsg("���س�����");
                    WLog("��������Ӧ���룺", resCode);
                    StopDownload();
                    return;
                }

                resultSize = GetContentLength((char*)strTempFile); //ʵ�����ݴ�С
                WLog("Ԥ��ʵ�����ݴ�С��", resultSize);
            }
            else
            {
                return;
            }
        }

        if (recvCount == headSize + resultSize) //���ݽ�����
        {
            ShowMsg("����������ɣ�");
            WLog("�ܽ������ݴ�С��", recvCount);
            StopDownload();
            ExtractFile((char*)strTempFile, strSaveFile);
        }
    }
}

//����HTTPͷ
char* Http_FormatHeader(char *strMethod, int32 *headLen)
{
    char *header = NULL;
    char temp[HTTP_HEAD_LEN];

    header = (char*)mrc_malloc(HTTP_HEAD_LEN);
    if(header == NULL)
        return NULL;

    if (NULL != mrc_strchr(&strUrl[7], '/'))
        sprintf(header, HTTP_HEADER_FORMAT, strMethod, mrc_strchr(&strUrl[7], '/')); //����
    else
        sprintf(header, HTTP_HEADER_FORMAT, strMethod, strUrl); //����

    sprintf(temp,HTTP_FIELD_HOST, strHost); //�������Ͷ˿ںţ�80��ʡ�ԣ�
    mrc_strcat(header, temp);
    //sprintf(temp,HTTP_FIELD_UA, HTTP_VALUE_UA); //UA
    //mrc_strcat(header, temp);
    sprintf(temp,HTTP_FIELD_ACCEPT, HTTP_VALUE_ACCEPT); //�������ͣ����У�
    mrc_strcat(header, temp);
    /*sprintf(temp,HTTP_FIELD_CONTENTTYPE, HTTP_VALUE_CONTENTTYPE);
    mrc_strcat(header, temp);*/
    sprintf(temp,HTTP_FIELD_CONNECTION, HTTP_VALUE_CONNECTION_CLOSED); //���ӷ�ʽ���ǳ־����ӣ�
    mrc_strcat(header, temp);
    /*sprintf(temp,HTTP_FIELD_PROXYCONNECTION, HTTP_VALUE_CONNECTION_KEEPALIVE);
    mrc_strcat(header, temp);*/
    mrc_strcat(header, "\r\n"); //������־

    *headLen = strlen(header);
    return header;
}

//������������
void Http_Get(void)
{
    int32 dataLen = 0, sendLen = 0;
    char *datBuf = NULL;

    datBuf = (char*)Http_FormatHeader("GET", &dataLen);
    if(datBuf)
    {
        ShowMsg("�������󡭡�");
        WLog(datBuf, 0);

        do
        {
            sendLen += mrc_send(socketHandle, &datBuf[sendLen], dataLen - sendLen);
            WLog("�ѷ��������С��", sendLen);
        } while (sendLen < dataLen);
        mrc_free(datBuf);

        usedTime = 0;
        recvCount = 0;
        resultSize = 0;
        timerHandle = mrc_timerCreate();
        mrc_timerStart(timerHandle, 100, 0, ReceiveCb, 1);
    }
}

//����״̬��ѯ�ص�
void ConnectCb(int32 data)
{
    int32 conState = mrc_getSocketState(socketHandle);

    switch (conState)
    {
    case MR_WAITING:
        ShowMsg("���ӷ���������");
        usedTime++;

        if (usedTime > 100)
        {
            ShowMsg("���ӷ�������ʱ��");
            StopDownload();
        }
    	break;
    case MR_SUCCESS:
        ShowMsg("���ӳɹ���");
        mrc_timerStop(timerHandle);
        mrc_timerDelete(timerHandle);
        timerHandle = 0;
        Http_Get();
        break;
    case MR_FAILED:
    case MR_IGNORE:
        ShowMsg("����ʧ�ܣ�");
        StopDownload();
        break;
    default:
        break;
    }
}

//��ʼ����
void Connect(void)
{
    char *findPos = NULL;

    socketHandle = mrc_socket(MR_SOCK_STREAM, MR_IPPROTO_TCP); //����Socket

    findPos = (char*)mrc_strchr(strHost, ':');
    if (NULL == findPos)
        connectPort = 80;
    else
        connectPort = (uint16)mrc_strtoul(findPos + 1, NULL, 10);

    WLog("���Ӷ˿ںţ�", connectPort);
    mrc_connect(socketHandle, websiteIP, connectPort, MR_SOCKET_NONBLOCK); //����Socket

    usedTime = 0;
    timerHandle = mrc_timerCreate();
    mrc_timerStart(timerHandle, 200, 0, ConnectCb, 1);
}

//����IP�ص�����
int32 cbGetHost(int32 ip)
{
    switch(ip)
    {
    case MR_FAILED:
        ShowMsg("��ȡIPʧ�ܣ�");
        StopDownload();
        break;
    case MR_WAITING:
        ShowMsg("��ȡIP����");
        break;
    default:
        ShowMsg("��ȡIP�ɹ���");
        websiteIP = ip;
        WLog("IP��1��", (ip >> 24) & 0xff);
        WLog("IP��2��", (ip >> 16) & 0xff);
        WLog("IP��3��", (ip >> 8) & 0xff);
        WLog("IP��4��", ip & 0xff);
        Connect();
        break;
    }

    return 0;
}

//��ʼ���ص�����
int32 cbInitNetwork(int32 result)  
{
    char strName[128] = {0};
    char *findPos = NULL;

    switch(result)
    {
    case MR_SUCCESS:
        ShowMsg("�����ʼ���ɹ���");

        findPos = (char*)mrc_strchr(strHost, ':');
        if (NULL == findPos)
            mrc_strcat(strName, strHost);
        else
            mrc_strncat(strName, strHost, findPos - strHost);

        cbGetHost(mrc_getHostByName(strName, cbGetHost)); //����ַ����IP
        break;
    case MR_FAILED:
        ShowMsg("�����ʼ��ʧ�ܣ�");
        StopDownload();
        break;
    case MR_WAITING:
        ShowMsg("�����ʼ������");
        break;
    default:
        break;
    }

    return 0;
}

//��ʼ���أ���ʼ�����磩
void StartDownLoad(void)
{
    ChangeAppState(APPSTATE_DOWNLOADING);

    if (MR_IS_DIR != mrc_fileState(strTempFile))
        mrc_remove(strTempFile);

    Url2Host(strUrl, strHost);
    cbInitNetwork(mrc_initNetwork(cbInitNetwork, strMode));
}

//��������
void StopDownload(void)
{
    if (timerHandle)
    {
        mrc_timerStop(timerHandle);
        mrc_timerDelete(timerHandle);
        timerHandle = 0;
    }

    if (socketHandle)
    {
        mrc_closeSocket(socketHandle);
        socketHandle = 0;
    }

    mrc_closeNetwork();

    ChangeAppState(APPSTATE_NORMAL);
}

/************************************************************************/

void WapWinWinEvent(int32 data, int32 eventId)
{
	switch (eventId)
	{
	case WIN_EVENT_SHOW:
	case WIN_EVENT_REFRESH:
        DrawForm();
		break;
	case WIN_EVENT_PAUSE:
		break;
	case WIN_EVENT_EXIT:
		break;
	case WIN_EVENT_UPDATE:
		break;
	}
}

void WapKeyWinEvent(int32 data, int32 type, int32 p1, int32 p2)
{
    if (APPSTATE_NORMAL == AppState)
    {
	    if(MR_KEY_RELEASE == type)
	    {
		    switch(p1)
		    {
		    case MR_KEY_SOFTRIGHT:
			    mrc_winClose();
			    mrc_exit();
			    break;
            case MR_KEY_SOFTLEFT:
            case MR_KEY_SELECT:
                DoByFocus();
                break;
            case MR_KEY_UP:
                ChangeFocus(-1);
                break;
            case MR_KEY_DOWN:
                ChangeFocus(-2);
                break;
            case MR_KEY_1:
                mrc_sprintf(strMode, "%s", "cmnet");
                mrc_sprintf(strUrl, "%s", "http://eles.wap.ai/bbs%5Cupload/476924/2011/06/20/476924_0219490h0.jpg");
                mrc_sprintf(strSaveFile, "%s", "XDownload\\test.gif");
                DrawForm();
                break;
            case MR_KEY_2:
                mrc_sprintf(strMode, "%s", "cmmm");
                mrc_sprintf(strUrl, "%s", "http://file.m.shequ.10086.cn:88/getfile/jVwt3t2SEgbrEB6rEgErEgfseGYseBbu4BMveTYue-+S4gbw.jpg");
                mrc_sprintf(strSaveFile, "%s", "XDownload\\test.jpg");
                DrawForm();
                break;
            case MR_KEY_3:
                mrc_sprintf(strMode, "%s", "cmnet");
                mrc_sprintf(strUrl, "%s", "http://wap.baidu.com");
                mrc_sprintf(strSaveFile, "%s", "XDownload\\test.txt");
                DrawForm();
                break;
		    }
	    }
	    else if(MR_MOUSE_UP == type)
	    {
	    }
    }
    else if (APPSTATE_EDITBOX == AppState)
    {
        DoDialogEvent(p1);
    }
    else if (APPSTATE_DOWNLOADING == AppState)
    {
        if(MR_KEY_RELEASE == type)
        {
            switch(p1)
            {
            case MR_KEY_UP:
                ChangeFocus(-1);
                break;
            case MR_KEY_DOWN:
                ChangeFocus(-2);
                break;
            }
        }
        else if(MR_MOUSE_UP == type)
        {
        }
    }
}

//Ӧ�ó�ʼ������
int32 mrc_init(void)
{
    InitRects();
    InitColor(0);

    /*mrc_sprintf(strMode, "%s", "cmnet");
    mrc_sprintf(strUrl, "%s", "http://eles.wap.ai/bbs%5Cupload/476924/2011/06/20/476924_0219490h0.jpg");
    mrc_sprintf(strSaveFile, "%s", "XDownload\\test.gif");*/

    /*mrc_sprintf(strMode, "%s", "cmmm");
    mrc_sprintf(strUrl, "%s", "http://file.m.shequ.10086.cn:88/getfile/jVwt3t2SEgbrEB6rEgErEgfseGYseBbu4BMveTYue-+S4gbw.jpg");
    mrc_sprintf(strSaveFile, "%s", "XDownload\\test.dat");*/

    mrc_sprintf(strUrl, "��1/2/3��ʹ���������ݡ�");

    if (MR_IS_DIR != mrc_fileState("XDownload"))
        mrc_mkDir("XDownload");

	mrc_winInit();
	mrc_winNew(0, WapWinWinEvent, WapKeyWinEvent);

    ShowMsg("��ʼ");

	return MR_SUCCESS;
}

#if 0

//Ӧ�ó�ʼ������
int32 mrc_event(int32 code, int32 param0, int32 param1)
{
	mrc_winEvent(code, param0, param1);
	return MR_SUCCESS;
}

//Ӧ����ͣ����
int32 mrc_pause(void)
{
	return 0;
}

//�ú�����Ӧ�ûָ�����ʱ��mythroadƽ̨���á�
int32 mrc_resume(void)
{
	mrc_winResume();
	return 0;
}

#else

//Ӧ�ó�ʼ������
int32 mrc_appEvent(int32 code, int32 param0, int32 param1)
{
	mrc_winEvent(code, param0, param1);
	return MR_SUCCESS;
}

//Ӧ����ͣ����
int32 mrc_appPause(void)
{
	return 0;
}

//�ú�����Ӧ�ûָ�����ʱ��mythroadƽ̨���á�
int32 mrc_appResume(void)
{
	mrc_winResume();
	return 0;
}

#endif

//�ú�����Ӧ���˳�ʱ��mythroadƽ̨���á�
int32 mrc_exitApp(void)
{
    ShowMsg("�����˳�����");
	return 0;
}