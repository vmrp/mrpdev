#include "i18n.h"
#include "bmp.h"
#include "smp.h"
#include "smp_toolbar.h"


//toolbar private data
typedef struct SMP_ToolbarData
{
	DWORD ids[SMP_TOOLBAR_ITEMCOUNT];
	PCWSTR str[SMP_TOOLBAR_ITEMCOUNT];
	int32 width[SMP_TOOLBAR_ITEMCOUNT];
	int32 height;
}TBDATA, *PTBDATA;

//////////////////////////////////////////////////////////////////////////////////////////////

VOID SMP_Toolbar_SetStrings(HWND hWnd, DWORD left, DWORD mid, DWORD right, BOOL redraw)
{
	int i; int32 h = 0;
	HFONT font = SGL_GetSystemFont();
	PTBDATA	pTbData = _GET_WINDATA(hWnd, PTBDATA);

	pTbData->ids[SMP_TOOLBARLOC_LEFT] = left;
	pTbData->ids[SMP_TOOLBARLOC_MID] = mid;
	pTbData->ids[SMP_TOOLBARLOC_RIGHT] = right;
	pTbData->str[SMP_TOOLBARLOC_LEFT] = SGL_LoadString(left);
	pTbData->str[SMP_TOOLBARLOC_MID] = SGL_LoadString(mid);	
	pTbData->str[SMP_TOOLBARLOC_RIGHT] = SGL_LoadString(right);
	pTbData->height = 0;

	for(i = 0; i < SMP_TOOLBAR_ITEMCOUNT; i++)
	{
		if(pTbData->str[i])
#ifdef FONT_SUPPORT
			_textWidthHeight((char*)pTbData->str[i], &pTbData->width[i], &h, 1, MR_FONT_BIG);
#else
			mrc_unicodeTextWidthHeight((uint16*)pTbData->str[i], (uint16)font, &pTbData->width[i], &h);
#endif
		if(h > pTbData->height) pTbData->height = h;
	}

	if(redraw && SGL_IsWindowVisible(hWnd))
		SGL_UpdateWindow(hWnd);
}

VOID SMP_Toolbar_SetStrings2(HWND hWnd, PCWSTR mid, BOOL redraw)
{
	int32 h;
	PTBDATA	pTbData = _GET_WINDATA(hWnd, PTBDATA);
	HFONT font = SGL_GetSystemFont();

	if(!mid) return;

	pTbData->str[SMP_TOOLBARLOC_MID] = mid;
	mrc_unicodeTextWidthHeight((uint16*)mid, (uint16)font, &pTbData->width[SMP_TOOLBARLOC_MID], &h);

	if(redraw && SGL_IsWindowVisible(hWnd))
	{
		SGL_UpdateWindow(hWnd);
	}
}

DWORD SMP_Toolbar_GetString(HWND hWnd, int location)
{
	PTBDATA	pTbData = _GET_WINDATA(hWnd, PTBDATA);
	return pTbData->ids[location];
}


LRESULT SMP_Toolbar_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	PTBDATA pTbData = _GET_WINDATA(hWnd, PTBDATA);
	
	switch(Msg) 
	{
	
	case WM_CREATE:
	{
		pTbData = (PTBDATA)SGL_MALLOC(sizeof(TBDATA));
		if(!pTbData){
			SGL_TRACE("%s, %d: memory out\n", __FILE__, __LINE__);
			return 1;
		}
		
		SGL_MEMSET(pTbData, 0, sizeof(TBDATA));
		_SET_WINDATA(hWnd, pTbData);
		_SET_STYLE(hWnd, WS_TRANSPARENT);
		return 0;
	}

	case WM_DESTROY:
	{
		if(pTbData) SGL_FREE(pTbData);
		return 0;
	}

	case WM_SHOW:
	{
		_CLR_STYLE(hWnd, WS_PRESSED);
		break;
	}

	case WM_PAINT:
	{
		int w = 0, h = 0, i;
		int x = _LEFT(hWnd);
		int y = _TOP(hWnd);
		HBITMAP bmp;
		mr_colourSt color;
		HFONT font = SGL_GetSystemFont();

		SGL_WindowToScreen(_PARENT(hWnd), &x, &y);
		SET_COLOR(color, _FGCOLOR(hWnd));
		
		w = _WIDTH(hWnd);
		h = _HEIGHT(hWnd);

		//GAL_DrawHLine(PHYSICALGC, x, y, w, 0x1B1B1B);
		//GAL_FillBox3(PHYSICALGC, x, y+1, w, h-1, 0x555555, 3);

		//1.���ر���������ͼƬ
		bmp = SGL_LoadBitmap(BMP_TITLEBAR, &w, &h);
		for(i = 0; i < _WIDTH(hWnd) / w; i++)
			mrc_bitmapShowEx(bmp, (int16)(i*w), (int16)y, (int16)w, (int16)w, (int16)h, BM_COPY, 0, 0);
		if(MOD(_WIDTH(hWnd), w))
			mrc_bitmapShowEx(bmp, (int16)(i*w), (int16)y, (int16)w, (int16)MOD( _WIDTH(hWnd), w), (int16)h, BM_COPY, 0, 0);  //����������ͼƬ

		//if(_IS_SET_ANY(hWnd, WS_PRESSED))
		//	x += 2, y += 2;

		for(i = 0; i < SMP_TOOLBAR_ITEMCOUNT; i++)
		{
			if(pTbData->str[i])
			{
				GAL_DrawText((PSTR)pTbData->str[i], (int16)(x + (DIV((_WIDTH(hWnd) - pTbData->width[i])*i, 2))), (int16)(y + DIV(_HEIGHT(hWnd) - pTbData->height, 2)), _FGCOLOR(hWnd), font, TRUE);
			}
		}
		return 0;
	}

	case WM_MOUSEDOWN:
	{
		_SET_STYLE(hWnd, WS_PRESSED);
		SGL_SetMouseTracker(hWnd);
		//SGL_UpdateWindow(hWnd);

		return 0;
	}

	case WM_MOUSEUP:
	{
		int x, i;

		if(!_IS_SET_ANY(hWnd, WS_PRESSED))
			return 0;

		_CLR_STYLE(hWnd, WS_PRESSED);
		//SGL_UpdateWindow(hWnd);

		for(i = 0; i < SMP_TOOLBAR_ITEMCOUNT; i++)
		{
			x = DIV((_WIDTH(hWnd) - pTbData->width[i])*i, 2);
			if(pTbData->str[i] && *pTbData->str[i] && (int)wParam >= x && (int)wParam <= (x + pTbData->width[i]))
			{
				SGL_DispatchEvents(WM_KEYUP, (i == SMP_TOOLBARLOC_LEFT? MR_KEY_SOFTLEFT : (i==SMP_TOOLBARLOC_MID? MR_KEY_SELECT : MR_KEY_SOFTRIGHT)), 0);
				break;
			}
		}		
		return 0;
	}
	
	}

	return 0;
}

