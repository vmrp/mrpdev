#ifndef _SMP_ICOWND_H_
#define _SMP_ICOWND_H_

#include "window.h"

#define	SMP_ICONWND_CLICKED		0x0001

/**
 * \brief Set the icownd bmp.
 */
VOID SMP_Icownd_SetIcon(HWND hWnd, DWORD bmpid);

	/** @} */

	/**
	 * \name Window Procedure
	 * @{
	 */

/**
 * \brief Simple spin window procedure
 *
 * \param hWnd the window handle
 * \param Msg the window message 
 * \param wParam the first parameter
 * \param lParam the second parameter
 * \return the result of message process 
 */
LRESULT SMP_Icownd_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
	

#endif