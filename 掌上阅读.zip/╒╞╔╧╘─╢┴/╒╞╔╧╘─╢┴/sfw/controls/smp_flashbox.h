#ifndef _SMP_FLASHBOX_H
#define _SMP_FLASHBOX_H

#include "window.h"

/**
  \defgroup smp_flashbox Simple Flash Box

  To work with Simple Flash Box:
  - Create the flash box window
  - Set the flash box information
  - Add to the parent window

  \code
  //frame information
  static const DWORD fbFrames[] = {
  	BMP_FRAME1,
  	BMP_FRAME2,
  	BMP_FRAME3
  };

  //your code
  hControl = SGL_CreateWindow(SMP_FlashBox_WndProc, ...);
  SMP_FlashBox_SetInfo(hControl, fbFrames, sizeof(fbFrames)/sizeof(fbFrames[0]), 1000, TRUE);
  SGL_AddChildWindow(hParent, hControl);
  
  \endcode
  
  @ingroup controls
  @{
 */

	/**
	 * \name Window Member Functions
	 * @{
	 */

/**
 * \brief Set the flash box information.
 *
 * \param hWnd the flash box window handle
 * \param frms the flash frames array
 * \param size the frames array size
 * \param interval the the interval value between two frames in ms
 * \param loop TRUE play the flash in loop, FALSE stop palying on the last frame
 */
VOID SMP_FlashBox_SetInfo(HWND hWnd, const DWORD* frms, Uint32 size, Uint32 interval, BOOL loop);

/**
 * \brief Play the flash from the index frame.
 *
 * \param hWnd the flash box window handle
 * \param index the index of the frame to play
 * \sa SMP_FlashBox_Stop
 */
VOID SMP_FlashBox_Start(HWND hWnd, Uint32 index);

/**
 * \brief Continue playing.
 *
 * \param hWnd the flash box window handle
 * \sa SMP_FlashBox_Stop
 */
VOID SMP_FlashBox_Play(HWND hWnd);

/**
 * \brief Stop playing.
 *
 * The stop flash box will auto playing when shown again.
 *
 * \param hWnd the flash box window handle
 * \sa SMP_FlashBox_Start, SMP_FlashBox_Play
 */
VOID SMP_FlashBox_Stop(HWND hWnd);

	/** @} */

	/**
	 * \name Window Procedure
	 * @{
	 */

/**
 * \brief The flash box window procedure.
 *
 * \param hWnd the window handle
 * \param Msg the window message
 * \param wParam the first parameter
 * \param lParam the second parameter
 * \return the result of message process 
 */
LRESULT SMP_FlashBox_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);

	/** @} */
	
/** @} end of smp_flashbox*/

#endif
