#include "smp_icownd.h"


#include "i18n.h"
#include "bmp.h"
#include "smp.h"


typedef struct 
{
	DWORD	bmpid;		//ͼ��
	BOOL	focused;	//�Ƿ��ѻ�ý���
}ICOWNDDATA, *PICOWNDDATA;


VOID SMP_Icownd_SetIcon(HWND hWnd, DWORD bmpid)
{
	PICOWNDDATA pData = _GET_WINDATA(hWnd, PICOWNDDATA);
	pData->bmpid = bmpid;
}


LRESULT SMP_Icownd_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	PICOWNDDATA pData = _GET_WINDATA(hWnd, PICOWNDDATA);

	switch(Msg)
	{
	case WM_CREATE:
		pData = (PICOWNDDATA)SGL_MALLOC(sizeof(ICOWNDDATA));
		if(!pData){
			SGL_TRACE("%s, %d: memory out\n", __FILE__, __LINE__);
			return 1;
		}
		SGL_MEMSET(pData, 0, sizeof(ICOWNDDATA));
		_SET_WINDATA(hWnd, pData);

		break;

	case WM_DESTROY:
		if(pData)
			SGL_FREE(pData);
		break;

	case WM_PAINT:
	{
		int x = 0, y = 0, w = 0, h = 0;
		int wBmp = 0, hBmp = 0;
		HBITMAP bmp;

		SGL_WindowToScreen(hWnd, &x, &y);
		w = _HEIGHT(hWnd);
		h = _WIDTH(hWnd);

		//����״̬����Ʊ���
		if(_IS_SET_ANY(hWnd, WS_FOCUSED))
			GAL_FillRoundRrct(x, y, _WIDTH(hWnd), _HEIGHT(hWnd), 0x0084CEF4);
		else
			GAL_FillBox(PHYSICALGC, x, y, _WIDTH(hWnd), _HEIGHT(hWnd), _BGCOLOR(hWnd));

		if(pData->bmpid < RES_BITMAP_COUNT)
		{
			bmp = SGL_LoadBitmap(pData->bmpid, &wBmp, &hBmp);
			mrc_bitmapShowEx(bmp, x+(w-wBmp)/2, y+(h-hBmp)/2, (int16)wBmp, (int16)wBmp, (int16)hBmp, BM_TRANSPARENT, 0, 0);
		}

		break;
	}

	case WM_MOUSEDOWN:
		if(!_IS_SET_ANY(hWnd, WS_FOCUSED))
			pData->focused = FALSE;
		else
			pData->focused = TRUE;
		SGL_SetFocusWindow(_PARENT(hWnd), hWnd);

		break;

	case WM_MOUSEUP:
		if(pData->focused)
			SGL_NotifyParent(hWnd, SMP_ICONWND_CLICKED, (DWORD)hWnd);
		break;

	case WM_KEYDOWN:
		break;

	case WM_KEYUP:
		if(wParam == MR_KEY_SELECT)
			SGL_NotifyParent(hWnd, SMP_ICONWND_CLICKED, (DWORD)hWnd);
		break;	

	case WM_COMMAND:
		break;

	case WM_SETFOCUS:
		{
			SGL_UpdateWindow(hWnd);
			break;
		}	

	case WM_KILLFOCUS:
		{
			SGL_UpdateWindow(hWnd);
			break;
		}	

	}

	return 0;
}