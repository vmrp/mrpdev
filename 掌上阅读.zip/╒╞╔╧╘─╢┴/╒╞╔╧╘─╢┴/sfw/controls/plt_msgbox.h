#ifndef _PLT_MSGBOX_H
#define _PLT_MSGBOX_H

#include "window.h"

/**
  \defgroup pltmsgbox Platform MsgBox window

  To work with platform Message box:
  - Call PLT_MsgBox to show the message box
  - Response to the WM_COMMAND message

  \code
  //show a platform message box
  PLT_MsgBox(0, hParent, SGL_LoadString(STR_MESSENGER), SGL_LoadString(STR_EXITCONFIRM), MR_DIALOG_OK_CANCEL, NULL);

  //response to WM_COMMAND
  case WM_COMMAND:
  	WID id = LOWORD(wParam);
  	WORD code = HIWORD(wParam);
  	if(id == "the platform msgbox id")
  	{
  		if(code == MR_DIALOG_KEY_OK)
  		{
  			//your code
  			......
  		}else if(code == MR_DIALOG_KEY_CANCEL){
			//your code
			......
  		}
  	}  \endcode
 
  @ingroup controls
  @{
 */

	/**
	 * \name Window Member Functions
	 * @{
	 */

/**
 * \brief Show a Message box.
 *
 * \param id the msg box id
 * \param hParent the top-level window handle
 * \param title the title string
 * \param content the content string
 * \param style the window style, MsgBox have some private styles:
 *	- MR_DIALOG_OK //just has a ok button
 *	- MR_DIALOG_OK_CANCEL // have ok and cancel button
 *	- MR_DIALOG_CANCEL // just has a cancel button
 * \param listener who receive the notify message, parenter will get the messages when it is NULL
 * \return the handle of the msgbox
 */
HWND PLT_MsgBox(WID id, HWND hParent, PCWSTR title, PCWSTR content, DWORD style, HWND listener);

	/** @} */
	
	/**
	 * \name Window Procedure
	 * @{
	 */

/**
 * \brief The platform Message Box window procedure.	
 *
 * \param hDlg the button window handle
 * \param Msg the window message
 * \param wParam the first parameter
 * \param lParam the second parameter
 * \return the result of message process 
 */
LRESULT PLT_MsgBox_WndProc(HWND hDlg, UINT Msg, WPARAM wParam, LPARAM lParam);

	/** @} */

/** @} end of pltmsgbox */

#endif

