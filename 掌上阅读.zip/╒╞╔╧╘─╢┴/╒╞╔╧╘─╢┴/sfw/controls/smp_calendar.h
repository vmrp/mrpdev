#ifndef _SMP_CALENDAR_H
#define _SMP_CALENDAR_H

#include "window.h"

/**
  \defgroup smp_calendar Simple Calendar

  To work with the simple calendar:
	- Create the calendar window
	- Set the current date
	- Add to the parent window
	- Response the calendar notify messages
  
  \code
	//create a calendar window
	hControl = SGL_CreateWindow(SMP_Calendar_WndProc, ...);
	SMP_Calendar_SetDate(hControl,  ...);
	SGL_AddChildWindow(hWnd, hControl);

	//response to calendar notify messages
	case WM_COMMAND:
		WID id = LOWORD(wParam);
		WORD code = HIWORD(wParam);

		if(id == "the calendar id")
		{
			hControl = (HWND)lParam;
			switch(code)
			{
			case SMP_CALENDARN_SELECTED:
				//handle the notify event.
				break;
			}
		}	
  \endcode
  
  @ingroup controls
  @{
*/

	/**
	 * \name Window Notify Messages
	 * @{
	 */

/**
 * \brief Sent when user select a date
 * 
 * \code
 *	case WM_COMMAND:
 *		WID id = LOWORD(wParam);
 *		WORD code = HIWORD(wParam);
 *
 *		if(id == "the calendar id" && code == SMP_CALENDARN_SELECTED)
 *		{
 *			HWND hControl = (HWND)lParam; // the calendar handle
 * 			//handle the calendar notify message
 *		}
 * \endcode
 *
 * \param hControl the calendar window handle
 */
#define SMP_CALENDARN_SELECTED	0x0001

	/** @} */

	/**
	 * \name Window Member Functions
	 * @{
	 */

/**
 * \brief Set the calendar date
 *
 * \param hWnd the calendar window handle
 * \param year the new value of year
 * \param month the new value of month
 * \param day the new value of day
 */
VOID SMP_Calendar_SetDate(HWND hWnd, int year, int month, int day);

/**
 * \brief Get the current date
 *
 * \param hWnd the calendar window handle
 * \param[out] year return the value of the year
 * \param[out] month return the value of the month
 * \param[out] day return the value of the day
 */
VOID SMP_Calendar_GetDate(HWND hWnd, int* year, int* month, int* day);

	/** @} */

	/**
	 * \name Window Procedure
	 * @{
	 */

/**
 * \brief The simple calendar window procedure.
 *
 * \param hWnd the window handle
 * \param Msg the window message
 * \param wParam the first parameter
 * \param lParam the second parameter
 * \return the result of message process 
 */
LRESULT SMP_Calendar_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);

	/** @} */

/** @} end of smp_calendar */

#endif
