  #ifndef _PLT_TEXT_H
#define _PLT_TEXT_H

#include "window.h"

/**
  \defgroup plttext Platform Text window

  To work with platform text window:
  - Create the text window
  - Setup the text information
  - Add to the desktop

  \code

  //create the window
  hWnd = SGL_CreateWindow(PLT_Text_WndProc, ..., MR_DIALOG_OK_CANCEL, ...);
  PLT_Text_SetInfo(hWnd, SGL_LoadString(STR_TITLE), SGL_LoadString(STR_CONTENT));

  _LISTENER(hWnd) = hYouWnd; // set the window to get the command message
  SGL_AddChildWindow(HWND_DESKTOP, hWnd);

  //response the WM_COMMAND
  case WM_COMMAND:
  	WID id = LOWORD(wParam);
  	WORD code = HIWORD(wParam);
  	if(id == "the platform text id")
  	{
  		if(code == MR_DIALOG_KEY_OK)
  		{
  			//your code
  			......
  		}else if(code == MR_DIALOG_KEY_CANCEL){
			//your code
			......
  		}
  	}
 
  \endcode
 
  @ingroup controls
  @{
 */

	/**
	 * \name Window Member Functions
	 * @{
	 */

/**
 * \brief Set text window information
 *
 * \param hWnd the text window handle
 * \param title the title string
 * \param text the text window content
 */
VOID PLT_Text_SetInfo(HWND hWnd, PCWSTR title, PCWSTR text);

	/** @} */

	/**
	 * \name Window Procedure
	 * @{
	 */

/**
 * \brief The platform text window procedure.	
 *
 * The platform text can have one of these window private styles:
 *	- MR_DIALOG_OK //just has a ok button
 *	- MR_DIALOG_OK_CANCEL // have ok and cancel button
 *	- MR_DIALOG_CANCEL // just has a cancel button
 *
 * \param hWnd the button window handle
 * \param Msg the window message
 * \param wParam the first parameter
 * \param lParam the second parameter
 * \return the result of message process 
 */
LRESULT PLT_Text_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);

	/** @} */

/** @} end of plttext */
	
#endif
