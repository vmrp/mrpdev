#include "gal.h"
#include "smp.h"
#include "smp_msgbox.h"
#include "bmp.h"


VOID SMP_DrawRadioBox(int x, int y, BOOL checked)
{
	SMP_DrawCheckBox(x, y, checked);		
}


VOID SMP_DrawCheckBox(int x, int y, BOOL checked)
{
	GAL_Rectangle3(PHYSICALGC, x, y, SMP_CHECKBOX_SIZE, SMP_CHECKBOX_SIZE, COLOR_border);	

	if(checked)
	{
		int ax, ay;
		ax = x + 4 + (SMP_CHECKBOX_SIZE - 8)*1/3;
		ay = y + SMP_CHECKBOX_SIZE - DIV(SMP_CHECKBOX_SIZE-7, 2);
		GAL_DrawHook(ax, ay, 3, 6, 3, COLOR_focus);
	}
}


VOID SMP_DrawMsgBoxFrame(int x, int y, int w, int h)
{
	GAL_FillBox(PHYSICALGC, x+1, y+1, w-2, h-2, (System_Theme == THEME_CLASSIC) ? COLOR_C_MAINBG : COLOR_N_MAINBG);//0x00333333

	GAL_Rectangle3(PHYSICALGC, x, y, w, h, (System_Theme == THEME_CLASSIC) ? 0x3f62a2 : 0x084878);
	GAL_Rectangle(PHYSICALGC, x+1, y+1, w-2, h-2, (System_Theme == THEME_CLASSIC) ? 0x70A4C0 : 0x185C88); 

	GAL_FillBox3(PHYSICALGC, x+2, y+2, w-4, SMP_MSGBOX_TBHEIHT-2,  
		(System_Theme == THEME_CLASSIC) ? 0x78CCE8 : 0x306CA8, 2);
	GAL_Rectangle(PHYSICALGC, x+2, y+SMP_MSGBOX_TBHEIHT, w-4, h-SMP_MSGBOX_TBHEIHT-2, 
		(System_Theme == THEME_CLASSIC) ? 0x70A4C0 : 0x084878);
}

VOID SMP_DrawEditFrame(int x, int y, int w, int h, BOOL focused)
{
	//�Ķ�
	if(!focused)
	{
		if(System_Theme == THEME_CLASSIC)
		{
			GAL_FillBox(PHYSICALGC, x, y, w, h, 0xffffff);
			GAL_Rectangle(PHYSICALGC, x, y, w, h, 0xB0C8D7);
			GAL_DrawHLine(PHYSICALGC, x+1, y, w-2, 0x9DBDD0);
			GAL_DrawVLine(PHYSICALGC, x, y+1, h-2, 0x9DBDD0);
			GAL_DrawHLine(PHYSICALGC, x+1, y+h-2, w-2, 0xCDDBE5);
			GAL_DrawVLine(PHYSICALGC, x+w-1, y+1, h-2, 0xCDDBE5);
			GAL_DrawHLine(PHYSICALGC, x, y+h-1, w, 0xF3F6F9);
		} 
		else
		{
			GAL_FillBox(PHYSICALGC, x, y, w, h, 0x1A527A);
			GAL_Rectangle3(PHYSICALGC, x, y, w, h, 0x96B5DA);
		}
	} 
	else
	{
		GAL_FillBox(PHYSICALGC, x, y, w, h, (System_Theme == THEME_CLASSIC) ? 0xffffff : 0x105070);
		GAL_Rectangle(PHYSICALGC, x+1, y+1, w-2, h-2, 0x46A8E2);
		GAL_Rectangle(PHYSICALGC, x, y, w, h, (System_Theme == THEME_CLASSIC) ? 0xBEE8FC : 0x082030);
		GAL_Rectangle3(PHYSICALGC, x, y, w, h, 0x60C8FD);
	}
}

VOID SMP_DrawWndHeader(int x, int y, int w, int h, Uint32 bgcolor, Uint32 fgcolor, DWORD bmpID, PCWSTR str)
{
	int wBmp = 0, hBmp = 0;
	int32 wText, hText;
	mr_screenRectSt rect;
	mr_colourSt color={0,};
	HBITMAP bmp;

	//���Ʊ���ɫ��
	GAL_FillBox(PHYSICALGC, x, y, w, h, bgcolor);

	//����bmpͼƬ
	wBmp = 0;
	if(bmpID < RES_BITMAP_COUNT)
	{
		bmp = SGL_LoadBitmap(bmpID, &wBmp, &hBmp);
		mrc_bitmapShowEx(bmp, SMP_ITEM_CONTENT_MARGIN, (int16)DIV(h - hBmp, 2), (int16)wBmp, (int16)wBmp, (int16)hBmp, BM_TRANSPARENT, 0, 0);
		wBmp += SMP_ITEM_CONTENT_MARGIN;
	}

	//��ʾ����
	if(str)
	{
		HFONT font = SGL_GetSystemFont();
		rect.x = (int16)(SMP_ITEM_CONTENT_MARGIN + wBmp);
		mrc_textWidthHeight((PSTR)str, TRUE, (uint16)font, &wText, &hText);
		rect.y = (int16)DIV(h - hText, 2); rect.h = h; rect.w = (uint16)(SCREEN_WIDTH - rect.x - SMP_ITEM_CONTENT_MARGIN);

		color.r = PIXEL888RED(fgcolor);
		color.g = PIXEL888GREEN(fgcolor);
		color.b = PIXEL888BLUE(fgcolor);
		mrc_drawTextEx((PSTR)str, rect.x, rect.y, rect, color, 1, (uint16)font);
	}
}


