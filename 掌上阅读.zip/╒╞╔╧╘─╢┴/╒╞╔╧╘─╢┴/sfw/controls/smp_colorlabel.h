#ifndef _SMP_COLORLABEL_H
#define _SMP_COLORLABEL_H

#include "window.h"


/**
 * \brief the colorlabel window height
 */
#define COLORLABEL_HEIGHT	30


/**
 * \brief Set the colorlabel content.
 *
 * \param hWnd the colorlabel window handle
 * \param caption the new string for the colorlabel caption
 * \param color the new color for the colorlabel caption font color
 */
VOID SMP_Colorlabel_SetContent(HWND hWnd, PCWSTR caption, Uint32 color);

/**
 * \brief Get the colorlabel content.
 *
 * \param hWnd the colorlabel window handle
 * \return the colorlabel font color
 */
Uint32 SMP_Colorlabel_GetColor(HWND hWnd);

/**
 * \brief The simple set color Label window procedure.	
 *
 * \param hWnd the button window handle
 * \param Msg the window message
 * \param wParam the first parameter
 * \param lParam the second parameter
 * \return the result of message process 
 */
LRESULT SMP_Colorlabel_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);

#endif