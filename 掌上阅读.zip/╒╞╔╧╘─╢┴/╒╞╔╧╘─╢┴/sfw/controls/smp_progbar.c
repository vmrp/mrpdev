#include "smp_progbar.h"


//default min/max values
#define PROGBAR_MIN_DEFAULT 	0
#define PROGBAR_MAX_DEFAULT		99


//progress bar data
typedef struct SMP_ProgBarData
{
	Sint32 min;
	Sint32 max;
	Sint32 cur;
	int32 autoscroTimer;	//������ʱ��
	BOOL  moveleft;	//True when move left,move right otherwise
}PROGBARDATA, *PPROGBARDATA;

///////////////////////////////////////////////////////////////////////////////

VOID SMP_ProgBar_SetRange(HWND hWnd, Sint32 min, Sint32 max)
{
	PPROGBARDATA pData = _GET_WINDATA(hWnd, PPROGBARDATA);

	if(min >= max) return;

	pData->min = min;
	pData->max = max;
	pData->cur = min;
}


VOID SMP_ProgBar_SetValue(HWND hWnd, Sint32 value, BOOL redraw, BOOL notify)
{
	PPROGBARDATA pData = _GET_WINDATA(hWnd, PPROGBARDATA);

	if(value < pData->min || value > pData->max || value == pData->cur)
		return;

	pData->cur = value;

	if(redraw)
		SGL_UpdateWindow(hWnd);

	if(notify)
		SGL_NotifyParent(hWnd, SMP_PROGBARN_VALUECHANGED, value);
}

//�������Զ������ص�
static VOID SMP_ProgBar_AutoScroCB(int32 data)
{
	HWND hWnd = (HWND)data;
	PPROGBARDATA pData = _GET_WINDATA(hWnd, PPROGBARDATA);

	if(pData->min + pData->cur > pData->max)
		pData->moveleft = TRUE;

	if(pData->min < 0)
		pData->moveleft = FALSE;

	if(pData->moveleft)
		pData->min -= 2;
	else
		pData->min += 2;

	SGL_UpdateWindow(hWnd);
}

LRESULT SMP_ProgBar_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	PPROGBARDATA pData = _GET_WINDATA(hWnd, PPROGBARDATA);

	switch(Msg)
	{
	case WM_CREATE:
	{
		pData = (PPROGBARDATA)SGL_MALLOC(sizeof(PROGBARDATA));
		if(!pData){
			SGL_TRACE("%s, %d: memory out\n", __FILE__, __LINE__);
			return 1;
		}
		SGL_MEMSET(pData, 0, sizeof(PROGBARDATA));
		_SET_WINDATA(hWnd, pData);
		_SET_STYLE(hWnd, WS_TRANSPARENT);

		pData->min = PROGBAR_MIN_DEFAULT;
		pData->max = PROGBAR_MAX_DEFAULT;
		pData->cur = PROGBAR_MIN_DEFAULT;

		//����������ʱ��
		pData->autoscroTimer = mrc_timerCreate();

		break;
	}
	
	case WM_DESTROY:
	{
		if(pData->autoscroTimer)
		{
			mrc_timerStop(pData->autoscroTimer);
			mrc_timerDelete(pData->autoscroTimer);
		}

		if(pData) 
			SGL_FREE(pData);
		
		break;
	}

	case WM_SHOW:	
	{
		//���Ϊ�Զ�������ʽ������ʾ��ʱ��������ʱ������ʼ�Զ�����
		if(_IS_SET_ANY(hWnd, SMP_PROGBAR_AUTOSCRO))
		{
			pData->min = 0;		//��ʱ��min��Ϊ���������ȿ�x����
			pData->max = _WIDTH(hWnd) - 4;	//��ֵΪ����������
			pData->cur = DIV(pData->max, 4); //�˲��������ȣ�����ռ����������1/4

			mrc_timerStart(pData->autoscroTimer, 40, (int32)hWnd, SMP_ProgBar_AutoScroCB, TRUE);
		}

		break;
	}

	case WM_HIDE:
	{
		//���ص�ʱ��ע��ֹͣ����
		if(pData->autoscroTimer)
		{
			mrc_timerStop(pData->autoscroTimer);
		}

		break;
	}
		
	case WM_PAINT:
	{
		int x = 0, y = 0;
		int w, h;
		Uint32 clr1, clr2;

		SGL_WindowToScreen(hWnd, &x, &y);
		w = _WIDTH(hWnd), h =  _HEIGHT(hWnd);

		//������
		GAL_FillBox(PHYSICALGC, x+1, y+1, w-2, h/2-1, 0x4B9CC8);
		GAL_FillBox(PHYSICALGC, x+1, y+h/2, w-2, h/2-1, 0x2B92C0);
		clr1 = System_Theme == THEME_CLASSIC ? 0x286DB0 : 0x60A0D0;
		GAL_Rectangle3(PHYSICALGC, x+1, y, w-2, h, clr1);
		GAL_Rectangle3(PHYSICALGC, x, y+1, w, h-2, 0x82B4D8);

		//�����ȿ�
		h = _HEIGHT(hWnd) - 4;	//���ȿ�߶�
		if(_IS_SET_ANY(hWnd, SMP_PROGBAR_AUTOSCRO))
		{
			clr2 = System_Theme == THEME_CLASSIC ? 0x9EDEF9 : 0x5A5173;
			GAL_FillBox3(PHYSICALGC, x + pData->min + 2, y+2, pData->cur, h, clr2, 2);
		}else{
			w = DIV((pData->cur - pData->min) * (_WIDTH(hWnd) - 4), pData->max - pData->min) - 2;
			clr2 = System_Theme == THEME_CLASSIC ? 0x9EDEF9 : 0x5A5173;
			GAL_FillBox3(PHYSICALGC, x+3, y+2, w, h, clr2, 2);
		}

		break;
	}
	
	}
	
	return 0;
}

