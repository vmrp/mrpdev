#include "smp.h"
#include "smp_list.h"
#include "smp_scrollbar.h"
#include "bmp.h"

#define LIST_SCRBAR_ID		1
#define SMP_LIST_ITEM_WIDTH		 (SCREEN_WIDTH - SMP_SCRBAR_WIDTH - 2*SMP_LIST_LEFT_MARGIN)


typedef struct SMP_ListData
{
	int rheight;          // �и� ����
	int total;            // �б�����Ŀ��
	int pagestart;        // ��ǰҳ��һ���е�����
	int hilight;          // ������ʾ�е�����
	int pagesize;         // ÿһҳ��ʾ������
	BOOL m_firstFocus;	  // ����һ�ε����ý��㣬�ڶ��ε������Ӧ�¼�
	int s_mLastY;		  // ��������MOVEʱ���ϴ�MOVE��Y����

	SMP_List_GetTotal fnGetTotalCount;  //��ȡ�������Ļص�����
	SMP_List_GetRowData fnGetRowData;   //��ȡ�����ݵĻص�����
	SMP_List_DrawRow fnDrawRow;
	HWND hScrBar;         // �б����������
}LISTDATA, *PLISTDATA;


//static BOOL IsFirstGetFocus;	//���Ӵ˱�־�������ǲ����״λ�ý���
//static int s_mLastY;			//��������MOVEʱ���ϴ�MOVE��Y����


/**
 * FUNCTION IMPLEMENTS Ĭ�ϵĻ��й��ܡ�
 * ע�⣺�˺���������������ÿ������
 * r�����л������ݾ���
 * ÿ�θı��б��ĸ����ж��ᴥ�����¼�
 */
VOID SMP_List_DefaultDrawRowCallback(int index, PRECT r, PSMPROWDATA pRowData, int hilight, BOOL flush)
{
	int32 i, w, h;
	mr_screenRectSt rect;
	mr_colourSt color;
	uint32 bg, fg;
	HFONT font = SGL_GetSystemFont();	
	
	//��䱳��
	if(index == hilight) 
	{
		bg = (System_Theme == THEME_CLASSIC) ? 0x70BCE8 : 0x80D0F0;
		GAL_FillBox2(PHYSICALGC, r->left+1, r->top+1, r->width-2, r->height-2, bg, 4);
		fg = (System_Theme == THEME_CLASSIC) ? 0x70BCE8 : 0xffffff;
		SET_COLOR(color, fg);
	}else{
		bg = (MOD(index, 2) == 0) ? 0x2D3434 : 0x082030;
		GAL_FillBox(PHYSICALGC, r->left, r->top, r->width, r->height, bg);
		fg = (System_Theme == THEME_CLASSIC) ? 0x80CCE8 : 0x80CCE8;
		SET_COLOR(color, fg);
	}

	//����ͼ��
	rect.x = r->left + pRowData->margin, rect.y = r->top, rect.h = r->height;
	if(pRowData->hBmp)
		mrc_bitmapShowEx(pRowData->hBmp, (int16)rect.x, (int16)(rect.y + DIV(rect.h-pRowData->colHeight0, 2)), pRowData->colWidth0, pRowData->colWidth0, pRowData->colHeight0, BM_TRANSPARENT, 0, 0);	
	
	//��������
	rect.x += pRowData->colWidth0;
	for(i = 0; i < SMP_LIST_MAX_STR_COL; i++)
	{
		if(pRowData->cols[i].str)
		{
			rect.w = pRowData->cols[i].width;
			//���޸�ԭ��ΪUnicode������ʾ
			mrc_textWidthHeight((PSTR)pRowData->cols[i].str, 0, (Uint16)font, &w, &h);
			mrc_drawTextEx((PSTR)pRowData->cols[i].str, rect.x + 5, (int16)(rect.y + DIV(rect.h - h, 2)), rect, color, 0, (Uint16)font);	
		}
		rect.x += pRowData->cols[i].width;
	}	

	if(flush)
		GAL_FlushRegion(PHYSICALGC, r->left, r->top, r->width, r->height);
}

//�Զ��廭�з�ʽ1����ʾ���
VOID SMP_List_CustomDrawRowCB1(int index, PRECT r, PSMPROWDATA pRowData, int hilight, BOOL flush)
{
	int32 w, h;
	mr_screenRectSt rect;
	mr_colourSt color={0,};
	HFONT font = SGL_GetSystemFont();	
	char buf[5] = {0};
	uint32 bg, fg;
	
	//��䱳��
	if(index == hilight) 
	{
		bg = (System_Theme == THEME_CLASSIC) ? 0x70BCE8 : 0x80D0F0;
		GAL_FillBox2(PHYSICALGC, r->left+1, r->top+1, r->width-2, r->height-2, bg, 4);
		fg = (System_Theme == THEME_CLASSIC) ? 0x70BCE8 : 0xffffff;
		SET_COLOR(color, fg);
	}else{
		bg = (MOD(index, 2) == 0) ? 0x2D3434 : 0x082030;
		GAL_FillBox(PHYSICALGC, r->left, r->top, r->width, r->height, bg);
		fg = (System_Theme == THEME_CLASSIC) ? 0x80CCE8 : 0x80CCE8;
		SET_COLOR(color, fg);
	}

	//����ͼ��
	rect.x = r->left + pRowData->margin, rect.y = r->top, rect.h = r->height;

	//1.�������
	mrc_sprintf(buf, "%d.", index+1);
	pRowData->cols[0].str = buf;
	mrc_textWidthHeight((PSTR)pRowData->cols[0].str, 0, (Uint16)font, &w, &h);
	rect.w = pRowData->cols[0].width = (uint16)w+5;
	mrc_drawTextEx((PSTR)pRowData->cols[0].str, rect.x + 5, (int16)(rect.y + DIV(rect.h - h, 2)), rect, color, 0, (Uint16)font);	
	//2.���Ʊ���
	rect.x += pRowData->cols[0].width;
	rect.w = SMP_LIST_ITEM_WIDTH - pRowData->cols[0].width-10;
	mrc_textWidthHeight((PSTR)pRowData->cols[1].str, 0, (Uint16)font, &w, &h);
	mrc_drawTextEx((PSTR)pRowData->cols[1].str, rect.x + 5, (int16)(rect.y + DIV(rect.h - h, 2)), rect, color, 0, (Uint16)font);	

	if(flush)
		GAL_FlushRegion(PHYSICALGC, r->left, r->top, r->width, r->height);
}


//�б�����ÿһ��
static VOID SMP_List_DrawItem(HWND hList, int index)
{
	RECT r;
	int top = 0;
	SMPROWDATA rowData;
	PLISTDATA pListData = _GET_WINDATA(hList, PLISTDATA);
	
	_WINRECT(hList, r);	
	SGL_WindowToScreen(_PARENT(hList), &r.left, &r.top);

	top = r.top + SMP_LIST_TOP_MARGIN;
	r.left += SMP_LIST_LEFT_MARGIN;
	r.width -= 2*SMP_LIST_LEFT_MARGIN;
	if(pListData->hScrBar) r.width -= SMP_SCRBAR_WIDTH;
	r.height = pListData->rheight;
	r.top = top + (index - pListData->pagestart)*pListData->rheight;
	
	GAL_FillBox(PHYSICALGC, r.left, r.top, r.width, r.height, _BGCOLOR(hList));
	SGL_MEMSET(&rowData, 0, sizeof(rowData));
	pListData->fnGetRowData(index, &rowData);
	pListData->fnDrawRow(index, &r, &rowData, pListData->hilight, TRUE);
}

//�б������иı�
static VOID SMP_List_HilightChanged(HWND hList, int from, int to)
{
	PLISTDATA pListData = _GET_WINDATA(hList, PLISTDATA);
	pListData->hilight = to;
	SMP_List_DrawItem(hList, from);
	SMP_List_DrawItem(hList, to);
	SGL_NotifyParent(hList, SMP_LISTN_HILICHANGED, to);
}

//���»���ÿһ��
VOID SMP_List_SetDrawRowCallback(HWND hList, SMP_List_DrawRow fnDrawRow)
{
	PLISTDATA pListData = _GET_WINDATA(hList, PLISTDATA);
	pListData->fnDrawRow = fnDrawRow;
}

//����ÿһ������
VOID SMP_List_SetDataProvider(HWND hList, SMP_List_GetTotal fnGetTotal, SMP_List_GetRowData fnGetRowData)
{
	PLISTDATA pListData = _GET_WINDATA(hList, PLISTDATA);

	if(pListData)
	{
		pListData->fnGetTotalCount = fnGetTotal;
		pListData->fnGetRowData = fnGetRowData;
	}
}

//�б�������
static VOID SMP_List_HilightRow(HWND hList, PLISTDATA pListData, int index)
{
	if(pListData->hilight != index 
		&& index >= 0 
		&& index < pListData->total)
	{
		pListData->hilight = index;

		if(index >= pListData->pagestart + pListData->pagesize)
			pListData->pagestart = index - pListData->pagesize + 1;
		else if(index < pListData->pagestart)
			pListData->pagestart = index;
		
		if(pListData->hScrBar) SMP_Scrollbar_SetValue(pListData->hScrBar, pListData->pagestart, FALSE);
		SGL_UpdateWindow(hList);
		SGL_NotifyParent(hList, SMP_LISTN_HILICHANGED, index);
	}
}

//ͨ������ı������
VOID SMP_List_HilightByIndex(HWND hList, int index)
{
	PLISTDATA pListData;
	if(!IS_NORMAL_WINDOW(hList)) return;

	pListData = _GET_WINDATA(hList, PLISTDATA);
	SMP_List_HilightRow(hList, pListData, index);
}

//��ȡ��ǰ�����е�����
int SMP_List_GetHilightIndex(HWND hList)
{
	PLISTDATA pListData;
	if(!IS_NORMAL_WINDOW(hList)) 
		return 0;

	pListData = _GET_WINDATA(hList, PLISTDATA);
	return pListData->hilight;
}

//��ȡ�б�ҳ����Ϣ
VOID SMP_List_GetPageInfo(HWND hList, int* pagestart, int* pagesize)
{
	PLISTDATA pListData;
	if(!IS_NORMAL_WINDOW(hList)) 
		return;
	
	pListData = _GET_WINDATA(hList, PLISTDATA);
	if(pagestart) *pagestart = pListData->pagestart;
	if(pagesize) *pagesize = pListData->pagesize;
}

//�б��Ϸ�ҳ
VOID SMP_List_PageUp(HWND hList)
{
	int oldHili;
	PLISTDATA pListData = _GET_WINDATA(hList, PLISTDATA);		
	if(pListData->pagestart <= 0)
		return;

	pListData->pagestart -= pListData->pagesize;
	if(pListData->pagestart < 0)
		pListData->pagestart = 0;

	oldHili = pListData->hilight;
	if(pListData->hilight >= pListData->pagestart + pListData->pagesize)
		pListData->hilight = pListData->pagestart + pListData->pagesize - 1;

	if(pListData->hScrBar)  SMP_Scrollbar_SetValue(pListData->hScrBar, pListData->pagestart, FALSE);
	SGL_UpdateWindow(hList);
	if(oldHili != pListData->hilight)
		SGL_NotifyParent(hList, SMP_LISTN_HILICHANGED, pListData->hilight);
}

//�б��·�ҳ
VOID SMP_List_PageDown(HWND hList)
{
	int oldHili;	
	PLISTDATA pListData = _GET_WINDATA(hList, PLISTDATA);		
	int maxstart = pListData->total - pListData->pagesize;
	if(pListData->pagestart >= maxstart)
		return;
	
	pListData->pagestart += pListData->pagesize;
	if(pListData->pagestart > maxstart)
		pListData->pagestart = maxstart;
	
	oldHili = pListData->hilight;
	if(pListData->hilight < pListData->pagestart)
		pListData->hilight = pListData->pagestart;
	
	if(pListData->hScrBar) SMP_Scrollbar_SetValue(pListData->hScrBar, pListData->pagestart, FALSE);
	SGL_UpdateWindow(hList);
	if(oldHili != pListData->hilight)
		SGL_NotifyParent(hList, SMP_LISTN_HILICHANGED, pListData->hilight);
}

//�б��Ϸ���
VOID SMP_List_LineUp(HWND hList)
{
	PLISTDATA pListData = _GET_WINDATA(hList, PLISTDATA);	

	if(pListData->hilight > 0) 
	{
		if(pListData->hilight > pListData->pagestart)
			SMP_List_HilightChanged(hList, pListData->hilight, pListData->hilight-1);
		else
			SMP_List_HilightRow(hList, pListData, pListData->hilight - 1);
	}else
	{
		SMP_List_HilightRow(hList, pListData, pListData->total - 1);
	}
}

//�б��·���
VOID SMP_List_LineDown(HWND hList)
{
	int step = 1;
	PLISTDATA pListData = _GET_WINDATA(hList, PLISTDATA);
	
	if(pListData->hilight < pListData->total - 1) 
	{
		if(pListData->hilight + step < pListData->pagestart + pListData->pagesize)
			SMP_List_HilightChanged(hList, pListData->hilight, pListData->hilight + step);
		else
			SMP_List_HilightRow(hList, pListData, pListData->hilight + step);
	}else
	{
		SMP_List_HilightRow(hList, pListData, 0);
	}
}

//ˢ���б�
VOID SMP_List_Refresh(HWND hList)
{
	int maxpagestart;
	PLISTDATA pListData = _GET_WINDATA(hList, PLISTDATA);
	pListData->total = pListData->fnGetTotalCount();

	if(pListData->hScrBar)
	{
		_LEFT(pListData->hScrBar) = _WIDTH(hList) - SMP_SCRBAR_WIDTH;
		_TOP(pListData->hScrBar) = 0;
		_WIDTH(pListData->hScrBar) = SMP_SCRBAR_WIDTH;
		_HEIGHT(pListData->hScrBar) = _HEIGHT(hList);
	}
	pListData->pagesize = DIV(_HEIGHT(hList) - SMP_LIST_TOP_MARGIN, SMP_LIST_ITEM_HEIGHT);
	pListData->rheight = SMP_LIST_ITEM_HEIGHT;

	if(pListData->hilight > pListData->total-1) 
		pListData->hilight = MAX(pListData->total - 1, 0);
	
	if(pListData->hScrBar) SMP_Scrollbar_SetInfo(pListData->hScrBar, 0, MAX(pListData->total - 1, 0), pListData->pagesize);
	
	maxpagestart = MAX(pListData->total - pListData->pagesize, 0);
	if(pListData->pagestart > maxpagestart)
	{
		pListData->pagestart = maxpagestart;
		if(pListData->hScrBar) SMP_Scrollbar_SetValue(pListData->hScrBar, pListData->pagestart, FALSE);		
	}

	SGL_UpdateWindow(hList);  //�б�������ϣ�ˢ���б�����(��)
}

//�������б�
VOID SMP_List_Reset(HWND hList)
{
	PLISTDATA pListData = _GET_WINDATA(hList, PLISTDATA);
	if(pListData)
	{
		 pListData->rheight = 0; 
		 pListData->total = 0; 
		 pListData->pagestart = 0; 
		 pListData->hilight = 0; 
		 pListData->pagesize = 0; 
	}
}

//�б������¼�
LRESULT SMP_List_WndProc(HWND hList, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	PLISTDATA pListData = _GET_WINDATA(hList, PLISTDATA);
	switch(Msg)
	{

	case WM_CREATE:
	{
		//request memory and initialize members
		pListData = (PLISTDATA)SGL_MALLOC(sizeof(LISTDATA));
		if(!pListData){
			SGL_TRACE("%s, %d: memory out\n", __FILE__, __LINE__);
			return 1;
		}
		
		SGL_MEMSET(pListData, 0, sizeof(LISTDATA));	
		pListData->fnDrawRow = SMP_List_DefaultDrawRowCallback;
		_SET_WINDATA(hList, pListData);		

		//create scrollbar
		if(!_IS_SET_ANY(hList, SMP_LISTS_NOSCRBAR))
		{
			pListData->hScrBar = SGL_CreateWindow(SMP_Scrollbar_WndProc, 
				0, 0, SMP_SCRBAR_WIDTH, _HEIGHT(hList), 
				LIST_SCRBAR_ID, 0, 0);
			SGL_AddChildWindow(hList, pListData->hScrBar);
		}

		return 0;
	}

	case WM_DESTROY:
	{
		if(pListData) SGL_FREE(pListData);
		return 0;
	}

	case WM_SHOW: //ˢ���б�
	{
		SMP_List_Refresh(hList);
		return 0;
	}

	case WM_PAINT:
	{
		RECT r;
		int32 from, to;
		SMPROWDATA rowData;
		
		_WINRECT(hList, r);
		SGL_WindowToScreen(_PARENT(hList), &r.left, &r.top);

		r.top += SMP_LIST_TOP_MARGIN;
		r.left += SMP_LIST_LEFT_MARGIN;
		r.width -= pListData->hScrBar? SMP_SCRBAR_WIDTH + 2*SMP_LIST_LEFT_MARGIN : 2*SMP_LIST_LEFT_MARGIN;
		r.height = pListData->rheight;

		to = pListData->total - pListData->pagestart;
		if(pListData->pagesize < to) to = pListData->pagesize;

		for(from = 0; from < to; from++, r.top += pListData->rheight)
		{
			SGL_MEMSET(&rowData, 0, sizeof(SMPROWDATA));
			pListData->fnGetRowData(from + pListData->pagestart, &rowData);
			pListData->fnDrawRow(pListData->pagestart + from, &r, &rowData, pListData->hilight, FALSE);
		}
		return 0;
	}

	case WM_MOUSEDOWN: //������ʾ�������
	{
		int row = DIV(lParam-SMP_LIST_TOP_MARGIN, pListData->rheight) + pListData->pagestart;

		if(row >= 0 && row < pListData->total && row < pListData->pagestart + pListData->pagesize)
		{			
			if(row != pListData->hilight )
			{
				SMP_List_HilightChanged(hList, pListData->hilight, row);
				pListData->m_firstFocus = TRUE;
			}else
				pListData->m_firstFocus = FALSE;
		}

		//��������ʱ ����Y����
		pListData->s_mLastY = (int)lParam;   

		return 0;
	}

	/* *
	 * �״ΰ�������Ǽ�¼���µ�λ�ã�Ȼ���ƶ���꣬
	 * ÿ�ƶ����볬���и���һ��Ȼ�����¼��������ʼλ��
	 * */
	case WM_MOUSEMOVE:
	{
		if(!pListData->hScrBar)	//û�й�����
			break;

		if((int)lParam - pListData->s_mLastY > pListData->rheight)		//�����ƶ� �����и�
		{
			SMP_Scrollbar_LineUp(pListData->hScrBar);
			pListData->s_mLastY = (int)lParam; 
		}else if(pListData->s_mLastY - (int)lParam > pListData->rheight){  //�����ƶ� �����и�
			SMP_Scrollbar_LineDown(pListData->hScrBar);
			pListData->s_mLastY = (int)lParam; 
		}

		return 0;
	}

	case WM_MOUSEUP:  //֪ͨ�������б����
	{
		int row = DIV(lParam-SMP_LIST_TOP_MARGIN, pListData->rheight) + pListData->pagestart;
		if(row >= 0 && row  <pListData->total && row < pListData->pagestart + pListData->pagesize)
		{
			if(row == pListData->hilight && !pListData->m_firstFocus)
				SGL_NotifyParent(hList, SMP_LISTN_CLICKED, pListData->hilight);
		}

		return 0;
	}

	case WM_KEYDOWN:  //�����б����з�ҳ
	case WM_KEYDOWNREPEAT:
	{
		switch(wParam)
		{
		case MR_KEY_DOWN:
			SMP_List_LineDown(hList);
			return 1;
		case MR_KEY_UP:
			SMP_List_LineUp(hList);
			return 1;
		case MR_KEY_LEFT:
			SMP_List_PageUp(hList);
			return 1;
		case MR_KEY_RIGHT:
			SMP_List_PageDown(hList);
			return 1;
		}
		return 0;
	}
	
	case WM_KEYUP:
	{
		if( (wParam == MR_KEY_SELECT) || (wParam == MR_KEY_5) )
		{
			SGL_NotifyParent(hList, SMP_LISTN_SELECTED, pListData->hilight);
			return 1;
		}
		return 0;
	}

	case WM_COMMAND:  //��Ҫ�Ǵ���������λ�õı仯
	{
		WORD id = LOWORD(wParam);
		WORD code = HIWORD(wParam);
		
		if(LIST_SCRBAR_ID == id && code == SMP_SCRBARN_VALUECHANGED)
		{
			RECT r = {0,};
			int oldHi = pListData->hilight;

			if(pListData->pagestart == (int)lParam)
				return 0;

			pListData->pagestart = (int)lParam;
			if(pListData->hilight < pListData->pagestart)
				pListData->hilight = pListData->pagestart;
			else if(pListData->hilight >= pListData->pagestart + pListData->pagesize)
				pListData->hilight = pListData->pagestart + pListData->pagesize - 1;

			//just avoid to repaint the scrollbar
			r.width = _WIDTH(hList) - SMP_SCRBAR_WIDTH;
			r.height = _HEIGHT(hList);
			SGL_UpdateWindowEx(hList, &r);
			if(oldHi != pListData->hilight)
				SGL_NotifyParent(hList, SMP_LISTN_HILICHANGED, pListData->hilight);
		}
		return 0;
	}

	}

	return 0;
}


