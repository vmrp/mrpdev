#include "colorpick.h"


//��ɫ���С
#define BLOCK_W		10
#define BLOCK_H		7

//��ɫ����ʼ���꣨x,y��
static int qsX, qsY;
//ѡ����ɫ������
static int si, sj;

/*
* uint[��][��]��
*/
static const uint32 colors[12][20] = {
	{0X000000, 0X000033, 0X000066, 0X000099,
	0X0000CC, 0X0000FF, 0X003300, 0X003333,
	0X003366, 0X003399, 0X0033CC, 0X0033FF,
	0X006600, 0X006633, 0X006666, 0X006699,
	0X0066CC, 0X0066FF, 0X009900, 0X009933},
	//2
	{0X009966, 0X009999, 0X0099CC, 0X0099FF,
	0X00CC00, 0X00CC33, 0X00CC66, 0X00CC99,
	0X00CCCC, 0X00CCFF, 0X00FF00, 0X00FF33,
	0X00FF66, 0X00FF99, 0X00FFCC, 0X00FFFF,
	0X330000, 0X330033, 0X330066, 0X330099},
	//3
	{0X3300CC, 0X3300FF, 0X333300, 0X333333,
	0X333366, 0X333399, 0X3333CC, 0X3333FF,
	0X336600, 0X336633, 0X336666, 0X336699,
	0X3366CC, 0X3366FF, 0X339900, 0X339933,
	0X339966, 0X339999, 0X3399CC, 0X3399FF},
	//4
	{0X33CC00, 0X33CC33, 0X33CC66, 0X33CC99,
	0X33CCCC, 0X33CCFF, 0X33FF00, 0X33FF33,
	0X33FF66, 0X33FF99, 0X33FFCC, 0X33FFFF,
	0X660000, 0X660033, 0X660066, 0X660099,
	0X6600CC, 0X6600FF, 0X663300, 0X663333},

	//5
	{0X663366, 0X663399, 0X6633CC, 0X6633FF,
	0X666600, 0X666633, 0X666666, 0X666699,
	0X6666CC, 0X6666FF, 0X669900, 0X669933,
	0X669966, 0X669999, 0X6699CC, 0X6699FF,
	0X66CC00, 0X66CC33, 0X66CC66, 0X66CC99},
	//6
	{0X66CCCC, 0X66CCFF, 0X66FF00, 0X66FF33,
	0X66FF66, 0X66FF99, 0X66FFCC, 0X66FFFF,
	0X990000, 0X990033, 0X990066, 0X990099,
	0X9900CC, 0X9900FF, 0X993300, 0X993333,
	0X993366, 0X993399, 0X9933CC, 0X9933FF},
	//7
	{0X996600, 0X996633, 0X996666, 0X996699,
	0X9966CC, 0X9966FF, 0X999900, 0X999933,
	0X999966, 0X999999, 0X9999CC, 0X9999FF,
	0X99CC00, 0X99CC33, 0X99CC66, 0X99CC99,
	0X99CCCC, 0X99CCFF, 0X99FF00, 0X99FF33},
	//8
	{0X99FF66, 0X99FF99, 0X99FFCC, 0X99FFFF,
	0XCC0000, 0XCC0033, 0XCC0066, 0XCC0099,
	0XCC00CC, 0XCC00FF, 0XCC3300, 0XCC3333,
	0XCC3366, 0XCC3399, 0XCC33CC, 0XCC33FF,
	0XCC6600, 0XCC6633, 0XCC6666, 0XCC6699},
	//9
	{0XCC66CC, 0XCC66FF, 0XCC9900, 0XCC9933,
	0XCC9966, 0XCC9999, 0XCC99CC, 0XCC99FF,
	0XCCCC00, 0XCCCC33, 0XCCCC66, 0XCCCC99,
	0XCCCCCC, 0XCCCCFF, 0XCCFF00, 0XCCFF33,
	0XCCFF66, 0XCCFF99, 0XCCFFCC, 0XCCFFFF},
	//10
	{0XFF0000, 0XFF0033, 0XFF0066, 0XFF0099,
	0XFF00CC, 0XFF00FF, 0XFF3300, 0XFF3333,
	0XFF3366, 0XFF3399, 0XFF33CC, 0XFF33FF,
	0XFF6600, 0XFF6633, 0XFF6666, 0XFF6699,
	0XFF66CC, 0XFF66FF, 0XFF9900, 0XFF9933},
	//11
	{0XFF9966, 0XFF9999, 0XFF99CC, 0XFF99FF,
	0XFFCC00, 0XFFCC33, 0XFFCC66, 0XFFCC99,
	0XFFCCCC, 0XFFCCFF, 0XFFFF00, 0XFFFF33,
	0XFFFF66, 0XFFFF99, 0XFFFFCC, 0XFFFFFF,
	0XFFFF66, 0XFFFF99, 0XFFFFCC, 0XFFFFFF}};


//����ColorBox������
VOID ColorBox_DrawGrid(VOID)
{
	int i;

	//1.��������
	for(i=0; i<12; i++)		//��
	{
		GAL_DrawHLine(PHYSICALGC, qsX, qsY + 8*i, 221, 0xa6a6a6);
	}
	for(i=0; i<21; i++)		//��
	{
		GAL_DrawVLine(PHYSICALGC, qsX + 11*i, qsY, 89, 0xa6a6a6);
	}
}

//����ѡ�еĿ�
VOID PaintFocusBlock(int fi, int fj)
{
	ColorBox_DrawGrid();//���»�������
	GAL_Rectangle(PHYSICALGC, qsX + (BLOCK_W + 1)*fj, qsY + (BLOCK_H + 1)*fi, 12, 9, 0xffffff);
	mrc_refreshScreen(qsX, qsY, qsX + COLORBOX_W, qsY + COLORBOX_H);
}

//����ColorBox
VOID DrawColorBox(int ax, int ay)
{
	int i, j;

	//��¼��ʼ����
	qsX = ax, qsY = ay;

	//1.��������(11*20)
	ColorBox_DrawGrid();

	//2.���������ɫ(w=10, h=7)
	for(i=0; i<11; i++)
	{
		for(j=0; j<20; j++)
			GAL_FillBox(PHYSICALGC, ax+1 + j*(BLOCK_W + 1), ay+1 + i*(BLOCK_H + 1), BLOCK_W, BLOCK_H, colors[i][j]);
	}

	//3.ѡ����ɫ
	PaintFocusBlock(si, sj);
}

/**
 * \ѡ����ɫ
 * \���� px,py ������µ�����
 * \(0, 0)��ʾ��һ��
 */
VOID ColorBox_FocusByMouse(int px, int py)
{
	int i, j;

	for(j=0; j<20; ++j) //��λ�� j sj
	{
		if((px - qsX) >= j*(BLOCK_W + 1) && (px - qsX) <= (j+1)*(BLOCK_W + 1))
			break;
	}
	if(j >= 20) 
		return; 
	else
		sj = j;

	for(i=0; i<11; ++i) //��λ��
	{
		if((py - qsY) >= i*(BLOCK_H + 1) && (py - qsY) <= (i+1)*(BLOCK_H + 1))
			break;
	}
	if(i >= 11) 
		return; 
	else
		si = i;

	PaintFocusBlock(si, sj);
}

//�ƶ�����һ�����㴦
VOID ColorBox_FocusNext(int dct)
{
	switch(dct)
	{
	case MR_KEY_LEFT: //�����ƶ� j
		if(sj>0) 
			sj--;
		else
			sj = 19;
		PaintFocusBlock(si, sj);
		break;

	case MR_KEY_RIGHT:
		if(sj < 19) 
			sj++;
		else
			sj = 0;
		PaintFocusBlock(si, sj);
		break;

	case MR_KEY_UP: //�����ƶ� i
		if(si > 0) 
			si--;
		else
			si = 10;
		PaintFocusBlock(si, sj);
		break;

	case MR_KEY_DOWN:
		if(si < 10) 
			si++;
		else
			si = 0;
		PaintFocusBlock(si, sj);
		break;
	}
}

//��ȡѡ����ɫ
uint32 ColorBox_GetSelColor(VOID)
{
	return colors[si][sj];
}