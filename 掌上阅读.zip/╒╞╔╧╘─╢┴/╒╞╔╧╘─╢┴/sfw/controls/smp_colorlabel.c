#include "smp_colorlabel.h"

#include "string.h"
#include "smp.h"
#include "i18n.h"
#include "smp_edit.h"

#include "mrc_exb.h"

#define  WID_EDIT			1
#define	 EDIT_LENGTH		70

typedef struct
{
	Uint32	color;		//the font color
	PCWSTR	caption;	//the caption string
	PWSTR	editbuf;	//the input color edit buffer
	HWND	hEdit;		//the edit wnd handel
}CLRLABELDATA, *PCLRLABELDATA;


/**
 * \��������Int2HexString
 * \���ܽ�һ����������ת����ʮ�������ַ���
 */
PSTR Int2HexString(void* pi, int32 datalen)
{
	int i, j, l;
	uint8 buf5[5] = {0}, buf2[4];
	PSTR p1, str = NULL;
	uint8 test;

	//1.������ݺϷ���
	if(datalen < 1 || datalen > 4) return NULL;
	if(!pi) return NULL;

	//2.���㲢���뷵���ַ��������ڴ�
	l = 2*datalen + 2;
	str = (PSTR)malloc(l);
	if(!str) return NULL;
	mrc_memset(str, 0, l);

	//3.ת��
	p1 = str;	//���ջ�����

	mrc_memcpy(&i, pi, 4);
	mrc_writeBigEndianU32((uint32)i, buf2);
	mrc_memcpy(buf5, buf2+1, 3);	//ע�����������ݳ��ȣ���

	mrc_sprintf(p1, "%s", "#");
	p1++;
	for(j=0; j<3; j++)
	{
		test = buf5[j];
		if(test == 0)
			mrc_sprintf(p1, "%s", "00");
		else if(test > 0 && test <= 15)
			mrc_sprintf(p1, "0%X", test);
		else 
			mrc_sprintf(p1, "%X", test);

		p1 += 2;
	}

	//5.�����ִ�
	return str;
}

VOID SMP_Colorlabel_SetContent(HWND hWnd, PCWSTR caption, Uint32 color)
{
	PSTR hex;
	char buf[20] = {0};
	PCLRLABELDATA pData = _GET_WINDATA(hWnd, PCLRLABELDATA);

	pData->caption = caption;
	pData->color = color;
	hex = Int2HexString(&color, 4);
	asc2unicode(hex, buf, 20);
	mrc_free(hex);
	SMP_Edit_SetText(pData->hEdit, (PCWSTR)buf, 1, 0);
}

Uint32 SMP_Colorlabel_GetColor(HWND hWnd)
{
	PCLRLABELDATA pData = _GET_WINDATA(hWnd, PCLRLABELDATA);
	return pData->color;
}

LRESULT SMP_Colorlabel_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	PCLRLABELDATA pData = _GET_WINDATA(hWnd, PCLRLABELDATA);

	switch(Msg)
	{
	case WM_CREATE:
	{
		pData = (PCLRLABELDATA)SGL_MALLOC(sizeof(CLRLABELDATA));
		if(NULL == pData){
			SGL_TRACE("%s, %d: memory out\n", __FILE__, __LINE__);
			return 1;
		}
		SGL_MEMSET(pData, 0, sizeof(CLRLABELDATA));
		_SET_WINDATA(hWnd, pData);

		pData->editbuf = (PWSTR)SGL_MALLOC(18);
		SGL_MEMSET(pData->editbuf, 0, 18);

		pData->hEdit = SGL_CreateWindow(SMP_Edit_WndProc,
			1, 1, EDIT_LENGTH, SMP_ITEM_HEIGHT,
			WID_EDIT, ES_ALPHA|WS_TABSTOP, 0);
		SMP_Edit_SetInfo(pData->hEdit, SGL_LoadString(STR_COLOR), pData->editbuf, 16);
		_BGCOLOR(pData->hEdit) = _BGCOLOR(hWnd);
		_FGCOLOR(pData->hEdit) = _FGCOLOR(hWnd);
		SGL_AddChildWindow(hWnd, pData->hEdit);

		_SET_STYLE(hWnd, WS_FOCUSCHILD);

		break;
	}

	case WM_DESTROY:
	{
		if(pData->editbuf) SGL_FREE(pData->editbuf);
		if(pData) SGL_FREE(pData);
		break;
	}

	case WM_SHOW:
	{
		_LEFT(pData->hEdit) = _WIDTH(hWnd) - EDIT_LENGTH;
		_TOP(pData->hEdit) = DIV(_HEIGHT(hWnd) - SMP_ITEM_HEIGHT, 2);
		//SGL_SetFocusWindow(hWnd, pData->hEdit);

		break;
	}

	case WM_HIDE:
		break;

	case WM_PAINT:
	{
		int x=0, y=0;
		mr_colourSt color;
		mr_screenRectSt rect;
		HFONT font = SGL_GetSystemFont();

		SGL_WindowToScreen(hWnd, &x, &y);

		//paint the focus style
		/*if(_IS_SET_ANY(pData->hEdit, WS_FOCUSED))
		{
			uint32 clr = (System_Theme == THEME_CLASSIC) ? 0x00ADA8F8 : 0x141414;
			GAL_FillBox(PHYSICALGC, x, y, _WIDTH(hWnd), _HEIGHT(hWnd), clr);
		}*/

		SET_COLOR(color, pData->color);

		if(pData->caption)
		{
			int32 fw, fh;

			rect.x = (uint16)(x + SMP_ITEM_CONTENT_MARGIN); 
			rect.w = (uint16)(_WIDTH(hWnd) - 2*SMP_ITEM_CONTENT_MARGIN - EDIT_LENGTH); 
			mrc_unicodeTextWidthHeight((uint16*)pData->caption, (uint16)font, &fw, &fh);
			rect.h = (uint16)fh;
			rect.y = (uint16)(y + DIV(_HEIGHT(hWnd) - fh, 2));
			mrc_drawTextEx((PSTR)pData->caption, (int16)rect.x, (int16)rect.y, rect, color, 1, font);
		}
		break;
	}

	case WM_SETFOCUS:
	case WM_KILLFOCUS:
		SGL_UpdateWindow(hWnd);
		break;

	case WM_MOUSEDOWN:
		break;

	case WM_MOUSEUP:
		break;

	case WM_KEYDOWN:
		break;

	case WM_KEYUP:
		break;	

	case WM_COMMAND:
	{
		WID id = LOWORD(wParam);     //�ӿؼ�ID������WPARAM��λ������
		WORD code = HIWORD(wParam);  //wparam�����ĸ�λ�ֽڷ��õ����Ӵ���������Ӵ���ID
		
		if(WID_EDIT == id && code == SMP_EDITN_TEXTCHANGED)
		{
			PCSTR p;
			char buf[10], buf2[10] = {0};
			uint32 clr=COLOR_lightwhite;

			unicode2asc((char*)pData->editbuf, buf, 10);
			p = mrc_strchr((PCSTR)buf, '#');
			if(p)
				mrc_strcpy(buf2, p+1);
			else
				mrc_strcpy(buf2, buf);
			clr = mrc_strtoul(buf2, 0, 16);
			pData->color = clr;
			SGL_UpdateWindow(hWnd);
		}
		break;
	}

		//other window messages
	}
	return 0;
}
