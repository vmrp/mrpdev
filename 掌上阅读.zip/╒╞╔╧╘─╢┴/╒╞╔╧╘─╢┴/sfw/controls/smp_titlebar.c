#include "smp_titlebar.h"

#include "string.h"
#include "smp.h"
#include "bmp.h"

#ifdef FONT_SUPPORT
#include "fontRead.h"
#endif

//���������ݽṹ
typedef struct SMP_TitlebarData
{
	DWORD bmp;       // BMPͼƬID
	PCWSTR str;      // ��ʾ�ı�������
	int32 twidth;    // ʱ�����
	int32 height;    // �ַ��߶�
}LABELDATA, *PLABELDATA;

static int32 TlbarTimer;

static VOID UpdateTimeCB(int32 data)
{
	HWND hTitlebar = (HWND)data;
	mrc_timerStart(TlbarTimer, 60000, data, UpdateTimeCB, 0);
	SGL_UpdateWindow(hTitlebar);
}

//��ʾ����ʱ��
VOID ShowLocalTime(uint32 color)
{
	int32 width, height;
	int16 x, y;
	char timenow[6] = {0};
	mr_datetime time;
	uint16 font = MR_FONT_SMALL;

	mrc_getDatetime(&time);
	mrc_sprintf(timenow, "%d%s%d", time.hour, (time.minute <= 9) ? ":0" : ":", time.minute);
	mrc_textWidthHeight(timenow, FALSE, font, &width, &height);
	x = SCREEN_WIDTH - (int16)width - 5;
	y = DIV((SMP_HEADER_HEIGHT - (int16)height),2);
	mrc_drawText(timenow, x, y, PIXEL888RED(color), PIXEL888GREEN(color), PIXEL888BLUE(color), 0, font);
}

//ֹͣˢ��ʱ��
VOID SMP_Titlebar_StopTime(HWND hWnd)
{
	mrc_timerStop(TlbarTimer);
}

//��ʼˢ��ʱ��
VOID SMP_Titlebar_StartTime(HWND hWnd)
{
	mrc_timerStart(TlbarTimer, 60000, (int32)hWnd, UpdateTimeCB, TRUE);
}

//���ñ���������
VOID SMP_Titlebar_SetContent(HWND hWnd, DWORD bmpID, PCWSTR content)
{
	int32 w, h;
	PLABELDATA pData = _GET_WINDATA(hWnd, PLABELDATA);
	pData->str = content;
	pData->bmp = bmpID;

	GAL_TextWidthHeight((PSTR)pData->str, TRUE, (uint16)SGL_GetSystemFont(), &w, &pData->height);
	//mrc_textWidthHeight((PSTR)pData->str, TRUE, (uint16)SGL_GetSystemFont(), &w, &pData->height);

	mrc_textWidthHeight((PSTR)"00:00", TRUE, (uint16)MR_FONT_SMALL, &pData->twidth, &h);
}

//�����������¼�
LRESULT SMP_Titlebar_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	PLABELDATA pData = _GET_WINDATA(hWnd, PLABELDATA);

	switch(Msg)
	{
	case WM_CREATE:
	{
		pData = (PLABELDATA)SGL_MALLOC(sizeof(LABELDATA));
		if(NULL == pData){
			SGL_TRACE("%s, %d: memory out\n", __FILE__, __LINE__);
			return 1;
		}
		SGL_MEMSET(pData, 0, sizeof(LABELDATA));
		_SET_WINDATA(hWnd, pData);

		TlbarTimer = mrc_timerCreate();
		break;
	}

	case WM_DESTROY:
	{
		if(TlbarTimer)
		{
			mrc_timerStop(TlbarTimer);
			mrc_timerDelete(TlbarTimer);
		}
		if(pData)
			SGL_FREE(pData);
		break;
	}

	//case WM_BACKRUN:  //��̨����
	//	mrc_timerStop(TlbarTimer);
	//	break;

	case WM_SHOW:
		break;

	case WM_PAINT:
		{
			int x=0, y=0, w = 0, h = 0, i, mid;
			HBITMAP bmp;
			mr_colourSt color = {0,};
			mr_screenRectSt rect;
			HFONT font = SGL_GetSystemFont();
			PCWSTR pContent = pData->str;
			//uint32 fgClr; //����ɫ

			SGL_WindowToScreen(hWnd, &x, &y);

			//1.���ر���������ͼƬ
			bmp = SGL_LoadBitmap(BMP_TITLEBAR, &w, &h);
			for(i = 0; i < _WIDTH(hWnd) / w; i++)
				mrc_bitmapShowEx(bmp, (int16)(i*w), (int16)y, (int16)w, (int16)w, (int16)h, BM_COPY, 0, 0);
			if(MOD(_WIDTH(hWnd), w))
				mrc_bitmapShowEx(bmp, (int16)(i*w), (int16)y, (int16)w, (int16)MOD( _WIDTH(hWnd), w), (int16)h, BM_COPY, 0, 0);  //����������ͼƬ

			//fgClr = COLOR_lightwhite;
			SET_COLOR(color, _FGCOLOR(hWnd));

			rect.x = (uint16)(x + SMP_ITEM_CONTENT_MARGIN); 
			rect.y = (uint16)y;
			rect.w = (uint16)(_WIDTH(hWnd) - 2*SMP_ITEM_CONTENT_MARGIN - pData->twidth); 
			rect.h = (uint16)_HEIGHT(hWnd);

			if(RESID_INVALID != pData->bmp)
			{
				bmp = SGL_LoadBitmap(pData->bmp, &w, &h);
				if(bmp)
				{
					mrc_bitmapShowEx((uint16 *)bmp, (int16)rect.x, (int16)(y + DIV(_HEIGHT(hWnd)-h, 2)), (int16)w, (int16)w, (int16)h, BM_TRANSPARENT, 0, 0); //��ʾ����ͼƬ
					x += w + SMP_ITEM_CONTENT_MARGIN;
					rect.w -= w + SMP_ITEM_CONTENT_MARGIN;
				}
			}

			x += SMP_ITEM_CONTENT_MARGIN;
			rect.x = (int16)x;
			mid = DIV(_HEIGHT(hWnd)-pData->height, 2);

			//��ʾ��������
			//mrc_drawTextEx((PSTR)pContent, (int16)x, (int16)(y + mid - 1), rect, color, 1, font);
			GAL_DrawTextEx((PSTR)pContent, (int16)x, (int16)(y + mid - 1), rect, _FGCOLOR(hWnd), font, 1);

			ShowLocalTime(COLOR_lightwhite);
			mrc_timerStart(TlbarTimer, 60000, (int32)hWnd, UpdateTimeCB, 0);

			break;
		}
	}
	return 0;
}

