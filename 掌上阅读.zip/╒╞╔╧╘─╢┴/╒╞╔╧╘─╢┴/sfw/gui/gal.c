/*
** gal.c: implements of gal.h
** 
** Copyright (C) 2007-2008 SKY-MOBI AS.  All rights reserved.
**
** Create date: 2007-12-27 by wandonglin
**
** This file is part of the simple gui library.
** It may not be redistributed under any circumstances.
*/

#include "gal.h"

#ifdef FONT_SUPPORT
#include "fontread.h"
#endif

struct _screendevice scrdev;
uint8 System_Theme;  /*ϵͳ����ģʽ*/


//GAL��ʼ��
void GAL_Initialize (VOID)
{
	int32 fw, fh;

	//��ȡ��Ļ�ߴ�
	mrc_getScreenInfo(&(scrdev.scrInfo));

	//��ȡ������ߴ�
	mrc_unicodeTextWidthHeight((uint16*)"\x9f\x0e\x00\x00", MR_FONT_MEDIUM, &fw, &fh);   //���������ֿ���
	scrdev.font_mid.ch_w = fw, scrdev.font_mid.ch_h = fh;
	mrc_unicodeTextWidthHeight((uint16*)"\x0\x45", MR_FONT_MEDIUM, &fw, &fh);   //����Ӣ���ֿ���
	scrdev.font_mid.en_w = fw, scrdev.font_mid.en_h = fh;

	//��ȡ������ߴ�
	mrc_unicodeTextWidthHeight((uint16*)"\x9f\x0e\x00\x00", MR_FONT_BIG, &fw, &fh);   //���������ֿ���
	scrdev.font_big.ch_w = fw, scrdev.font_big.ch_h = fh;
	mrc_unicodeTextWidthHeight((uint16*)"\x0\x45", MR_FONT_BIG, &fw, &fh);   //����Ӣ���ֿ���
	scrdev.font_big.en_w = fw, scrdev.font_big.en_h = fh;

	//��ȡС����ߴ�
	mrc_unicodeTextWidthHeight((uint16*)"\x9f\x0e\x00\x00", MR_FONT_MEDIUM, &fw, &fh);   //���������ֿ���
	scrdev.font_sml.ch_w = fw, scrdev.font_sml.ch_h = fh;
	mrc_unicodeTextWidthHeight((uint16*)"\x0\x45", MR_FONT_MEDIUM, &fw, &fh);   //����Ӣ���ֿ���
	scrdev.font_sml.en_w = fw, scrdev.font_sml.en_h = fh;
}

//��ȡָ���ֺ��������
VOID GAL_GetFontSize(int32* w, int32 *h, uint16 font, BOOL isGB)
{
	switch(font)
	{
	case MR_FONT_BIG:
	{
		if(isGB)
			*w = scrdev.font_big.ch_w, *h = scrdev.font_big.ch_h;
		else
			*w = scrdev.font_big.en_w, *h = scrdev.font_big.en_h;
		break;
	}

	case MR_FONT_MEDIUM:
	{
		if(isGB)
			*w = scrdev.font_mid.ch_w, *h = scrdev.font_mid.ch_h;
		else
			*w = scrdev.font_mid.en_w, *h = scrdev.font_mid.en_h;
		break;
	}

	case MR_FONT_SMALL:
	{
		if(isGB)
			*w = scrdev.font_sml.ch_w, *h = scrdev.font_sml.ch_h;
		else
			*w = scrdev.font_sml.en_w, *h = scrdev.font_sml.en_h;
		break;
	}
	}
}

void GAL_Terminate (VOID)
{
	SGL_TRACE("%s, %d: Terminate GAL\n", __FILE__, __LINE__);
}


void GAL_Rectangle(GAL_GC gc, int x, int y, int w, int h, Uint32 pixel)
{
	int16 r = x + w - 1;
	int16 b = y + h - 1;
	mrc_drawLine((int16)x, (int16)y, r, (int16)y, PIXEL888RED(pixel), PIXEL888GREEN(pixel), PIXEL888BLUE(pixel));
	mrc_drawLine((int16)x, b, r, b, PIXEL888RED(pixel), PIXEL888GREEN(pixel), PIXEL888BLUE(pixel));
	mrc_drawLine((int16)x, (int16)y, (int16)x, b, PIXEL888RED(pixel), PIXEL888GREEN(pixel), PIXEL888BLUE(pixel));
	mrc_drawLine(r, (int16)y, r, b, PIXEL888RED(pixel), PIXEL888GREEN(pixel), PIXEL888BLUE(pixel));
}

void GAL_Rectangle2(GAL_GC gc, int x, int y, int w, int h, int line, Uint32 pixel)
{
	int i;
	for(i = 0; i < line; i++)
		GAL_Rectangle(gc, x+i, y+i, w-2*i, h-2*i, pixel);
}

void GAL_Rectangle3(GAL_GC gc, int x, int y, int w, int h, Uint32 pixel)
{
	int16 r = x + w -1;
	int16 b = y + h -1;

	//2����
	mrc_drawLine((int16)x+1, (int16)y, r-1, (int16)y, PIXEL888RED(pixel), PIXEL888GREEN(pixel), PIXEL888BLUE(pixel));
	mrc_drawLine((int16)x+1, b, r-1, b, PIXEL888RED(pixel), PIXEL888GREEN(pixel), PIXEL888BLUE(pixel));
	//2����
	mrc_drawLine((int16)x, (int16)y+1, (int16)x, b-1, PIXEL888RED(pixel), PIXEL888GREEN(pixel), PIXEL888BLUE(pixel));
	mrc_drawLine(r, (int16)y+1, r, b-1, PIXEL888RED(pixel), PIXEL888GREEN(pixel), PIXEL888BLUE(pixel));
}

void GAL_Rectangle4(GAL_GC gc, int x, int y, int w, int h, Uint32 pixel)
{
}

//����ɫ����������
void GAL_FillBox2(GAL_GC gc, int x, int y, int w, int h, Uint32 pixel, int d)
{
	//������
	GAL_DrawHLine(gc, x + 1, y, w - 2, pixel);
	GAL_DrawHLine(gc, x + 1, y + h - 1, w - 2, pixel);
	//������
	GAL_DrawVLine(gc, x, y + 1, h - 2, pixel);
	GAL_DrawVLine(gc, x + w - 1, y + 1, h - 2, pixel);
	//�������
	GAL_FillBox3(gc, x + 1, y + 1, w - 2, h - 2, pixel, d);

}
//����ɫ�����������ޱ߿�
void GAL_FillBox3(GAL_GC gc, int x, int y, int w, int h, Uint32 topclr, int d)
{
	int i;
	uint8 r, g, b;

	r = PIXEL888RED(topclr);
	g = PIXEL888GREEN(topclr);
	b = PIXEL888BLUE(topclr);

	//����ɫ
	for(i=0; i<h; i++)
	{
		mrc_drawLine(x, y+i, x+w-1, y+i, r, g, b);
		r -= d, g -= d, b -= d; 
	}
}

//��������������1 (�����߿�)
void FillShadeRange1(int16 x, int16 y, int16 w, int16 h, uint32 top, uint32 btm)
{
	int i;
	mr_colourSt topClr, clr;
	mr_screenRectSt r;

	SET_COLOR(topClr, top);
	clr.r = topClr.r - PIXEL888RED(btm), clr.g = topClr.g - PIXEL888GREEN(btm), clr.b = topClr.b - PIXEL888BLUE(btm);
	r.x = x, r.y = y, r.w = w, r.h = h;

	for(i=0; i<h; i++)
	{
		mrc_drawLine(r.x, r.y+i, r.x+r.w-1, r.y+i, 
			topClr.r-clr.r*i/h, topClr.g-clr.g*i/h, topClr.b-clr.b*i/h);
	}
}

//��������������2 (���߿�)
void FillShadeRange2(int16 x, int16 y, int16 w, int16 h, uint32 top, uint32 btm)
{
	mr_colourSt clr;
	mr_screenRectSt r;

	SET_COLOR(clr, top);
	r.x = x, r.y = y, r.w = w, r.h = h;

	//������
	mrc_drawLine(r.x+1, r.y, r.x+r.w-2, r.y, clr.r,clr.g,clr.b);
	mrc_drawLine(r.x+1, r.y+r.h-1, r.x+r.w-2, r.y+r.h-1, clr.r,clr.g,clr.b);
	//������
	mrc_drawLine(r.x, r.y+1, r.x, r.y+r.h-2, clr.r,clr.g,clr.b);
	mrc_drawLine(r.x+r.w-1, r.y+1, r.x+r.w-1, r.y+r.h-2, clr.r,clr.g,clr.b); 

	r.x += 1, r.y += 1, r.w -= 2, r.h -= 2;
	FillShadeRange1(r.x, r.y, r.w, r.h, top, btm);
}


void GAL_DrawLine(POINT start, POINT end, mr_colourSt color)
{
	mrc_drawLine(start.x, start.y, end.x, end.y, color.r,color.g,color.b);
}

void GAL_DrawRoundRange(int16 x, int16 y, int16 w, int16 h, uint32 pixel)
{
	mr_colourSt color;
	POINT topL, topR, btmL, btmR;

	color.r = PIXEL888RED(pixel);
	color.g = PIXEL888GREEN(pixel);
	color.b = PIXEL888BLUE(pixel);

	topL.x = x, topL.y = y; topR.x = x + w - 1, topR.y = y;
	btmL.x = x, btmL.y = y + h - 1; btmR.x = x + w - 1, btmR.y = y + h - 1;

	GAL_DrawLine(topL, topR, color);
	GAL_DrawLine(btmL, btmR, color);
	GAL_DrawLine(topL, btmL, color);
	GAL_DrawLine(topR, btmR, color);

	mrc_drawPointEx(topL.x+1, topL.y+1, color.r,color.g,color.b);
	mrc_drawPointEx(topL.x+2, topL.y+1, color.r,color.g,color.b);
	mrc_drawPointEx(topL.x+1, topL.y+2, color.r,color.g,color.b);

	mrc_drawPointEx(topR.x-1, topR.y+1, color.r,color.g,color.b);
	mrc_drawPointEx(topR.x-2, topR.y+1, color.r,color.g,color.b);
	mrc_drawPointEx(topR.x-1, topR.y+2, color.r,color.g,color.b);

	mrc_drawPointEx(btmL.x+1, btmL.y-1, color.r,color.g,color.b);
	mrc_drawPointEx(btmL.x+2, btmL.y-1, color.r,color.g,color.b);
	mrc_drawPointEx(btmL.x+1, btmL.y-2, color.r,color.g,color.b);

	mrc_drawPointEx(btmR.x-1, btmR.y-1, color.r,color.g,color.b);
	mrc_drawPointEx(btmR.x-2, btmR.y-1, color.r,color.g,color.b);
	mrc_drawPointEx(btmR.x-1, btmR.y-2, color.r,color.g,color.b);
}

void GAL_FillRoundRrct(int x, int y, int w, int h, uint32 pixel)
{
	int i;
	uint8 r, g, b;

	r = PIXEL888RED(pixel);
	g = PIXEL888GREEN(pixel);
	b = PIXEL888BLUE(pixel);

	x += 1, y += 1, w -= 2, h -= 2; 
	mrc_drawRect((int16)x, (int16)y, (int16)w, (int16)h, r, g, b);
	for(i=0; i<1; i++)
	{
		GAL_DrawHLine(PHYSICALGC, x+i+1, y-(i+1), w-2*(i+1), pixel);
		GAL_DrawHLine(PHYSICALGC, x+i+1, y+h+i, w-2*(i+1), pixel);
	}
	for(i=0; i<1; i++)
	{
		GAL_DrawVLine(PHYSICALGC, x-(i+1), y+(i+1), h-2*(i+1), pixel);
		GAL_DrawVLine(PHYSICALGC, x+w+i, y+(i+1), h-2*(i+1), pixel);
	}
}

void GAL_DrawHook(int ax, int ay, int lw, int rw, int d, uint32 pixel)
{
	while(d > 0)
	{
		GAL_Line(PHYSICALGC, ax, ay, ax-lw, ay-lw, pixel); //DIV(SMP_CHECKBOX_SIZE*2, 3)
		GAL_Line(PHYSICALGC, ax, ay, ax+rw, ay-rw, pixel); //DIV(SMP_CHECKBOX_SIZE*2, 3)
		d--;
		ay--;
	}
}

//��Ļ������ʾ���ֺ���
void GAL_DrawTextMidScn(char* text, uint32 pixel, int is_unicode) 
{ 
    int16 x,y; 
    int32 w,h;
	mr_colourSt clr;

	SET_COLOR(clr, pixel);
	
    mrc_textWidthHeight(text, is_unicode, MR_FONT_MEDIUM, &w, &h); 
    x = (int16)(GAL_Width(PHYSICALGC) - w )/2; 
    y =  (int16)(GAL_Height(PHYSICALGC)- h )/2; 
	mrc_drawText(text, x, y, clr.r,clr.g,clr.b, is_unicode, MR_FONT_MEDIUM); 
}


VOID GAL_DrawTextRight(PSTR pText, mr_screenRectSt rt, uint32 pixel, BOOL isUnicode, uint16 font)
{
	int32 w, h;
	mr_colourSt color;

	SET_COLOR(color, pixel);
#ifdef FONT_SUPPORT
	_textWidthHeight(pText, &w, &h, MR_SET_GB, MR_FONT_MEDIUM);
	_drawText(pText, (int16)(rt.x + (rt.w - w - 2)), (int16)(rt.y + (rt.h - h)/2),  color, MR_SET_GB, MR_FONT_MEDIUM);
#else
	mrc_textWidthHeight(pText, font, isUnicode, &w, &h);
	mrc_drawText(pText, (int16)(rt.x + (rt.w - w - 2)), (int16)(rt.y + (rt.h - h)/2), color.r,color.g,color.b, isUnicode, font);
#endif
}

VOID GAL_DrawTextLeft(PSTR pText, mr_screenRectSt rt, uint32 pixel, BOOL isUnicode, uint16 font)
{
	int32 w, h;
	uint8 r, g, b;

	r = PIXEL888RED(pixel);
	g = PIXEL888GREEN(pixel);
	b = PIXEL888BLUE(pixel);
	mrc_textWidthHeight(pText, isUnicode, font, &w, &h);
	mrc_drawText(pText, (int16)(rt.x + 2), (int16)(rt.y + (rt.h - h)/2), r, g, b, font, isUnicode);
}

VOID GAL_DrawTextA(PSTR pText, int x, int y, uint32 pixel, BOOL isUnicode, uint16 font)
{
	uint8 r, g, b;

	r = PIXEL888RED(pixel);
	g = PIXEL888GREEN(pixel);
	b = PIXEL888BLUE(pixel);

	mrc_drawText(pText, (int16)(x), (int16)(y), r, g, b, isUnicode, font);
	mrc_drawText(pText, (int16)(x+1), (int16)(y), r+0, g+0, b+0, isUnicode, font);
}

VOID GAL_DrawText(PSTR pText, int16 x, int16 y, uint32 pixel, uint16 font, BOOL isUnicode)
{
	mr_colourSt colorst;
	SET_COLOR(colorst, pixel);

#ifdef FONT_SUPPORT
	_drawText(pText, x, y, colorst, 1, MR_FONT_BIG);
#else
	mrc_drawText(pText, x, y, colorst.r, colorst.g, colorst.b, isUnicode, font);
#endif

}

VOID GAL_DrawTextEx(PSTR pText, int16 x, int16 y, mr_screenRectSt rect, uint32 pixel, uint16 font, int flag)
{
	mr_colourSt colorst;
	SET_COLOR(colorst, pixel);

#ifdef FONT_SUPPORT
	_drawTextLeft(pText, x, y, rect, colorst, 1, font);
#else
	mrc_drawTextEx(pText, x, y, rect, colorst, flag, font);
#endif

}

VOID GAL_TextWidthHeight(PSTR pText, BOOL isUnicode, uint16 font, int32 *w, int32 *h)
{
#ifdef FONT_SUPPORT
	_textWidthHeight(pText, w, h, 1, font);
#else
	mrc_textWidthHeight(pText, isUnicode, font, w, h);
#endif
}
