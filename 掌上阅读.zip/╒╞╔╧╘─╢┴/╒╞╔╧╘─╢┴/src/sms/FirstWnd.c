#include "FirstWnd.h"
#include "opendlg.h"
#include "topwnd.h"
#include "textwnd.h"

#include "bmp.h"
#include "string.h"
#include "i18n.h"

#include "smp.h"
#include "smp_menu.h"
#include "smp_titlebar.h"
#include "smp_toolbar.h"
#include "smp_menuwnd.h"
#include "smp_edit.h"
#include "smp_button.h"
#include "smp_msgbox.h"
#include "smp_flashbox.h"
#include "smp_label.h"
#include "smp_list.h"
#include "smp_progbar.h"
#include "smp_combobox.h"
#include "smp_list.h"
#include "smp_scrollview.h"

#include "mrc_base_i.h"
#include "plat.h"

#define  ITEM_LEN  (SCREEN_WIDTH-SMP_SCRBAR_WIDTH-2*SMP_ITEM_SPACE)


int GetReadHistroyNum(VOID)
{
	return 3;
}

static const char* Test[3] = 
{
	"������.txt",
	"��������1.txt",
	"��¥��.txt"
};
VOID GetReadHistroyNumData(int index, PSMPROWDATA pRowData)
{
	int w, h;

	if (!pRowData || index < 0 || index > 3)
		return;

	pRowData->margin = 4; 
	pRowData->hBmp = SGL_LoadBitmap(BMP_TEXT, &w, &h);
	pRowData->colWidth0 = (uint16)w;
	pRowData->colHeight0 = (uint16)h;
	pRowData->cols[0].width = SCREEN_WIDTH - w - 24;
	pRowData->cols[0].str = (PSTR)Test[index];
}

enum
{
	FIRSTWND_SCRVIEW,
	FIRSTWND_TITLEBAR,
	FIRSTWND_TOOLBAR,
	FIRSTWND_LIST,
	FIRSTWND_LABEL,
	FIRSTWND_LABEL_MOR,		//�������label
	FIRSTWND_LABEL_THEME,	//�������label
	FIRSTWND_LABEL_SENTCE,	//�������label sentence
	FIRSTWND_LABEL_URL,		//�������
	FIRSTWND_BOOK1, FIRSTWND_BOOK2, FIRSTWND_BOOK3,
	FIRSTWND_OPTMENU,
	FIRSTWND_LAST
};

//ѡ������Ĳ˵�
static const DWORD miOptions[] = 
{
	STR_OPEN,		//0.��
	STR_SET,		//1.����
	STR_BACKRUN,	//2.��̨����
	STR_HELP,		//3.����
	STR_ABOUT,		//4.����
	STR_EXIT		//5.�˳�
};

/**
 * \��ʾ�˵�
 */
static VOID ShowOptMenu(HWND hWnd) 
{
	int start = 0;

	//��ղ˵���
	SMP_Menu_ClearMenuItems();         

	//1.��ѡ��
	SMP_Menu_SetMenuItem2(start, miOptions, TABLESIZE(miOptions));
	start += TABLESIZE(miOptions);

	//��ʾ�˵�����
	SMP_Menu_Popup(FIRSTWND_OPTMENU, SMP_MENUS_BOTTOMLEFT, hWnd, 0, _HEIGHT(hWnd) - SMP_TOOLBAR_HEIGHT , NULL);
}

LRESULT FirstWnd_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	HWND hScrview, hContent, hControl; 
	switch(Msg)
	{
	case WM_CREATE:
	{
		int x, y, i;

		_BGCOLOR(hWnd) = COLOR_MAIN_BG;
		_FGCOLOR(hWnd) = COLOR_MAIN_FG;
		y = 0;
		x = SMP_ITEM_SPACE;

//-------�����Ӵ���-------------------------------------------------------------------------------------------
		//����������
		hControl = SGL_CreateWindow(SMP_Titlebar_WndProc,0, 0, SCREEN_WIDTH, SMP_HEADER_HEIGHT, FIRSTWND_TITLEBAR, SMP_TITLEBAR_STATIC, 0);
		SMP_Titlebar_SetContent(hControl, BMP_ICO1, SGL_LoadString(STR_HELLO));
		_FGCOLOR(hControl) = COLOR_MAIN_FG;
		SGL_AddChildWindow(hWnd, hControl);

		//����������ͼ��������
		hScrview = SGL_CreateWindow(SMP_ScrollView_WndProc, 0, SMP_HEADER_HEIGHT, SMP_CONTENT_VIEW_WIDTH, SMP_CONTENT_VIEW_HEIGHT,
			FIRSTWND_SCRVIEW, WS_TABSTOP, 0);
		hContent =  SMP_ScrollView_GetContentView(hScrview);  //��ȡ������ͼ����
		_BGCOLOR(hContent) = _BGCOLOR(hWnd), _FGCOLOR(hContent) = _FGCOLOR(hWnd);

		y += SMP_ITEM_SPACE;

		//����label(����Ķ�)
		hControl = SGL_CreateWindow(SMP_Label_WndProc, x, y, ITEM_LEN, SMP_ITEM_HEIGHT, FIRSTWND_LABEL, SMP_LABELS_LINK | SMP_LABELS_VCENTER, 0);
		SMP_Label_SetContent(hControl, RESID_INVALID, SGL_LoadString(STR_RECENT), 500);
		_BGCOLOR(hControl) = _BGCOLOR(hWnd), _FGCOLOR(hControl) = _FGCOLOR(hWnd);
		SGL_AddChildWindow(hContent, hControl);

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		//����list��ʾ����ʷ�ļ�
		//hControl = SGL_CreateWindow(SMP_List_WndProc, x, y, ITEM_LEN, 3*SMP_ITEM_HEIGHT+10, FIRSTWND_LIST, WS_TABSTOP | SMP_LISTS_NOSCRBAR, 0);
		//SMP_List_SetDataProvider(hControl, GetReadHistroyNum, GetReadHistroyNumData);
		//_BGCOLOR(hControl) = _BGCOLOR(hWnd), _FGCOLOR(hControl) = _FGCOLOR(hWnd);
		//SGL_AddChildWindow(hContent, hControl);
		//y += 3*SMP_ITEM_HEIGHT + 10 + SMP_ITEM_SPACE;
		for(i=0; i<3; i++)
		{
			//����label(����Ķ�����...)
			hControl = SGL_CreateWindow(SMP_Label_WndProc, x, y, ITEM_LEN, SMP_ITEM_HEIGHT, FIRSTWND_BOOK1+i, WS_TABSTOP|SMP_LABELS_VCENTER, 0);
			SMP_Label_SetContent(hControl, RESID_INVALID, SGL_LoadString(STR_MORE), 500);
			_BGCOLOR(hControl) = _BGCOLOR(hWnd), _FGCOLOR(hControl) = _FGCOLOR(hWnd);
			SGL_AddChildWindow(hContent, hControl);
			_LISTENER(hControl) = hWnd; 

			y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;
		}

		//����label(����Ķ�����...)
		hControl = SGL_CreateWindow(SMP_Label_WndProc, x, y, ITEM_LEN, SMP_ITEM_HEIGHT, FIRSTWND_LABEL_MOR, WS_TABSTOP | SMP_LABELS_LINK | SMP_LABELS_VCENTER, 0);
		SMP_Label_SetContent(hControl, RESID_INVALID, SGL_LoadString(STR_MORE), 500);
		_BGCOLOR(hControl) = _BGCOLOR(hWnd), _FGCOLOR(hControl) = _FGCOLOR(hWnd);
		SGL_AddChildWindow(hContent, hControl);
		_LISTENER(hControl) = hWnd; 

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		//����label(��������)
		hControl = SGL_CreateWindow(SMP_Label_WndProc, x, y, ITEM_LEN, SMP_ITEM_HEIGHT, FIRSTWND_LABEL_THEME, WS_TABSTOP | SMP_LABELS_LINK | SMP_LABELS_VCENTER, 0);
		SMP_Label_SetContent(hControl, RESID_INVALID, SGL_LoadString(STR_CHGTHEME), 500);
		_BGCOLOR(hControl) = _BGCOLOR(hWnd), _FGCOLOR(hControl) = _FGCOLOR(hWnd);
		SGL_AddChildWindow(hContent, hControl);
		_LISTENER(hControl) = hWnd; 

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		//����label(����չʾ)
		hControl = SGL_CreateWindow(SMP_Label_WndProc, x, y, ITEM_LEN, 2*SMP_ITEM_HEIGHT, FIRSTWND_LABEL_SENTCE, WS_TABSTOP | SMP_LABELS_LINK | SMP_LABELS_NEWLINE, 0);
		SMP_Label_SetContent(hControl, RESID_INVALID, SGL_LoadString(STR_SENTCE1), 500);
		_BGCOLOR(hControl) = _BGCOLOR(hWnd), _FGCOLOR(hControl) = _FGCOLOR(hWnd);
		SGL_AddChildWindow(hContent, hControl);
		_LISTENER(hControl) = hWnd; 

		y += 2*SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		//����label(��ַ����)
		hControl = SGL_CreateWindow(SMP_Label_WndProc, x, y, ITEM_LEN, SMP_ITEM_HEIGHT, FIRSTWND_LABEL_URL, WS_TABSTOP | SMP_LABELS_LINK | SMP_LABELS_VCENTER, 0);
		SMP_Label_SetContent(hControl, RESID_INVALID, SGL_LoadString(STR_URL), 500);
		_BGCOLOR(hControl) = _BGCOLOR(hWnd), _FGCOLOR(hControl) = _FGCOLOR(hWnd);
		SGL_AddChildWindow(hContent, hControl);
		_LISTENER(hControl) = hWnd; 

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		SGL_AddChildWindow(hWnd, hScrview);

		//����������
		hControl = SGL_CreateWindow(SMP_Toolbar_WndProc, 0,  _HEIGHT(hWnd) - SMP_TOOLBAR_HEIGHT, _WIDTH(hWnd), SMP_TOOLBAR_HEIGHT, FIRSTWND_TOOLBAR, 0, 0);
		_FGCOLOR(hControl) = COLOR_MAIN_FG;
		SMP_Toolbar_SetStrings(hControl,  STR_OPTIONS , RESID_INVALID, STR_EXIT, TRUE);
		SGL_AddChildWindow(hWnd, hControl);

		break;
	}

	case WM_DESTROY:
		break;

	case WM_INITFOCUS:
		SGL_FocusNext(hWnd, TRUE);
		break;

	case WM_SHOW:
		break;

	case WM_HIDE:
		break;

	case WM_KEYDOWN:
	case WM_KEYDOWNREPEAT:
	{
		switch(wParam)
		{
		case MR_KEY_UP:
			SGL_FocusNext(hWnd, FALSE);
			return 1;
		case MR_KEY_DOWN:
			SGL_FocusNext(hWnd, TRUE);
			return 1;
		}
		break;
	}	

	case WM_KEYUP:
	{
		switch(wParam)
		{
		case MR_KEY_SOFTRIGHT:
			SMP_ExitBox(hWnd);
			break;

		case MR_KEY_SOFTLEFT:
			ShowOptMenu(hWnd);
			//HideTopWindow(TOPWND_FIRSTWND, 0, 1);
			//ShowTopWindow(TOPWND_ZYUEMAIN, NULL, 0);
			break;
		}

		break;	
	}//end of case WM_KEYUP:

	case WM_COMMAND:
	{
		WID id = LOWORD(wParam);
		WORD code = HIWORD(wParam);

		switch(id)
		{
		case TOPWIN_MSGBOX_EXIT:
			if(code == ID_OK) 
			{
				HideRichedit();
				mrc_exit();
			}
			break;

		case FIRSTWND_OPTMENU:
		{
			switch(code)
			{
			case STR_OPEN:		//��->�ļ�
				HideTopWindow(_WID(hWnd), 0, 0);
				ShowOpenDlg(TOPWND_ZYUEMAIN, FALSE, FILE_TEXT);
				break;

			case STR_HELP:		//����
				ShowTextInfo(_WID(hWnd), SGL_LoadString(STR_HELP_READER), SGL_LoadString(STR_HELP));
				break;

			case STR_ABOUT:		//����
				ShowTextInfo(_WID(hWnd), SGL_LoadString(STR_ABOUT_STR), SGL_LoadString(STR_ABOUT));
				break;

			case STR_SET:		//��������
				ShowTopWindow(TOPWND_SETALL, 0, 0);
				break;

			case STR_BACKRUN:	//����->��̨����
				BackRunApp(203103);
				break;

			case STR_EXIT:		//�˳�
				SMP_ExitBox(hWnd);
				break;
			}
		}// END OF case RICHEDIT_OPTMENU:

		}

		break;
	}//end of case WM_COMMAND:

	}
	return SMP_MenuWnd_WndProc(hWnd, Msg, wParam, lParam);
}