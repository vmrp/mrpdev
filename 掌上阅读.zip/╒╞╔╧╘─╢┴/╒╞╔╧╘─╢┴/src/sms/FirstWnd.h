#ifndef _FIRSTWND_H_
#define _FIRSTWND_H_

#include "window.h"
#include "zyue.h"

/**
 * \��һ������
 */
LRESULT FirstWnd_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);

#endif