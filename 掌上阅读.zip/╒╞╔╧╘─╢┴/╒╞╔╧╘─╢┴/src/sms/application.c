#include "application.h"
#include "topwnd.h"
#include "mrc_exb.h"

#include "smp.h"
#include "bmp.h"
#include "md5.h"

#ifdef FONT_SUPPORT
#include "fontRead.h"
#endif

#define CLOSE_FILE(fd){if(fd){mrc_close(fd); fd=0;}}

VOID CreatMainWin(int32 data)
{
	if(data)
		mrc_timerDelete(data);
	System_Theme = THEME_CLASSIC;
	InitTopWindow(); 
	ShowTopWindow(TOPWND_MAINWND, 0, 0);
}

VOID DrawBmp(DWORD BMPID, uint32 BgClr)
{
	int w,h;
	HBITMAP bmp = SGL_LoadBitmap(BMPID, &w, &h); 
	if(bmp)
		mrc_bitmapShowEx(bmp, (int16)(DIV(SCREEN_WIDTH,2)-DIV(w,2)), (int16)(DIV(SCREEN_HEIGHT,2)-DIV(h,2)), (int16)w, (int16)w, (int16)h, BM_COPY, 0, 0); 
}

VOID ShowLogo(VOID)
{
	int32 timer1;

	GAL_ClearScreen(0x103554);
	DrawBmp(BMP_LOGO_STAR, 0x103554);
	GAL_Flush(PHYSICALGC);

	timer1 = mrc_timerCreate();
	mrc_timerStart(timer1, 200, timer1, CreatMainWin, 0);
}


int32 Check_Authorized(VOID)
{
	int32 ret = MR_FAILED;
	uint8 md5[17] = {0};
	uint8 cor[17] = {0};
	int32 fd, len;
	PSTR name = mrc_getPackName();

#ifdef WIN32
	return	MR_SUCCESS;
#endif

	len = mrc_getLen(name) - 260;
	fd = mrc_open(name, MR_FILE_RDONLY);
	if(fd > 0)
	{
		mrc_seek(fd, -16, MR_SEEK_END);
		mrc_read(fd, cor, 16);
		CLOSE_FILE(fd);

		if(MR_SUCCESS == MD5_MakeFromFile((char*)"adce321", name, 240, len, md5))
			ret = (mrc_memcmp(md5, cor, 16) == 0) ? MR_SUCCESS : MR_FAILED;
		else
			ret = MR_FAILED;
	}else
		ret = MR_FAILED;

	return ret;
}


int InitApplication(VOID)
{	
	if(1)//MR_SUCCESS == Check_Authorized())
	{
		ShowLogo();
	}else{
		mrc_clearScreen(0,0,0);
		mrc_drawText("�������ƻ���", 20, 20, 30,144,255, 0, MR_FONT_MEDIUM);
		mrc_refreshScreen(0,0,240,320);
	}

	return 0;
}

static BOOL errorcorrept = FALSE;
int ExitApplication(VOID)
{
	if(!errorcorrept)
	{
		mrc_EffSetCon(0, 0, (int16)GAL_Width(PHYSICALGC), (int16)GAL_Height(PHYSICALGC), 128, 128, 128);
		//mrc_clearScreen(0,0,0);
		GAL_DrawTextMidScn("\x6b\x63\x57\x28\x90\x0\x51\xfa\x30\x2\x30\x2\x30\x2", 0xf0f0f0, 1);
		//mrc_refreshScreen(0,0,240,320);
		GAL_Flush(PHYSICALGC);
	}
	return 0;
}


int PauseApplication(VOID)
{
	// TODO: Add your code here!
	return 0;
}


int ResumeApplication(VOID)
{
	// TODO: Add your code here!
	return 0;
}

VOID SGL_ExitError(PSTR info)
{
	errorcorrept = TRUE;
	mrc_clearScreen(0,0,0);
	mrc_drawText(info, 20, 20, 255, 0, 0, 0, MR_FONT_MEDIUM);
	mrc_refreshScreen(0,0,240,320);
	SGL_TRACE("�ڴ治�㣡");
	mrc_exit();
}