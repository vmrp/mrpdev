#include "i18n.h"

#include "mainwnd.h"

#include "smp.h"
#include "smp_menu.h"
#include "smp_toolbar.h"
#include "smp_menuwnd.h"
#include "smp_edit.h"
#include "smp_button.h"
#include "smp_msgbox.h"
#include "smp_flashbox.h"
#include "bmp.h"
#include "smp_label.h"
#include "plt_msgbox.h"
#include "smp_progbar.h"
#include "smp_combobox.h"
#include "smp_list.h"
#include "topwnd.h"
#include "string.h"
#include "smp_titlebar.H"

static const DWORD miOptions[] = 
{
	STR_HELP,
	STR_ABOUT,
	STR_EXIT
};

static const DWORD miConnections[] =
{
	STR_OK,
	STR_CANCEL
};

static VOID ShowOptMenu(HWND hWnd)
{
	SMP_Menu_ClearMenuItems();
	SMP_Menu_SetMenuItem2(0, miOptions, TABLESIZE(miOptions));
	SMP_Menu_SetMenuItem2(TABLESIZE(miOptions), miConnections, TABLESIZE(miConnections));
	SMP_Menu_SetSubMenu(0, TABLESIZE(miOptions));
	SMP_Menu_Popup(MAINWND_OPTMENU, SMP_MENUS_BOTTOMLEFT, hWnd, 0, _HEIGHT(hWnd) - SMP_TOOLBAR_HEIGHT, NULL);
}


static UCHAR tmp[100];
LRESULT MAINWND_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	HWND hControl;
	
	switch(Msg)
	{
	case WM_CREATE:
	{
		int x, y;

		//����������
		hControl = SGL_CreateWindow(SMP_Titlebar_WndProc,0, 0, SCREEN_WIDTH, SMP_HEADER_HEIGHT, 
			MAINWND_TITLEBAR, SMP_TITLEBAR_STATIC, 0);
		SMP_Titlebar_SetContent(hControl, BMP_ICO1, SGL_LoadString(STR_TITLE_MAIN));
		_FGCOLOR(hControl) = COLOR_MAIN_FG;
		SGL_AddChildWindow(hWnd, hControl);
		
		hControl = SGL_CreateWindow(SMP_Toolbar_WndProc, 
			0, SCREEN_HEIGHT - SMP_TOOLBAR_HEIGHT, SCREEN_WIDTH, SMP_TOOLBAR_HEIGHT,
			MAINWND_TOOLBAR, 0, 0);
		SMP_Toolbar_SetStrings(hControl, STR_OPTIONS, RESID_INVALID, STR_BACK, FALSE);
		_FGCOLOR(hControl) = COLOR_MAIN_FG;
		SGL_AddChildWindow(hWnd, hControl);

		x = SMP_ITEM_MARGIN;
		y = SMP_HEADER_HEIGHT + SMP_ITEM_MARGIN;

		//���ܺ���
		hControl = SGL_CreateWindow(SMP_Label_WndProc,
			x, y, SMP_ITEM_LENGTH, SMP_ITEM_HEIGHT,
			MAINWND_LABEL, 
			SMP_LABELS_VCENTER|WS_TRANSPARENT|SMP_LABELS_STATIC|SMP_LABELS_LINK, 0);
		SMP_Label_SetContent(hControl, RESID_INVALID, SGL_LoadString(STR_HINT1));
		SGL_AddChildWindow(hWnd, hControl);

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		hControl = SGL_CreateWindow(SMP_Edit_WndProc,
			x, y, SMP_ITEM_LENGTH, SMP_ITEM_HEIGHT,
			MAINWND_EDIT, WS_TABSTOP, 0);
		SMP_Edit_SetInfo(hControl, SGL_LoadString(STR_YES), tmp, 100);
		SGL_AddChildWindow(hWnd, hControl);
		wstrcpy(tmp, SGL_LoadString(STR_OK));

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		//��������
		hControl = SGL_CreateWindow(SMP_Label_WndProc,
			x, y, SMP_ITEM_LENGTH, SMP_ITEM_HEIGHT,
			MAINWND_LABEL, 
			SMP_LABELS_VCENTER|WS_TRANSPARENT|SMP_LABELS_STATIC|SMP_LABELS_LINK, 0);
		SMP_Label_SetContent(hControl, RESID_INVALID, SGL_LoadString(STR_HINT2));
		SGL_AddChildWindow(hWnd, hControl);

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		hControl = SGL_CreateWindow(SMP_Edit_WndProc,
			x, y, SMP_ITEM_LENGTH, SMP_ITEM_HEIGHT,
			MAINWND_EDIT, WS_TABSTOP, 0);
		SMP_Edit_SetInfo(hControl, SGL_LoadString(STR_YES), tmp, 100);
		SGL_AddChildWindow(hWnd, hControl);
		wstrcpy(tmp, SGL_LoadString(STR_OK));

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		//��ʱ����
		hControl = SGL_CreateWindow(SMP_Label_WndProc,
			x, y, SMP_ITEM_LENGTH, SMP_ITEM_HEIGHT,
			MAINWND_LABEL, 
			SMP_LABELS_VCENTER|WS_TRANSPARENT|SMP_LABELS_STATIC|SMP_LABELS_LINK, 0);
		SMP_Label_SetContent(hControl, RESID_INVALID, SGL_LoadString(STR_HINT3));
		SGL_AddChildWindow(hWnd, hControl);

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		hControl = SGL_CreateWindow(SMP_Edit_WndProc,
			x, y, SMP_ITEM_LENGTH, SMP_ITEM_HEIGHT,
			MAINWND_EDIT, WS_TABSTOP, 0);
		SMP_Edit_SetInfo(hControl, SGL_LoadString(STR_YES), tmp, 100);
		SGL_AddChildWindow(hWnd, hControl);
		wstrcpy(tmp, SGL_LoadString(STR_OK));

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		//��ʼ����
		hControl = SGL_CreateWindow(SMP_Button_WndProc,
			x, y, 80, SMP_ITEM_HEIGHT,
			MAINWND_BUTTON,  WS_TABSTOP | SMP_BUTTONS_HCENTER | SMP_BUTTONS_VCENTER, 0);
		SMP_Button_SetTitle(hControl, SGL_LoadString(STR_HINT4));
		SGL_AddChildWindow(hWnd, hControl);
		//ת����̨����
		hControl = SGL_CreateWindow(SMP_Button_WndProc,
			SCREEN_WIDTH - SMP_ITEM_MARGIN - 80, y, 80, SMP_ITEM_HEIGHT,
			MAINWND_BUTTON,  WS_TABSTOP | SMP_BUTTONS_HCENTER | SMP_BUTTONS_VCENTER, 0);
		SMP_Button_SetTitle(hControl, SGL_LoadString(STR_HINT5));
		SGL_AddChildWindow(hWnd, hControl);

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		hControl = SGL_CreateWindow(SMP_ProgBar_WndProc,
			x, SCREEN_HEIGHT - SMP_TOOLBAR_HEIGHT - SMP_ITEM_MARGIN - 20,
			SMP_ITEM_LENGTH, 20,
			MAINWND_PROGBAR, 0, 0);
		SMP_ProgBar_SetValue(hControl, 30, FALSE, FALSE);
		SGL_AddChildWindow(hWnd, hControl);

		/*hControl2 = SGL_CreateWindow(SGL_Window_WndProc,
			0, SMP_HEADER_HEIGHT + 180, SCREEN_WIDTH, SMP_ITEM_HEIGHT,
			0, WS_TABSTOP | WS_FOCUSCHILD, 0);
		_BGCOLOR(hControl2) = COLOR_blue;
		SGL_AddChildWindow(hWnd, hControl2);

		hControl = SGL_CreateWindow(SMP_ComboBox_WndProc,
			0, 0, 70, SMP_ITEM_HEIGHT,
			MAINWND_COMBO1, WS_TABSTOP, 0);
		SMP_ComboBox_SetItems(hControl, miOptions, 5);
		SGL_AddChildWindow(hControl2, hControl);

		hControl = SGL_CreateWindow(SMP_ComboBox_WndProc,
			80, 0, 70, SMP_ITEM_HEIGHT,
			MAINWND_COMBO2, WS_TABSTOP, 0);
		SMP_ComboBox_SetItems(hControl, miConnections, 2);
		SGL_AddChildWindow(hControl2, hControl);

		hControl = SGL_CreateWindow(SMP_ComboBox_WndProc,
			160, 0, 70, SMP_ITEM_HEIGHT,
			MAINWND_COMBO2, WS_TABSTOP, 0);
		SMP_ComboBox_SetItems(hControl, miConnections, 2);
		SGL_AddChildWindow(hControl2, hControl);*/

		//hControl = SGL_CreateWindow(SMP_DatePicker_WndProc, 
		//	20, SMP_HEADER_HEIGHT + 210, 120, SMP_ITEM_HEIGHT, 
		//	0, WS_TABSTOP, 0);
		//SMP_DatePicker_SetDate(hControl, 2008, 8, 8, FALSE, FALSE);
		//SGL_AddChildWindow(hWnd, hControl);
		break;
	}

	case WM_SHOW:
	{
		_BGCOLOR(hWnd) = 0xb0c4de;

		break;
	}

	case WM_INITFOCUS:
	{
		SGL_FocusNext(hWnd, TRUE);
		break;
	}

	case WM_KEYDOWN:
	case WM_KEYDOWNREPEAT:
	{
		switch(wParam)
		{
		case MR_KEY_UP:
			SGL_FocusNext(hWnd, FALSE);
			return 1;
		case MR_KEY_DOWN:
			SGL_FocusNext(hWnd, TRUE);
			return 1;
		}
		break;
	}	

	case WM_KEYUP:
	{
		switch(wParam)
		{
		case MR_KEY_SOFTLEFT:
			ShowOptMenu(hWnd);
			return 1;
		case MR_KEY_SOFTRIGHT:
			SMP_ExitBox(hWnd);
			//HideTopWindow(_WID(hWnd), FALSE, TRUE);
			return 1;
		}
		break;
	}

	case WM_COMMAND:
	{
		WID id = LOWORD(wParam);
		WORD code = HIWORD(wParam);

		switch(id)
		{

		case MAINWND_OPTMENU:
		{
			switch(code)
			{
			case STR_OK:
				break;
			case STR_CANCEL:
				SMP_MsgBox(0, hWnd, NULL, SGL_LoadString(STR_YES), SGL_LoadString(STR_NO), ID_OK | SMP_MSGBOXS_AUTOCLOSE, NULL);
				break;
			case STR_ABOUT:
				break;
			case STR_HELP:
				break;
			case STR_EXIT:
				_SET_STYLE(hWnd, WS_KEEPFOCUS);
				break;
			}
			break;
		}
			
		}
		
		break;
	}

	case WM_MODALSHOW:
	case WM_MENUSHOW:
	{
		break;
	}

	case WM_MODALHIDE:
	case WM_MENUHIDE:
	{
		break;
	}
	}

	return SMP_MenuWnd_WndProc(hWnd, Msg, wParam, lParam);
}

