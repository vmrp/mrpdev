#ifndef _STE_CENTER_H_
#define _STE_CENTER_H_

#include "window.h"

/**
 * \���ô���
 */
LRESULT SetAll_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);


#endif
