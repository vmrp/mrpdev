#include "bookmark.h"


void selectBookMark(){
	/*selector = null;
	currentWindow = null;
	System.gc();

	byte[][] selectbmitems = new byte[currentMarks.size()][];
	for (int i = 0; i < selectbmitems.length; i++){
		selectbmitems[i] = ((Mark) currentMarks.elementAt(i)).
			data;
	}

	selector = new Selector("ѡ����ǩ", selectbmitems, 0);
	currentWindow = selector;
	selectbmitems = null;*/
}

void addBookMark(){
	/*int start = ((TxtLine) mylines.elementAt(0)).offset;
	int len = start + bufferTxt.length - currentOffset;
	len = len > 24 ? 24 : len;
	byte[] b = new byte[len];
	System.arraycopy(bufferTxt, currentOffset - start, b, 0,
		b.length);

	Mark mark = new Mark(0, currentOffset, b);
	currentMarks.insertElementAt(mark, 0);
	b = null;
	mark = null;
	System.gc();
	message.showMessage("������ǩ", new String[] {"������ǩ�ɹ���",
		" ", "���������������"});
	currentWindow = null;
	menu = null;
	showMenu = false;*/
}

void deleteBookMark(){
	/*selector = null;
	currentWindow = null;
	System.gc();

	byte[][] deletebmitems = new byte[currentMarks.size()][];
	for (int i = 0; i < deletebmitems.length; i++) {
		deletebmitems[i] = ((Mark) currentMarks.elementAt(i)).
			data;
	}

	selector = new Selector("ɾ����ǩ", deletebmitems, 0);
	currentWindow = selector;*/
}