#include "zyue.h"

#include "gal.h"
#include "bmp.h"
#include "i18n.h"
#include "string.h"

#include "smp.h"
#include "smp_label.h"
#include "smp_edit.h"
#include "smp_toolbar.h"

#define	JMP_HINT1	"\x8b\xf7\x8f\x93\x51\x65\x98\x75\x78\x1"
#define JMPBOX_W	170
#define	JMPBOX_H	70

enum
{
	JMP_EDIT=1,
	JMP_LABEL
};

static HWND hJmpBox;

HWND RichEdit_JumpPage(WID id, HWND hParent)
{
	DWORD style = WS_MODAL|WS_FOCUSCHILD|WS_TRANSPARENT; //WS_MODAL
	
	if(!hJmpBox)
	{
		int x = 0, y = 0;
		x = DIV((GAL_Width(PHYSICALGC) - JMPBOX_W), 2);
		y = GAL_Height(PHYSICALGC) - JMPBOX_H - SMP_TOOLBAR_HEIGHT - 40;
		hJmpBox = SGL_CreateWindow(RichEdit_JumpPageBox_WndProc, x, y, JMPBOX_W, JMPBOX_H, id, style, 0); //WS_TRANSPARENT
	}

	if(SGL_AddChildWindow(hParent, hJmpBox))
	{
		_SET_STYLE(hJmpBox, style);	
		_SET_STYLE(hParent, WS_INACTIVE); //����ֻΪ��ֹ�ı���ˢ��
		SGL_SetFocusWindow(hParent, hJmpBox);
	}
	
	return hJmpBox;
}

VOID ExitJmpBox(WORD code, DWORD data)
{
	HWND hParent = _PARENT(hJmpBox);

	if(!SGL_IsWindowVisible(hJmpBox))
		return;

	_CLR_STYLE(hJmpBox, WS_MODAL);//WS_INACTIVE|
	_CLR_STYLE(hParent, WS_INACTIVE);//|WS_MODAL
	SGL_SuspendDrawing();
	SGL_RemoveChildWindow(hJmpBox);
	SGL_SendNotifyMessage(hParent, _WID(hJmpBox), code, data);
	SGL_UnsuspendDrawing();
	SGL_UpdateWindow(hParent);
}

static uint8 FirstShow;
static UCHAR LabelBuf[50];
static UCHAR EditBuf[12];
LRESULT RichEdit_JumpPageBox_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	HWND hControl;

	switch(Msg)
	{
	case WM_CREATE:
	{
		int x, y, w, h;

		x = SMP_ITEM_MARGIN, y = SMP_ITEM_SPACE;
		h = _HEIGHT(hWnd), w = _WIDTH(hWnd) - 2*SMP_ITEM_MARGIN;
		_BGCOLOR(hWnd) = COLOR_lightwhite;
		_FGCOLOR(hWnd) = 0x00201c3a;

		hControl = SGL_CreateWindow(SMP_Label_WndProc,
			x, y, w, SMP_ITEM_HEIGHT,
			0, WS_TRANSPARENT|SMP_LABELS_HCENTER|SMP_LABELS_STATIC|SMP_LABELS_LINK, 0);
		_FGCOLOR(hControl) = _FGCOLOR(hWnd);
		SMP_Label_SetContent(hControl, RESID_INVALID, (PCWSTR)JMP_HINT1, 0);
		SGL_AddChildWindow(hWnd, hControl);

		y += SMP_ITEM_SPACE + SMP_ITEM_HEIGHT;

		hControl = SGL_CreateWindow(SMP_Edit_WndProc,
			x, y, w/2, SMP_ITEM_HEIGHT,
			JMP_EDIT, WS_TABSTOP|ES_NUM, 0);
		mrc_memset(EditBuf, 0, 12);
		SMP_Edit_SetInfo(hControl, (PCWSTR)JMP_HINT1, EditBuf, 12); //(ֻ����5����)��������:(��ʾ����(����Ӣ������)+1) * 2
		_FGCOLOR(hControl) = _FGCOLOR(hWnd);
		_BGCOLOR(hControl) = _BGCOLOR(hWnd);
		SGL_AddChildWindow(hWnd, hControl);

		x += w/2;

		hControl = SGL_CreateWindow(SMP_Label_WndProc,
			x, y, w/2, SMP_ITEM_HEIGHT,
			JMP_LABEL, WS_TRANSPARENT|SMP_LABELS_STATIC, 0);
		SMP_Label_SetContent(hControl, RESID_INVALID, (PCWSTR)"\x0\x5c\x0\x78\x0\x78\x0\x78", 0);
		_FGCOLOR(hControl) = _FGCOLOR(hWnd);
		SGL_AddChildWindow(hWnd, hControl);

		FirstShow = TRUE;

		break;
	}

	case WM_SHOW:
	{
		//int x = 0, y = 0;

		//SGL_WindowToScreen(hWnd, &x, &y);
		//mrc_EffSetCon(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, 128, 128, 128);
		hControl = SGL_FindChildWindow(hWnd, JMP_EDIT); 
		SGL_SetFocusWindow(hWnd, hControl);
		FirstShow = TRUE;
		break;
	}

	case WM_HIDE:
		FirstShow = TRUE;
		break;

	case WM_PAINT:
	{
		int x=0, y=0;
		PWSTR uni;
		char buf[20] = {0};

		SGL_WindowToScreen(hWnd, &x, &y);
		GAL_FillRoundRrct(x, y, _WIDTH(hWnd), _HEIGHT(hWnd), COLOR_lightwhite);
		//mrc_EffSetCon(x, y, _WIDTH(hWnd), _HEIGHT(hWnd), 128, 224, 255);

		if(!FirstShow)	//���Ȿ������򷵻غ��ˢ��
			break;

		mrc_memset(EditBuf, 0, 12);
		hControl = SGL_FindChildWindow(hWnd, JMP_LABEL); 
		mrc_sprintf(buf, "/%d", CurBook.pagecount);
		uni = asc2uni(buf);
		mrc_memset(LabelBuf, 0, 50);
		wstrcpy(LabelBuf, uni);
		mrc_free(uni);
		SMP_Label_SetContent(hControl, RESID_INVALID, (PCWSTR)LabelBuf, 0);

		FirstShow = FALSE;
		break;
	}

	case WM_KEYDOWN:
	case WM_KEYDOWNREPEAT:
	{
		hControl = SGL_FindChildWindow(hWnd, JMP_EDIT); 
		if((wParam != MR_KEY_SOFTRIGHT) && (wParam != MR_KEY_SOFTLEFT))
			SGL_SendMessage(hControl, Msg, wParam, lParam);

		break;
	}

	case WM_KEYUP:
	{
		//�ҵ��༭�򴰿�
		hControl = SGL_FindChildWindow(hWnd, JMP_EDIT); 

		if(wParam == MR_KEY_SOFTRIGHT)
		{
			ExitJmpBox((WORD)JUMPBOX_CAMCEL, 0);
			return 1;
		}else if(wParam == MR_KEY_SOFTLEFT)
		{
			int i;
			PSTR buf;
			PWSTR input;

			input = SMP_Edit_GetText(hControl);
			buf = uni2asc(input);
			i = mrc_atoi(buf);
			mrc_free(buf);
			ExitJmpBox((WORD)JUMPBOX_JUMPPAGE, (DWORD)i);			
			return 1;
		}else
			SGL_SendMessage(hControl, Msg, wParam, lParam);

		break;
	}

	//other messages...
	}

	return 0;
}
