#include "SetCenter.h"

#include "zyue.h"
#include "topwnd.h"
#include "window.h"


#include "bmp.h"
#include "string.h"
#include "i18n.h"

#include "smp.h"
#include "smp_menu.h"
#include "smp_toolbar.h"
#include "smp_menuwnd.h"
#include "smp_edit.h"
#include "smp_button.h"
#include "smp_msgbox.h"
#include "smp_flashbox.h"
#include "smp_label.h"
#include "smp_progbar.h"
#include "smp_combobox.h"
#include "smp_list.h"
#include "smp_scrollview.h"
#include "smp_colorlabel.h"
#include "smp_titlebar.h"

#include "mrc_base_i.h"

#define  ITEM_LEN  (SCREEN_WIDTH-SMP_SCRBAR_WIDTH-2*SMP_ITEM_SPACE)
enum
{
	SETCLR_IDSTART=0,
	SETCLR_SCRVIEW,
	SETCLR_TITLEBAR,
	SETCLR_TOOLBAR,
	SETCLR_LABELFT,
	SETCLR_CLRLABELFG, SETCLR_CLRLABELBG, SETCLR_CLRLABELCAP, SETCLR_CLRLABELLI, SETCLR_CLRLABELBORDER,
	CHKBTN_FONTB, CHKBTN_FONTM, CHKBTN_FONTS,
	COMBOX_ANGEL,
	SETCLR_IDEND
};

//��Ļ�Ӳ˵�
static const DWORD miScnAng[] =
{
	STR_ANG0, 
	STR_ANG90, 
	STR_ANG180, 
	STR_ANG270, 
};

static HWND hContent;
static HWND hSelectBtn;

static VOID SaveSettings(HWND hWnd)
{
	HWND hColorLabel, hTopWnd, hCombox;
	Sint32 select;

	hColorLabel = SGL_FindChildWindow(hContent, SETCLR_CLRLABELFG);
	Skin.skins[Skin.select].c_Ft1 = SMP_Colorlabel_GetColor(hColorLabel);

	hColorLabel = SGL_FindChildWindow(hContent, SETCLR_CLRLABELBG);
	Skin.skins[Skin.select].c_Bg = SMP_Colorlabel_GetColor(hColorLabel);

	hColorLabel = SGL_FindChildWindow(hContent, SETCLR_CLRLABELCAP);
	Skin.skins[Skin.select].c_Ft2 = SMP_Colorlabel_GetColor(hColorLabel);

	hColorLabel = SGL_FindChildWindow(hContent, SETCLR_CLRLABELLI);
	Skin.skins[Skin.select].c_Line = SMP_Colorlabel_GetColor(hColorLabel);

	hColorLabel = SGL_FindChildWindow(hContent, SETCLR_CLRLABELBORDER);
	Skin.skins[Skin.select].c_Border = SMP_Colorlabel_GetColor(hColorLabel);

	hCombox = SGL_FindChildWindow(hContent, COMBOX_ANGEL);
	select = SMP_ComboBox_GetSelectedItem(hCombox);

	HideTopWindow(_WID(hWnd), 1, 1);
	hTopWnd = SGL_GetNextChild(HWND_DESKTOP, NULL);
	Richedit_RefreshSkin(hTopWnd, 0);
	SGL_UpdateWindow(hTopWnd);

	//ת��
	mrc_plat(101, select);
}

LRESULT SetAll_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	HWND hControl, hScrview;

	switch(Msg)
	{
	case WM_CREATE:
	{
		int i, x, y;
		WID		id[5];
		DWORD	str[5];
		uint32	clr[5];
		int32	fw, fh;
		PWSTR	pText;

		_BGCOLOR(hWnd) = COLOR_MAIN_BG;
		_FGCOLOR(hWnd) = COLOR_MAIN_FG;

		x = 0; 

//-------�����Ӵ���-------------------------------------------------------------------------------------------
		//����������
		hControl = SGL_CreateWindow(SMP_Titlebar_WndProc, 0, 0, SCREEN_WIDTH, SMP_HEADER_HEIGHT, SETCLR_TITLEBAR, SMP_TITLEBAR_STATIC, 0);
		SMP_Titlebar_SetContent(hControl, BMP_ICO3, SGL_LoadString(STR_SETALL));
		_FGCOLOR(hControl) = COLOR_MAIN_FG;
		SGL_AddChildWindow(hWnd, hControl);

		//����������ͼ��������
		hScrview = SGL_CreateWindow(SMP_ScrollView_WndProc,
			0, SMP_HEADER_HEIGHT, SMP_CONTENT_VIEW_WIDTH, SMP_CONTENT_VIEW_HEIGHT,
			SETCLR_SCRVIEW, WS_TABSTOP, 0);
		hContent =  SMP_ScrollView_GetContentView(hScrview);  //��ȡ������ͼ����
		_BGCOLOR(hContent) = _BGCOLOR(hWnd);
		_FGCOLOR(hContent) = _FGCOLOR(hWnd);

		y = 0;
		x = SMP_ITEM_SPACE;

		//����һ�鵥ѡ��ť(����)
		//label ���壺
		hControl = SGL_CreateWindow(SMP_Label_WndProc,
			x, y, ITEM_LEN, SMP_ITEM_HEIGHT,
			SETCLR_LABELFT, SMP_LABELS_LINK, 0);
		SMP_Label_SetContent(hControl, RESID_INVALID, SGL_LoadString(STR_FONT), 500);
		_BGCOLOR(hControl) = _BGCOLOR(hWnd);
		_FGCOLOR(hControl) = _FGCOLOR(hWnd);
		SGL_AddChildWindow(hContent, hControl);

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		//��������(��ѡ��ť)
		str[0] = STR_FONTBIG, str[1] = STR_FONTSML;
		id[0] = CHKBTN_FONTB, id[1] = CHKBTN_FONTS;
		for(i=0; i<2; i++)
		{
			hControl = SGL_CreateWindow(SMP_Button_WndProc,
				x+i*ITEM_LEN/2, y, ITEM_LEN/2, SMP_ITEM_HEIGHT,
				id[i], WS_TABSTOP|SMP_BUTTONS_VCENTER|SMP_BUTTONS_HCENTER|SMP_BUTTONS_RADIOBOX, 0);
			SMP_Button_SetTitle(hControl, (PCWSTR)SGL_LoadString(str[i]));
			_BGCOLOR(hControl) = _BGCOLOR(hWnd);
			_FGCOLOR(hControl) = _FGCOLOR(hWnd);
			_LISTENER(hControl) = hWnd; 
			SGL_AddChildWindow(hContent, hControl);
		}
		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		//�������� label ��ɫ
		hControl = SGL_CreateWindow(SMP_Label_WndProc,
			x, y, ITEM_LEN, SMP_ITEM_HEIGHT,
			SETCLR_LABELFT, SMP_LABELS_LINK, 0);
		SMP_Label_SetContent(hControl, RESID_INVALID, SGL_LoadString(STR_COLOR), 500);
		_BGCOLOR(hControl) = _BGCOLOR(hWnd);
		_FGCOLOR(hControl) = _FGCOLOR(hWnd);
		SGL_AddChildWindow(hContent, hControl);

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		//����һ�� color label 
		str[0] = STR_CLR_FG, str[1] = STR_CLR_BG, str[2] = STR_CLR_CAP, str[3] = STR_CLR_LINE, str[4] = STR_CLR_BORDER;
		id[0] = SETCLR_CLRLABELFG, id[1] = SETCLR_CLRLABELBG, id[2] = SETCLR_CLRLABELCAP, id[3] = SETCLR_CLRLABELLI, id[4] = SETCLR_CLRLABELBORDER;
		clr[0] = Draw.c_Ft1, clr[1] = Draw.c_Bg, clr[2] = Draw.c_Ft2, clr[3] = Draw.c_Line, clr[4] = Draw.c_Border;
		for(i=0; i<5; i++)
		{
			hControl = SGL_CreateWindow(SMP_Colorlabel_WndProc,
				x, y, ITEM_LEN, COLORLABEL_HEIGHT,
				id[i], WS_TABSTOP, 0);
			SMP_Colorlabel_SetContent(hControl, SGL_LoadString(str[i]), clr[i]);
			_BGCOLOR(hControl) = _BGCOLOR(hWnd);
			SGL_AddChildWindow(hContent, hControl);

			y += COLORLABEL_HEIGHT + SMP_ITEM_SPACE;
		}

		//�������� label ��ת��Ļ
		hControl = SGL_CreateWindow(SMP_Label_WndProc,
			x, y, ITEM_LEN, SMP_ITEM_HEIGHT,
			0, SMP_LABELS_LINK, 0);
		SMP_Label_SetContent(hControl, RESID_INVALID, SGL_LoadString(STR_SCREEN), 500);
		_BGCOLOR(hControl) = _BGCOLOR(hWnd);
		_FGCOLOR(hControl) = _FGCOLOR(hWnd);
		SGL_AddChildWindow(hContent, hControl);

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		//���� combox ��Ļ�Ƕ�
		pText = (PWSTR)SGL_LoadString(STR_TUNSCN);
		mrc_unicodeTextWidthHeight((uint16*)pText, 1, &fw, &fh);
		hControl = SGL_CreateWindow(SMP_Label_WndProc,
			x, y, fw+20, SMP_ITEM_HEIGHT,
			0, 0, 0);
		SMP_Label_SetContent(hControl, RESID_INVALID, (PCWSTR)pText, 500);
		_BGCOLOR(hControl) = _BGCOLOR(hWnd);
		_FGCOLOR(hControl) = _FGCOLOR(hWnd);
		SGL_AddChildWindow(hContent, hControl);

		hControl = SGL_CreateWindow(SMP_ComboBox_WndProc,
			x+fw+20, y, ITEM_LEN-fw-20, SMP_ITEM_HEIGHT,
			COMBOX_ANGEL, WS_TABSTOP, 0);
		SMP_ComboBox_SetItems(hControl, miScnAng, 4);
		_BGCOLOR(hControl) = _BGCOLOR(hWnd);
		_FGCOLOR(hControl) = _FGCOLOR(hWnd);
		_LISTENER(hControl) = hWnd; 
		SGL_AddChildWindow(hContent, hControl);

		y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

		SGL_AddChildWindow(hWnd, hScrview);   //���ӹ����Ӵ���������

		//����������
		hControl = SGL_CreateWindow(SMP_Toolbar_WndProc, 
			0, SCREEN_HEIGHT - SMP_TOOLBAR_HEIGHT, SCREEN_WIDTH, SMP_TOOLBAR_HEIGHT,
			SETCLR_TOOLBAR, 0, 0);
		_FGCOLOR(hControl) = COLOR_MAIN_FG;
		SMP_Toolbar_SetStrings(hControl, STR_APPLY, RESID_INVALID, STR_BACK, FALSE);
		SGL_AddChildWindow(hWnd, hControl);

		break;
	}

	case WM_SHOW:
	{
		HFONT font = SGL_GetSystemFont();
		HWND hBtn2;

		//��������ѡ�а�ť
		switch(font)
		{
		case MR_FONT_BIG:
			hBtn2 = SGL_FindChildWindow(hContent, CHKBTN_FONTB);
			SMP_Button_SetChecked(hBtn2, 1);
			hSelectBtn = hBtn2;
			break;

		case MR_FONT_SMALL:
			hBtn2 = SGL_FindChildWindow(hContent, CHKBTN_FONTS);
			SMP_Button_SetChecked(hBtn2, 1);
			hSelectBtn = hBtn2;
			break;
		}
		break;
	}

	case WM_PAINT:
		break;

	case WM_INITFOCUS: 
		SGL_FocusNext(hWnd, TRUE);
		break;

	case WM_HIDE:
		break;

	case WM_MOUSEDOWN:
		break;

	case WM_MOUSEUP:
		break;

	case WM_KEYDOWN:
	case WM_KEYDOWNREPEAT:
	{
		switch(wParam)
		{
		case MR_KEY_UP:
			SGL_FocusNext(hWnd, FALSE);
			return 1;
		case MR_KEY_DOWN:
			SGL_FocusNext(hWnd, TRUE);
			return 1;
		}
		break;
	}	

	case WM_KEYUP:
	{
		switch(wParam)
		{
			case MR_KEY_SOFTLEFT: 
				SaveSettings(hWnd);
				return 1;

			case MR_KEY_SOFTRIGHT: 
				HideTopWindow(TOPWND_SETALL, 1, 1);
				return 1;
		}
		break;
	}

	case WM_COMMAND:
	{
		WID id = LOWORD(wParam);     //�ӿؼ�ID������WPARAM��λ������
		WORD code = HIWORD(wParam);  //wparam�����ĸ�λ�ֽڷ��õ����Ӵ���������Ӵ���ID

		switch(id)
		{
		case CHKBTN_FONTB: //��ѡ��ť ��
		case CHKBTN_FONTM: //��ѡ��ť ��
		case CHKBTN_FONTS: //��ѡ��ť С
		{
			HWND hBtn = (HWND)lParam;
			HFONT font;

			SGL_SetFocusWindow(hWnd, hBtn);
			if(code == SMP_BUTTONN_CLICKED)
			{
				if(_WID(hSelectBtn) == _WID(hBtn))
					break;

				SMP_Button_SetChecked(hSelectBtn, 0);
				SMP_Button_SetChecked(hBtn, 1);
				hSelectBtn = hBtn;
				if(_WID(hBtn) == CHKBTN_FONTB) 
					font = MR_FONT_BIG;
				else if(_WID(hBtn) == CHKBTN_FONTS) 
					font = MR_FONT_SMALL;
				else 
					font = MR_FONT_MEDIUM;
				SGL_SetSystemFont(font);
			}
			break;
		}

		case COMBOX_ANGEL:
		{
			break;
		}
		
		}

		break;
	}

		//other window messages
	}
	return 0;
}
