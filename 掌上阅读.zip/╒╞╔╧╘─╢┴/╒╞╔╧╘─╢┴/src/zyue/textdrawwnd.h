#ifndef _SMP_TEXTWND_H_
#define _SMP_TEXTWND_H_

#include "window.h"


//----------------------------------------------------------
//Enum value type
typedef enum DirectionValue
{
	DRT_NULL=0,
	DRT_LEFT,
	DRT_RIGHT,
	DRT_UP,
	DRT_DOWN
}DIRECTION;

typedef enum FlipType
{
	FLIP_PIX, FLIP_LINE, FLIP_PAGE
}FLIPTYPE;

typedef enum SrcType
{
	SRC_NULL=0,
	SRC_FILE,
	SRC_STREAM
}SRCTYPE;

typedef enum 
{
	GB2312 = 0, UTF8, UNICODE
}TEXTTYPE;

typedef enum 
{
	LINE_DOTTED = 0, LINE_SOLID
}LINETYPE;
//----------------------------------------------------------


/**
 * \Move the window
 * \param pSource the memory of pSource
 * \param hWnd the win handel
 * \param type the type of pSource
 */
BOOL SMP_TextWnd_SetText(HWND hWnd, PSTR pSource, SRCTYPE type);

/**
 * \�����Զ�������ʽ
 */
VOID SMP_TextWnd_SetMoveType(HWND hWnd, FLIPTYPE type);
/**
 * \Description:
 * \Play the text. If first using, it would be very slow bacause must initialize the memory DC.
 * \It would be quickly next time when the setting has not changed since first using
 * \param hWnd the win handel
 */
BOOL SMP_TextWnd_Play(HWND hWnd, DIRECTION direction);

/**
 * \Stop the text MOVE
 * \param hWnd the win handel
 */
BOOL SMP_TextWnd_Stop(HWND hWnd);

/**
 * \Set the direction for the text information displayed
 * \param hWnd the win handel
 * \param dtValue the DirectionValue
 */
VOID SMP_TextWnd_SetDirection(HWND hWnd, DIRECTION dtValue);

/**
 * \Set the move distance once, base on pixel.
 * \param hWnd the win handel
 * \param iPixel the pixel value
 */
VOID SMP_TextWnd_SetMovePixel(HWND hWnd, int iPixel);

/**
 * \Set the color for the background of window 
 * \param hWnd the win handel
 * \param fgColor the background color
 * \param bgColor the foreground color
 * \param lineColor the color of underline
 * \color == COLOR_INVALID when don't change it
 */
VOID SMP_TextWnd_SetColor(HWND hWnd, Uint32 fgColor, Uint32 bgColor, Uint32 lineColor);

/**
 * \Text Page Up
 * \param hWnd the win handel
 */
VOID SMP_TextWnd_PageUP(HWND hWnd);

/**
 * \Text Page Down
 * \param hWnd the win handel
 */
VOID SMP_TextWnd_PageDown(HWND hWnd);

/**
 * \Text Line Up
 * \param hWnd the win handel
 */
VOID SMP_TextWnd_LineUp(HWND hWnd);

/**
 * \Text Line Down
 * \param hWnd the win handel
 */
VOID SMP_TextWnd_LineDown(HWND hWnd);

/**
 * \�����ļ��Ժ����³�ʼ����ȡ��Ϣ
 */
VOID TextReadRefresh(HWND hWnd);

/**
 * \����ȫ��/��ȫ����ʾ
 */
VOID SMP_TextWnd_SetFullScn(HWND hWnd, BOOL fullshow);

/**
 * \������ת
 */
VOID SMP_TextWnd_FreeJump(HWND hWnd, int32 off);

/**
 * \����/��ʾ�»���
 */
VOID SMP_TextWnd_UnderLine(HWND hWnd, BOOL show);

/**
 * \��������
 */
VOID SMP_TextWnd_SetFont(HWND hWnd, GAL_FONT_TYPE font);

/**
 * \Set the direction for the text information displayed
 * \param hWnd the win handel
 * \param dtValue the DirectionValue
 */
//void SMP_TextWnd_SetTxtPointSize(int iPointSize);

/**
 * \Set the direction for the text information displayed
 * \param hWnd the win handel
 * \param dtValue the DirectionValue
 */
//void SMP_TextWnd_SetTxtWeight(int iWeight);

/**
 * \Set the direction for the text information displayed
 * \param hWnd the win handel
 * \param dtValue the DirectionValue
 */
//BOOL SMP_TextWnd_SwitchNext(void);

/**
 * \Set the direction for the text information displayed
 * \param hWnd the win handel
 * \param dtValue the DirectionValue
 */
//BOOL SMP_TextWnd_SwitchPrevious(void);


/**
 * \brief The textwnd window procedure.
 *
 * \param hWnd the window handle
 * \param Msg the window message
 * \param wParam the first parameter
 * \param lParam the second parameter
 * \return the result of message process 
 */
LRESULT SMP_TextWnd_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);


#endif