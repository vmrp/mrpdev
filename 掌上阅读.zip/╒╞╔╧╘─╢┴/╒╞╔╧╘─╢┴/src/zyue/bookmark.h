#ifndef _BOOKMARK_H_
#define _BOOKMARK_H_

#include "window.h"

#endif