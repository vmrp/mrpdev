
#include "topwnd.h"

#include "i18n.h"
#include "bmp.h"
#include "smp.h"
#include "smp_toolbar.h"
#include "smp_textinfo.h"
#include "smp_titlebar.h"

typedef struct
{
	PCWSTR title;
	PCWSTR text;
	WID EntryWndId;
}TEXTWNDDATA;

enum
{
	TEXTWND_TITLEBAR=1,
	TEXTWND_TEXT,
	TEXTWND_TOOLBAR
};

static TEXTWNDDATA pData; 

VOID ShowTextInfo(WID id, PWSTR text, PWSTR title)
{
	pData.EntryWndId = id;
	pData.text = text;
	pData.title = title;
	HideTopWindow(pData.EntryWndId, 0, 0);
	ShowTopWindow(TOPWND_TEXTINFO, 0, 0);
}
VOID HidTextInfo(VOID)
{
	HideTopWindow(TOPWND_TEXTINFO, 0, 0);
	ShowTopWindow(pData.EntryWndId, 0, 1001);
}

//������Ϣ����
LRESULT TextInfo_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	HWND hControl;
	switch(Msg)
	{
	case WM_CREATE:
		//����������
		hControl = SGL_CreateWindow(SMP_Titlebar_WndProc,
			0, 0, SCREEN_WIDTH, SMP_HEADER_HEIGHT,
			TEXTWND_TITLEBAR, SMP_TITLEBAR_STATIC, 0);
		SMP_Titlebar_SetContent(hControl, BMP_ICO4, SGL_LoadString(STR_HELP));
		_FGCOLOR(hControl) = COLOR_MAIN_FG;
		SGL_AddChildWindow(hWnd, hControl);

		//�����ı���Ϣ����
		hControl = SGL_CreateWindow(SMP_TextInfo_WndProc,
			0, SMP_HEADER_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT - SMP_HEADER_HEIGHT - SMP_TOOLBAR_HEIGHT,
			TEXTWND_TEXT, WS_TABSTOP, 0);
		SMP_TextInfo_SetContent(hControl, SGL_LoadString(STR_HINT));
		_BGCOLOR(hControl) = COLOR_MAIN_BG;
		_FGCOLOR(hControl) = COLOR_MAIN_FG;
		SGL_AddChildWindow(hWnd, hControl);

		//����������
		hControl = SGL_CreateWindow(SMP_Toolbar_WndProc, 
			0, SCREEN_HEIGHT - SMP_TOOLBAR_HEIGHT, SCREEN_WIDTH,SMP_TOOLBAR_HEIGHT,
			TEXTWND_TOOLBAR, 0, 0);
		_FGCOLOR(hControl) = COLOR_MAIN_FG;
		SMP_Toolbar_SetStrings(hControl, RESID_INVALID, RESID_INVALID, STR_BACK, FALSE);
		SGL_AddChildWindow(hWnd, hControl);

		break;

	case WM_INITFOCUS:
		hControl = SGL_FindChildWindow(hWnd, TEXTWND_TEXT);
		SGL_SetFocusWindow(hWnd, hControl);
		break;

	case WM_SHOW:
		hControl = SGL_FindChildWindow(hWnd, TEXTWND_TEXT);
		SMP_TextInfo_SetContent(hControl, (PCWSTR)pData.text);
		//������show�������ˢ�´���
		//SGL_UpdateWindow(hWnd);
		break;

	case WM_PAINT:
		//SMP_DrawWndHeader(0, 0, SCREEN_WIDTH, SMP_HEADER_HEIGHT, COLOR_black, COLOR_MAIN_FG, BMP_ICO4, (PCWSTR)pData.title);
		break;

	case WM_HIDE:
		break;

	case WM_KEYUP:
		switch(wParam)
		{
		case MR_KEY_SOFTRIGHT:
			HidTextInfo();
			return 1;
		}
		break;	

	}

	return 0;
}