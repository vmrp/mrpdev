#ifndef _MRPINFOEDIT_H
#define _MRPINFOEDIT_H

#include "window.h"

//the entery of the mrpedit
VOID ShowMrpEdit(PSTR filepn);

LRESULT MrpEdit_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);

#endif