#include "mrpinfoedit.h"
#include "topwnd.h"

#include "string.h"
#include "i18n.h"
#include "smp.h"
#include "bmp.h"
#include "fun.h"
#include "mrc_exb.h"
#include "mrppack.h"
#include "textwnd.h"
#include "appdef.h"
#include "opendlg.h"

#include "smp_label.h"
#include "smp_titlebar.h"
#include "smp_toolbar.h"
#include "smp_button.h"
#include "smp_scrollview.h"
#include "smp_edit.h"
#include "smp_menuwnd.h"
#include "smp_menu.h"
#include "smp_msgbox.h"
#include "smp_textinfo.h"


#define COLOR_Combox_bg     0x00202020  //combox����
#define COLOR_Listface	    0x00171a1d   //�б�Ƥ��
#define COLOR_FONT_night    0x004A6D8C  //QQ�����ҹ������ɫ
#define MAX_FULLNAME_LEN	512

enum WinIds
{
	MRP_EDIT1 = 1,  //�����༭��ID
	MRP_EDIT2,
	MRP_EDIT3,
	MRP_EDIT4,
	MRP_EDIT5,
	MRP_EDIT6,
	MRP_EDIT7,
	MRP_TITLEBAR,
	MRP_TOOLBAR,
	MRP_BTN_SAVE,   //�����޸İ�ťID
	MRP_SCRVIEW,    //������ͼ����ID
	MRP_OPTMENU     //���˵�ID
};

//ֻ�����༭��Ļ���
typedef struct MrpInfo
{
	UCHAR filename[24];  //�ļ���
	UCHAR appname[48];   //Ӧ����
	UCHAR code[34];      //���к�
	UCHAR appidstr[22];  //APPID�ִ���ʽ
	UCHAR appverstr[22]; //Ӧ�ð汾�ִ�
	UCHAR vender[80];    //����
	UCHAR descrip[128];  //Ӧ������
}MRPHEADERINFO;

//���ݽṹ
typedef struct SMP_MrpEdit_Data
{
	char mrpName[512];     //������mrp�ļ���
	HWND hContent;
	BOOL isOpen;
}MRPEDITWINDATA, *PMRPEDITWINDATA;


//mrpͷ��Ϣ�ṹ��
static MRPHEADERINFO		MrpInfo;
static BOOL					FistShow;
static MRPEDITWINDATA		pData;		


//��Ϣд��MRP
int32 WriteToMrp(HWND hWnd);
//��ȡmrp��Ϣ
VOID ReadMrpInfo(HWND hWnd);

int32 RenameMrp(WID editid)
{
	PWSTR text;
	PSTR ext;
	int32 ret, len;
	HWND hControl;
	char newname[512] = {0};
	PSTR buffer, path;

	hControl = SGL_FindChildWindow(pData.hContent, editid);
	text = SMP_Edit_GetText(hControl);

	buffer = uni2asc(text);
	path = ExtractFileDir(pData.mrpName);
	//��ȡ����·��
	if(NULL != path)
		mrc_strcpy(newname, path);
	mrc_strcat(newname, buffer);
	FREE_SET_NULL(buffer);
	FREE_SET_NULL(path);

	ext = ExtractFileExt(newname);
	if(mrc_strcmp(ext, "mrp") != 0)
		mrc_strcat(newname, ".mrp");
	FREE_SET_NULL(ext);

	ret = mrc_rename(pData.mrpName, newname);
	if(MR_FAILED == ret) return MR_FAILED;

	len = mrc_strlen(newname);
	if(len > MAX_FULLNAME_LEN) return MR_FAILED;
	mrc_strcpy(pData.mrpName, newname);
	
	return MR_SUCCESS;
}


VOID ShowMrpEdit(PSTR filepn)
{
	

	//ShowTopWindow(TOPWND_MRPEDIT, 0, 0);
}

VOID HideMrpEdit(VOID)
{
	HideTopWindow(TOPWND_MRPEDIT, 0, 1);
	mrc_exit();
}

//�˵���
static const DWORD miOptions[] = 
{
	STR_OPEN,	 //0.��
	STR_OPTION,	 //1.����
	STR_RENAME,  //2.������
	STR_HELP,    //3.����
	STR_EXIT     //4.����
};
//�˵��������
static const DWORD miRename[] = 
{
	STR_MRP_FNAME,  //6.��ʾ��
	STR_MRP_APPNAME //7.�ڲ���
};
static const DWORD miFile[] = 
{
	STR_PACK,    //7.���
	STR_EXTRACT, //8.��ѹ
	STR_SAVE,    //9.����
	STR_QQINFO,  //10.�Դ�QQ
};

//��ʾ�˵�
static VOID MRP_Opt_Menu(HWND hWnd)
{
	int start = 0;

	SMP_Menu_ClearMenuItems();
	SMP_Menu_SetMenuItem2(start, miOptions, TABLESIZE(miOptions));
	start += TABLESIZE(miOptions);

	SMP_Menu_SetMenuItem2(start, miFile, TABLESIZE(miFile));
	SMP_Menu_SetSubMenu(1, start);
	start += TABLESIZE(miFile);

	SMP_Menu_SetMenuItem2(start, miRename, TABLESIZE(miRename)); 
	SMP_Menu_SetSubMenu(2, start);
	start += TABLESIZE(miRename);

	if(!pData.isOpen)
	{
		SMP_Menu_DisableMenuItem(1, 1);
		SMP_Menu_DisableMenuItem(2, 1);
	}
	
	SMP_Menu_Popup(MRP_OPTMENU, SMP_MENUS_BOTTOMLEFT, hWnd, 0, _HEIGHT(hWnd) - SMP_TOOLBAR_HEIGHT, NULL);
}

//�����ں���
LRESULT MrpEdit_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	HWND hControl, hScrview;

	switch(Msg)
	{
	case WM_CREATE:
	{
		int i, x, y, w;
		uint32	bgclr, fgclr;
		DWORD	str_id[7] = {STR_MRP_FNAME, STR_MRP_APPNAME, STR_MRP_SID, STR_MRP_APPID, STR_MRP_APPVER, STR_MRP_AUTHOR,STR_MRP_ABOUT};
		WID		edit_id[7] = {MRP_EDIT1, MRP_EDIT2, MRP_EDIT3, MRP_EDIT4, MRP_EDIT5, MRP_EDIT6, MRP_EDIT7};
		PWSTR	edit_buf[7];
		int		edit_buflen[7] = {48, 24, 34, 22, 22, 80, 128};			

		//1.���ݳ�ʼ��
		mrc_memset(&pData, 0, sizeof(MRPEDITWINDATA));
		_SET_WINDATA(hWnd, &pData);
		//��ʼ��mrp��Ϣ�ṹ
		SGL_MEMSET(&MrpInfo, 0, sizeof(MRPHEADERINFO));
		//��һ�ν��뱾����
		FistShow = TRUE;

		_BGCOLOR(hWnd) = (System_Theme == THEME_CLASSIC) ? COLOR_controlbg : 0x0B2337;
		fgclr = _FGCOLOR(hWnd) = (System_Theme == THEME_CLASSIC) ? COLOR_black : COLOR_lightwhite;
		bgclr = (System_Theme == THEME_CLASSIC) ? COLOR_controlbg : COLOR_Combox_bg;

		//����������
		hControl = SGL_CreateWindow(SMP_Titlebar_WndProc,
			0, 0, SCREEN_WIDTH, SMP_HEADER_HEIGHT,
			MRP_TITLEBAR, SMP_TITLEBAR_STATIC, 0);
		SMP_Titlebar_SetContent(hControl, BMP_ICO1, SGL_LoadString(STR_TITLE_INFO));
		_FGCOLOR(hControl) = COLOR_MAIN_FG;
		SGL_AddChildWindow(hWnd, hControl);

		//����������ͼ��������
		hScrview = SGL_CreateWindow(SMP_ScrollView_WndProc,
			0 , SMP_HEADER_HEIGHT, SMP_CONTENT_VIEW_WIDTH, SMP_CONTENT_VIEW_HEIGHT,
			MRP_SCRVIEW, WS_TRANSPARENT|WS_TABSTOP, 0);
		pData.hContent =  SMP_ScrollView_GetContentView(hScrview);
		
		//�����༭�����
		edit_buf[0] = MrpInfo.appname, edit_buf[1] = MrpInfo.filename, edit_buf[2] = MrpInfo.code;
		edit_buf[3] = MrpInfo.appidstr, edit_buf[4] = MrpInfo.appverstr, edit_buf[5] = MrpInfo.vender;
		edit_buf[6] = MrpInfo.descrip;
		x = SMP_ITEM_MARGIN;
		y = 2;
		w = SMP_ITEM_LENGTH - SMP_SCRBAR_WIDTH;
		for(i=0; i<7; i++)
		{
			//����label
			hControl = SGL_CreateWindow(SMP_Label_WndProc,
				x, y, w, SMP_ITEM_HEIGHT,
				0, WS_TRANSPARENT|SMP_LABELS_STATIC, 0);	//WS_SYSTHEME|
			SMP_Label_SetContent(hControl, RESID_INVALID, SGL_LoadString(str_id[i]), 0);
			_FGCOLOR(hControl) = fgclr;
			SGL_AddChildWindow(pData.hContent , hControl);

			y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;

			//����edit
			hControl = SGL_CreateWindow(SMP_Edit_WndProc,
				x, y, w, SMP_ITEM_HEIGHT,
				edit_id[i], WS_TABSTOP, 0);	//WS_SYSTHEME|
			SMP_Edit_SetInfo(hControl, SGL_LoadString(str_id[i]), edit_buf[i], edit_buflen[i]);
			_LISTENER(hControl) = hWnd;   // ���ü������ڣ��Ƚ�����Ϣ�Ĵ���
			_BGCOLOR(hControl) = bgclr;
			_FGCOLOR(hControl) = fgclr;
			SGL_AddChildWindow(pData.hContent, hControl);

			y += SMP_ITEM_HEIGHT + SMP_ITEM_SPACE;
		}

		//6.�����޸İ�ť
 		/*hControl = SGL_CreateWindow(SMP_Button_WndProc,
			x, y, SMP_ITEM_LENGTH - SMP_SCRBAR_WIDTH, 30,
			MRP_BTN_SAVE,  WS_TABSTOP | SMP_BUTTONS_HCENTER | SMP_BUTTONS_VCENTER, 0);
		_FGCOLOR(hControl) = _FGCOLOR(hWnd);
		_BGCOLOR(hControl) = _BGCOLOR(hWnd);
		SMP_Button_SetTitle(hControl, SGL_LoadString(STR_MRP_SAVE));
		_LISTENER(hControl) = hWnd;
		SGL_AddChildWindow(pData.hContent, hControl);*/

		_BGCOLOR(pData.hContent) = _BGCOLOR(hWnd);
	    SGL_AddChildWindow(hWnd, hScrview); 

		//����������
		hControl = SGL_CreateWindow(SMP_Toolbar_WndProc, 
			0,  _HEIGHT(hWnd) - SMP_TOOLBAR_HEIGHT, _WIDTH(hWnd), SMP_TOOLBAR_HEIGHT,
			MRP_TOOLBAR, 0, 0);
		SMP_Toolbar_SetStrings(hControl,  STR_OPTIONS , RESID_INVALID, STR_EXIT, TRUE);
		_FGCOLOR(hControl) = _FGCOLOR(hWnd);
		SGL_AddChildWindow(hWnd, hControl);

		break;
	}

	case WM_DESTROY:
	{
		break;
	}

	case WM_SHOW:
	{
		if(FistShow)
			SMP_MsgBox(0, hWnd, NULL, SGL_LoadString(STR_HINT), SGL_LoadString(STR_HINT21), ID_OK, NULL);
		FistShow = FALSE;

		//_BGCOLOR(hWnd) = (System_Theme == THEME_CLASSIC) ? COLOR_controlbg : COLOR_Listface;
		//_FGCOLOR(hWnd) = (System_Theme == THEME_CLASSIC) ? COLOR_black : COLOR_FONT_night;
		//_BGCOLOR(pData.hContent) = _BGCOLOR(hWnd);
		//_FGCOLOR(pData.hContent) = _FGCOLOR(hWnd);

		if(1001 == _USERDATA(hWnd))
			break;

		//ShowMrpEdit("test.mrp");
		//ReadMrpInfo(hWnd);

		break;
	}

	case WM_GETFILE:
	{
		PSTR filepn = (PSTR)wParam;
		int32 len;

		if(!filepn)
		{
			SMP_MsgBox(0, hWnd, NULL, SGL_LoadString(STR_HINT), (PCWSTR)"\x62\x53\x5f\x0\x59\x31\x8d\x25\xff\x1", ID_OK | SMP_MSGBOXS_AUTOCLOSE, NULL);
			break;
		}

		len = mrc_strlen(filepn);
		if(len > MAX_FULLNAME_LEN)
		{
			SMP_MsgBox(0, hWnd, NULL, SGL_LoadString(STR_HINT), (PCWSTR)"\x62\x53\x5f\x0\x59\x31\x8d\x25\xff\x1", ID_OK | SMP_MSGBOXS_AUTOCLOSE, NULL);
			break;
		}
		mrc_strcpy(pData.mrpName, filepn);

		ReadMrpInfo(hWnd);
		pData.isOpen = TRUE;
		break;
	}
	
	case WM_PAINT:
	{
		break;
	}

	case WM_INITFOCUS:
	{
		SGL_SetFocusWindow(hWnd , _PARENT(pData.hContent));
		break;
	}
	
	case WM_KEYDOWN:
	case WM_KEYDOWNREPEAT:
	{
		switch(wParam)
		{
		case MR_KEY_UP:
			return 1;
		case MR_KEY_DOWN:
			return 1;
		}
		break;
	}
	
	case WM_KEYUP:
	{
		switch(wParam)
		{
		case MR_KEY_SOFTRIGHT: 
			SMP_ExitBox(hWnd);
			return 1 ;  //ע������� return 1 

		case MR_KEY_SOFTLEFT:
			MRP_Opt_Menu(hWnd);
			return 1 ;   //ע������� return 1 

		}
		break;
	}

	case WM_COMMAND:
		{
			WID id = LOWORD(wParam);
 			WORD code = HIWORD(wParam);

			switch(id)
			{
			case MRP_BTN_SAVE:
				WriteToMrp(hWnd);  //д��MRP
				break;

			case TOPWIN_MSGBOX_COMMON:
				SGL_UpdateWindow(hWnd);
				break;

			case TOPWIN_MSGBOX_EXIT:
				if(code == ID_OK) HideMrpEdit();
				break;

			case MRP_OPTMENU:
				{
					switch(code)
					{
					case STR_OPEN:
						ShowOpenDlg(_WID(hWnd), 0, FILE_MRP);
						break;

					case STR_SAVE:
						WriteToMrp(hWnd);  //д��MRP
						break;

					case STR_HELP:
						ShowTextInfo(TOPWND_MRPEDIT, SGL_LoadString(STR_HELP_MRPEDIT), SGL_LoadString(STR_HELP));
						break;

					case STR_BACK:     //����
						HideMrpEdit();
						break;

					case STR_EXIT:     //�˳�
						SMP_ExitBox(hWnd);
						break;

					case STR_EXTRACT:  //��ѹ
						ShowMrpExtractWnd(hWnd, pData.mrpName, 0);
						break;

					case STR_PACK:    //���
						ShowMrpExtractWnd(hWnd, pData.mrpName, 1);
						break;

					case STR_QQINFO:  //�Դ�QQ
						hControl = SGL_FindChildWindow(pData.hContent, MRP_EDIT2); //Ӧ���� qq2008.mrp
						SMP_Edit_SetText(hControl, (PCWSTR)"\x0\x71\x0\x71\x0\x32\x0\x30\x0\x30\x0\x38\x0\x2e\x0\x6d\x0\x72\x0\x70", TRUE, FALSE);
						hControl = SGL_FindChildWindow(pData.hContent, MRP_EDIT4); //APPID 230103
						SMP_Edit_SetText(hControl, (PCWSTR)"\x0\x32\x0\x30\x0\x33\x0\x31\x0\x30\x0\x33", TRUE, FALSE);
						break;

					case STR_MRP_FNAME:		//������Ϊ��ʾ��
					{
						if(MR_SUCCESS == RenameMrp(MRP_EDIT1))
							SMP_MsgBox(TOPWIN_MSGBOX_COMMON, hWnd, NULL, SGL_LoadString(STR_HINT), (PCWSTR)"\x4f\xee\x65\x39\x62\x10\x52\x9f\xff\x1", ID_OK | SMP_MSGBOXS_AUTOCLOSE, NULL);
						else
							SMP_MsgBox(TOPWIN_MSGBOX_COMMON, hWnd, NULL, SGL_LoadString(STR_HINT), (PCWSTR)"\x4f\xee\x65\x39\x59\x31\x8d\x25\xff\x1", ID_OK | SMP_MSGBOXS_AUTOCLOSE, NULL);

						break;
					}

					case STR_MRP_APPNAME:   //������Ϊ�ڲ���
					{
						if(MR_SUCCESS == RenameMrp(MRP_EDIT2))
							SMP_MsgBox(TOPWIN_MSGBOX_COMMON, hWnd, NULL, SGL_LoadString(STR_HINT), (PCWSTR)"\x4f\xee\x65\x39\x62\x10\x52\x9f\xff\x1", ID_OK | SMP_MSGBOXS_AUTOCLOSE, NULL);
						else
							SMP_MsgBox(TOPWIN_MSGBOX_COMMON, hWnd, NULL, SGL_LoadString(STR_HINT), (PCWSTR)"\x4f\xee\x65\x39\x59\x31\x8d\x25\xff\x1", ID_OK | SMP_MSGBOXS_AUTOCLOSE, NULL);

						break;
					}

					}

				break;
				}//OPTMENU
				
			}
		break;
		} //WM_COMMAND
	}
	//���ز˵��¼�
 	return SMP_MenuWnd_WndProc(hWnd, Msg, wParam, lParam);  
}

//��ȡmrp��Ϣ
VOID ReadMrpInfo(HWND hWnd)
{
	int32 mrpHandel;
	char buffer[128] = {0};
	HWND hControl;
	int32 appid, appver;
	PWSTR buf;

	mrpHandel = mrc_open((PCSTR)pData.mrpName, MR_FILE_RDONLY);
	if(!mrpHandel) return;

	//1.�ӿ�ʼλ�ð�ָ���Ƶ�ƫ��28����ȡmrp��ʾ����22�ֽ�(����ȫΪ����)
	mrc_seek(mrpHandel, 28, MR_SEEK_SET);
	mrc_memset(buffer, 0, sizeof(buffer));        //��ʼ��������
	mrc_read(mrpHandel, (char*)buffer, 22);
	hControl = SGL_FindChildWindow(pData.hContent, MRP_EDIT1);
	buf = asc2uni(buffer);
	SMP_Edit_SetText(hControl, (PWSTR)buf, TRUE, FALSE);
	FREE_SET_NULL(buf);

	//2.�ӿ�ʼλ�ð�ָ���Ƶ�ƫ��16����ȡmrp�ڲ�����12�ֽڣ�����ȫΪӢ�ģ�
	mrc_seek(mrpHandel, 16, MR_SEEK_SET);
	mrc_memset(buffer, 0, sizeof(buffer));
	mrc_read(mrpHandel, (char*)buffer, 12);
	hControl = SGL_FindChildWindow(pData.hContent, MRP_EDIT2);
	buf = asc2uni(buffer);
	SMP_Edit_SetText(hControl, (PWSTR)buf, TRUE, FALSE);
	FREE_SET_NULL(buf);

	//3.�ӿ�ʼλ�ð�ָ���Ƶ�ƫ��52����ȡmrp���кţ�16�ֽڣ�����ȫ��Ӣ�ģ�
	mrc_seek(mrpHandel, 52, MR_SEEK_SET);
	mrc_memset(buffer, 0, sizeof(buffer));
	mrc_read(mrpHandel, (char*)buffer, 16);
	hControl = SGL_FindChildWindow(pData.hContent, MRP_EDIT3);
	buf = asc2uni(buffer);
	SMP_Edit_SetText(hControl, (PWSTR)buf, TRUE, FALSE);
	FREE_SET_NULL(buf);

	//4.��ȡAPPID
	mrc_seek(mrpHandel, 68, MR_SEEK_SET);
	mrc_memset(buffer, 0, sizeof(buffer));
	mrc_read(mrpHandel, &appid, sizeof(int32));
	hControl = SGL_FindChildWindow(pData.hContent, MRP_EDIT4);
	mrc_sprintf(buffer, "%d", appid);
	buf = asc2uni(buffer);
	SMP_Edit_SetText(hControl, (PWSTR)buf, TRUE, FALSE);
	FREE_SET_NULL(buf);

	//5.��ȡӦ�ð汾
	mrc_seek(mrpHandel, 72, MR_SEEK_SET);
	mrc_memset(buffer, 0, sizeof(buffer));
	mrc_read(mrpHandel, &appver, sizeof(int32));
	hControl = SGL_FindChildWindow(pData.hContent, MRP_EDIT5);
	mrc_sprintf(buffer, "%d", appver);
	buf = asc2uni(buffer);
	SMP_Edit_SetText(hControl, (PWSTR)buf, TRUE, FALSE);
	FREE_SET_NULL(buf);

	//6.�ӿ�ʼλ�ð�ָ���Ƶ�ƫ��88����ȡmrp���ߣ�38�ֽڣ�����ȫΪ���ģ�
	mrc_seek(mrpHandel, 88, MR_SEEK_SET);
	mrc_memset(buffer, 0, sizeof(buffer));
	mrc_read(mrpHandel, (char*)buffer, 38);
	hControl = SGL_FindChildWindow(pData.hContent, MRP_EDIT6);
	buf = asc2uni(buffer);
	SMP_Edit_SetText(hControl, (PWSTR)buf, TRUE, FALSE);
	FREE_SET_NULL(buf);

	//7.�ӿ�ʼλ�ð�ָ���Ƶ�ƫ��128����ȡmrpӦ��˵����60�ֽ�
	mrc_seek(mrpHandel, 128, MR_SEEK_SET);
	mrc_memset(buffer, 0, sizeof(buffer));
	mrc_read(mrpHandel, (char*)buffer, 60);
	hControl = SGL_FindChildWindow(pData.hContent, MRP_EDIT7);
	buf = asc2uni(buffer);
	SMP_Edit_SetText(hControl, (PWSTR)buf, TRUE, FALSE);
	FREE_SET_NULL(buf);

	mrc_close(mrpHandel);      //��ȡ��ϣ��ر��ļ�
	mrpHandel = 0;
}

//д����Ϣ��MRP
int32 WriteToMrp(HWND hWnd)
{
	int32 mrpHandel = 0, ret  = 0, write = 0;    //��д��MRP�ļ����
	char* buffer;   //��д�뻺��������
	int appid, appver;

	//��mrp�ļ�
	mrpHandel = mrc_open((PCSTR)pData.mrpName, MR_FILE_RDWR);
	if(!mrpHandel) return MR_FAILED;

	//1.�ӿ�ʼλ�ð�ָ���Ƶ�ƫ��28��д��mrp��ʾ����22�ֽ�
	mrc_seek(mrpHandel, 28, MR_SEEK_SET);
	buffer = uni2asc(MrpInfo.appname);
	ret = mrc_write(mrpHandel, buffer, 22);
	write += ret;   //����д����ֽ���
	FREE_SET_NULL(buffer);

	//2.�ӿ�ʼλ�ð�ָ���Ƶ�ƫ��16����ȡmrp�ڲ�����11�ֽ�
	mrc_seek(mrpHandel, 16, MR_SEEK_SET);
	buffer = uni2asc(MrpInfo.filename);
	ret = mrc_write(mrpHandel, buffer, 11);
	write += ret;   //����д����ֽ���
	FREE_SET_NULL(buffer);

	//3.�ӿ�ʼλ�ð�ָ���Ƶ�ƫ��52����ȡmrp���кţ�16�ֽ�
	mrc_seek(mrpHandel, 52, MR_SEEK_SET);
	buffer = uni2asc(MrpInfo.code);
	ret = mrc_write(mrpHandel, buffer, 16);
	write += ret;   //����д����ֽ���
	FREE_SET_NULL(buffer);

	//4.дAPPID(������һ��68��һ��192)
	buffer = uni2asc(MrpInfo.appidstr);
	appid = mrc_atoi((PCSTR)buffer);
	mrc_seek(mrpHandel, 68, MR_SEEK_SET);
	ret = mrc_write(mrpHandel, &appid, sizeof(int));
	write += ret;   //����д����ֽ���
	FREE_SET_NULL(buffer);
	
	buffer = (char*)mrc_malloc(4*sizeof(uint8));
	mrc_writeBigEndianU32((uint32)appid, (uint8*)buffer);
	mrc_seek(mrpHandel, 192, MR_SEEK_SET);
	ret = mrc_write(mrpHandel, buffer, sizeof(int));
	write += ret;   //����д����ֽ���
	FREE_SET_NULL(buffer);

	//5.дӦ�ð汾(���� ƫ�� 72, 196)
	buffer = uni2asc(MrpInfo.appverstr);
	appver = mrc_atoi((PCSTR)buffer);
	mrc_seek(mrpHandel, 72, MR_SEEK_SET);
	ret = mrc_write(mrpHandel, &appver, sizeof(int));
	write += ret;   //����д����ֽ���
	FREE_SET_NULL(buffer);

	buffer = (char*)mrc_malloc(4*sizeof(uint8));
	mrc_writeBigEndianU32((uint32)appver, (uint8*)buffer);
	mrc_seek(mrpHandel, 196, MR_SEEK_SET);
	ret = mrc_write(mrpHandel, buffer, sizeof(int));
	write += ret;   //����д����ֽ���
	FREE_SET_NULL(buffer);


	//6.�ӿ�ʼλ�ð�ָ���Ƶ�ƫ��88����ȡmrp���ߣ�38�ֽ�
	mrc_seek(mrpHandel, 88, MR_SEEK_SET);
	buffer = uni2asc(MrpInfo.vender);
	ret = mrc_write(mrpHandel, (char*)buffer, 38);
	write += ret;   //����д����ֽ���
	FREE_SET_NULL(buffer);

	//7.�ӿ�ʼλ�ð�ָ���Ƶ�ƫ��128����ȡmrpӦ��˵����60�ֽ�
	mrc_seek(mrpHandel, 128, MR_SEEK_SET);
	buffer = uni2asc(MrpInfo.descrip);
	ret = mrc_write(mrpHandel, (char*)buffer, 60);
	write += ret;     //����д����ֽ���
	FREE_SET_NULL(buffer);

	mrc_close(mrpHandel);      //д����ϣ��ر��ļ�

	if(write > 0)
		SMP_MsgBox(TOPWIN_MSGBOX_COMMON, hWnd, NULL, SGL_LoadString(STR_HINT), SGL_LoadString(STR_EDIT_SUC), ID_OK | SMP_MSGBOXS_AUTOCLOSE, NULL);
	else
		SMP_MsgBox(TOPWIN_MSGBOX_COMMON, hWnd, NULL, SGL_LoadString(STR_HINT), SGL_LoadString(STR_EDIT_FAIL), ID_OK | SMP_MSGBOXS_AUTOCLOSE, NULL);
	
	return MR_SUCCESS;
}
