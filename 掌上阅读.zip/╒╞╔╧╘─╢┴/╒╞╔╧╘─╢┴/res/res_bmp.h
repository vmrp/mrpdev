
//begin the bitmaps
#define BMP_ARRDOWN 0
#define BMP_ARRDOWN_PRESS 1
#define BMP_ARRLEFT 2
#define BMP_ARRLEFT_PRESS 3
#define BMP_ARRRIGHT 4
#define BMP_ARRRIGHT_PRESS 5
#define BMP_FILE 6
#define BMP_FOLDER 7
#define BMP_ARCHIVE 8
#define BMP_AUDIO 9
#define BMP_HIDDEN 10
#define BMP_IMAGE 11
#define BMP_TEXT 12
#define BMP_VIDEO 13
#define BMP_MRP 14
#define BMP_ERROR 15
#define BMP_LOGO_STAR 16
#define BMP_TITLEBAR 17
#define BMP_TOOLBAR 18
#define BMP_PIC1 19
#define BMP_ICO1 20
#define BMP_ICO2 21
#define BMP_ICO3 22
#define BMP_ICO4 23

#define RES_BITMAP_COUNT 24
