#ifndef _MYTYPE_H_
#define _MYTYPE_H_

#define BOOL	int
#define BYTE	unsigned char
#define WORD	unsigned short 
#define DWORD	unsigned long
#define INT		int
#define u8      unsigned char
#define FALSE   0
#define TRUE    1

#endif



					 //800e  810b
//78,d8,a9,8d,a2,9a,ad,10,   ad,10,ad,10,ad,10,ad,10,ad,10,
					
	









