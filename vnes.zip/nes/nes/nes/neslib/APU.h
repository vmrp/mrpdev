#ifndef _APU_H_
#define _APU_H_
#include "mytype.h"

BYTE APU_Read(WORD addr);

#endif

