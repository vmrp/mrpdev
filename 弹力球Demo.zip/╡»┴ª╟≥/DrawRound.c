#include "mrc_base.h"
#include <math.h>

static mr_screenRectSt rect;
static int curX, curY;
static int32 timer;

//��ײ���
#define IS_HIT  \
	(rect.x <= 0 || (rect.x+rect.y>=240) || rect.y <= 0 || (rect.y+rect.h>=320))

//��ײ���
int isHit()
{
	return (rect.x <= 0 || (rect.x+rect.y>=240) || rect.y <= 0 || (rect.y+rect.h>=320));
}

//x,y ����ߵĵ�����꣬r�뾶
void fillRound(int16 x, int16 y, int r)
{
	int i, j;
	double l;
	int t1, t2;

	curX = x, curY = y;
	rect.x = x, rect.y = y - r, rect.w = rect.h = 2*r;

	mrc_clearScreen(0,0,0);

	t1 = mrc_getUptime();
	l = sqrt(2*pow(r,2));	//�ܳ�

	for(i=0; i <= (r*2); i++)
	{
		uint8 cr = 30, cg = 144, cb = 255;

		j = sqrt(pow(r,2) - pow(r-i,2));

		//�ϰ�Բ
		mrc_drawLine(x+i, y, x+i, y-j, cr+i,cg-i,cb-i);
		//�°�Բ
		mrc_drawLine(x+i, y, x+i, y+j,  cr+i,cg-i,cb-i);
	}
	t2 = mrc_getUptime();

	{
		char buf[50] = {0};
		mrc_sprintf(buf, "Paint Time=%d", t2-t1);
		mrc_drawText(buf, 0, 300, 30,144,255, 0, 0);
	}

	mrc_refreshScreen(0, 0, 240, 320);
}

//x,y ����ߵĵ������
void drawRound(int16 x, int16 y, int r)
{
	int i, j, k=0;
	double l;
	int t1, t2;

	mrc_clearScreen(0,0,0);

	curX = x, curY = y;
	rect.x = x, rect.y = y - r, rect.w = rect.h = 2*r;

	t1 = mrc_getUptime();
	l = sqrt(2*pow(r,2));
	for(k=0; k<r; k++)
	{
		//r = 80-k;
		for(i=0; i <= (r*2); i++)
		{
			int32 cr = 30, cg = 144, cb = 255;

			j = sqrt(pow(r,2) - pow(r-i,2));

			mrc_drawPointEx(x+i+k, y-j, cr+i,cg-i,cb-i);

			mrc_drawPointEx(x+i+k, y+j,  cr+i,cg-i,cb-i);
		}
	}
	t2 = mrc_getUptime();

	{
		char buf[50] = {0};
		mrc_sprintf(buf, "Paint Time=%d", t2-t1);
		mrc_drawText(buf, 0, 300, 30,144,255, 0, 0);
	}

	mrc_refreshScreen(0,0,240,320);
}

void moveCB(int32 data)
{
	if(IS_HIT)
	{
		curX += 5; curY += 5;
		fillRound(curX, curY, 50);
	}else
	{
		curX -= 5; curY -= 5;
		fillRound(curX, curY, 50);
	}
}

int32 MRC_EXT_INIT(void)
{
	mrc_clearScreen(0,0,0);

	curX = 1;
	curY = 55;
	timer = mrc_timerCreate();
	mrc_timerStart(timer, 100, 0, moveCB, 1);

	//fillRound(0, 50, 50);
	//drawRound(0, 100, 50);

	return MR_SUCCESS;
}

int32 mrc_appEvent(int32 code, int32 param0, int32 param1)
{
	switch (code)
	{
	case MR_MOUSE_MOVE:
	case MR_MOUSE_DOWN:
	case MR_MOUSE_UP:
		{
			int16 x = (int16)param0;
			int16 y = (int16)param1;
			fillRound(x, y, 50);
			break;
		}
	}
	return MR_SUCCESS;
}


int32 mrc_appPause(void)
{
	return 0;
}


int32 mrc_appResume(void)
{
	return 0;
}


int32 MRC_EXT_EXIT(void)
{
	return 0;
}