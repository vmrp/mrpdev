
#include "mrc_base.h"

#include "jinclude.h"

#include "jcapi.h"
#include "jcint.h"

extern unsigned char dcttab[3][512];
extern unsigned char inbuf_buf[11520];

extern void  jhuff_flush_buffer(jpeg_compress_info *cinfo);
extern jpeg_compress_info info1;

jpeg_compress_info * jpeg_create_compress( void ) 
{
  jpeg_compress_info *cinfo = &info1;
  memset((void *)(cinfo), 0, sizeof(jpeg_compress_info));
  cinfo->state = JC_CREATING;
  return cinfo;
}
void jpeg_destory_compress( jpeg_compress_info *cinfo ) {
 
  
  if (cinfo->state != JC_FINISH)
    ;
  cinfo->state = JC_DESTORING;
}

void jpeg_set_default( jpeg_compress_info *cinfo ) 
{
  cinfo->precision = 8;  
  cinfo->in_color_space = JCS_RGB;
  cinfo->quality = 1.0f;
  #define SET_COMP(TARGET,ID,H,V,Tq,Td,Ta) \
  ( TARGET.comp_id = (ID),\
    TARGET.comp_index = (ID),\
    TARGET.h_factor = (H),\
    TARGET.v_factor = (V),\
    TARGET.quant_tbl_no = (Tq),\
    TARGET.dc_tbl_no = (Td),\
    TARGET.ac_tbl_no = (Ta) )

  cinfo->num_comp = 3;
  SET_COMP(cinfo->comp[0], 1, 2,2, 0, 0,0);
  SET_COMP(cinfo->comp[1], 2, 1,1, 1, 1,1);
  SET_COMP(cinfo->comp[2], 3, 1,1, 1, 1,1);  
  jint_std_quant_tables(cinfo);
  jint_std_huff_tables(cinfo);
  jpeg_calc_value(cinfo);
}
void jpeg_calc_value( jpeg_compress_info *cinfo ) 
{
  int i, h, v, bn;
  int size;
  jpeg_component_info *pcomp;

  cinfo->state = JC_SETTING;
  
  bn = 0;
  cinfo->max_h_factor = 0;
  cinfo->max_v_factor = 0;

  for (i=0; i<cinfo->num_comp; i++) 
  {
    pcomp = &cinfo->comp[i];
    h = pcomp->h_factor;
    v = pcomp->v_factor;
    
    if (cinfo->max_h_factor < h) 
    {
      cinfo->max_h_factor = h;
    }
    if (cinfo->max_v_factor < v) 
    {
      cinfo->max_v_factor = v;
    }
    bn += (h*v);

    pcomp->num_dct_table = h * v;
    size = sizeof(DCTBLOCK) * pcomp->num_dct_table;
    pcomp->dct_table = (DCTBLOCK *)(dcttab[i]);
    memset((void *)(pcomp->dct_table), 0, size);
  }
  
  if (bn > MAX_BLOCK_IN_MCU) {
   mrc_exit();
  }
  
  cinfo->block_in_mcu = bn;
  cinfo->mcu_width  = cinfo->max_h_factor * DCTSIZE;
  cinfo->mcu_height = cinfo->max_v_factor * DCTSIZE;
  cinfo->mcu_blocks = cinfo->mcu_width * cinfo->mcu_height;

  cinfo->mcu_per_row = cinfo->image_width / cinfo->mcu_width;
  if (cinfo->image_width  % cinfo->mcu_width != 0)
    cinfo->mcu_per_row++;
  cinfo->mcu_rows    = cinfo->image_height / cinfo->mcu_height;
  if (cinfo->image_height % cinfo->mcu_height != 0)
    cinfo->mcu_rows++;

  cinfo->inbuf_width  = cinfo->mcu_per_row * cinfo->mcu_width;
  cinfo->inbuf_height = cinfo->mcu_height;
  cinfo->inbuf_size = cinfo->inbuf_width * cinfo->inbuf_height 
                    * cinfo->num_comp  * sizeof(JSAMPLE);
  cinfo->inbuf = (JSAMPLE *)inbuf_buf;
  memset((void *)(cinfo->inbuf), 0, cinfo->inbuf_size);

  cinfo->next_line = 0;
}
void jpeg_write_scanline( jpeg_compress_info *cinfo, 
                     JSAMPLE *samp_row ) 
{
  int x, c;
  int pos, size, last;

  
  if (cinfo->state != JC_START)
  {
    //mrc_printf("������cinfo->state != JC_START");
  }
  size = cinfo->num_comp * sizeof(JSAMPLE);
  pos  = cinfo->inbuf_width * size * (cinfo->next_line % cinfo->inbuf_height);
  memcpy(&cinfo->inbuf[pos], samp_row, cinfo->image_width * size);

  last = cinfo->image_width - 1;
  pos += cinfo->image_width * size;
  for (x=0; x<cinfo->inbuf_width-cinfo->image_width; x++) {
    for (c=0; c<cinfo->num_comp; c++) {
      cinfo->inbuf[pos+x*cinfo->num_comp+c] = samp_row[last*cinfo->num_comp+c];
    }
  }
  cinfo->next_line++;
  if (cinfo->next_line%cinfo->inbuf_height == 0) {
    jint_process_rows(cinfo);
    memset((void *)(cinfo->inbuf), 0, cinfo->inbuf_size);
  }
}
void
jpeg_start_compress  (jpeg_compress_info *cinfo) 
{
  int i;
  if (cinfo->state != JC_SETTING)
  {
   //mrc_printf("������cinfo->state != JC_SETTING");
  }

  jmkr_write_start(cinfo);
  cinfo->state = JC_START;
  cinfo->next_line = 0;
  for(i=0; i<cinfo->num_comp; i++) {
    cinfo->comp[i].preval = 0;
  }
}
void jpeg_finish_compress (jpeg_compress_info *cinfo) 
{
  int i, startline, rowlen;
  JSAMPLE *data;
  if (cinfo->state != JC_START)
  {
   //mrc_printf("������cinfo->state != JC_START");
  }
  if (cinfo->next_line%cinfo->inbuf_height != 0) {
    rowlen = cinfo->inbuf_width * cinfo->num_comp * sizeof(JSAMPLE);
    startline = cinfo->next_line % cinfo->inbuf_height;
    data  = &cinfo->inbuf[(startline - 1)*rowlen];
    if (startline!=0) {
      for (i=startline; i<cinfo->inbuf_height; i++)
        memcpy(&cinfo->inbuf[i*rowlen], data,rowlen);
    }
    jint_process_rows(cinfo);  
  }

  jhuff_flush_buffer(cinfo); 
  jmkr_write_end(cinfo);
  cinfo->state = JC_FINISH;
}

