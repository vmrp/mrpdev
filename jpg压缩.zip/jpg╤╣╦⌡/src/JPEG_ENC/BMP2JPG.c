#include   "mrc_base.h"
#include "jinclude.h"
#include "jcapi.h"

unsigned char *JPG_enc_buf;
unsigned int pt_buf;
jpeg_compress_info info1;
JQUANT_TBL  JQUANT_TBL_2[2];
JHUFF_TBL  JHUFF_TBL_4[4];
unsigned char dcttab[3][512];
unsigned char inbuf_buf[11520];

int32 BMP2JPG(uint8* Bmpbuf,char* JpgName,uint32 w,uint32 h) 
{
 
  int32 f,t=0;
  char*image;
  jpeg_compress_info *cinfo;
  pt_buf = 0;
  
  image =(char*)Bmpbuf;

  JPG_enc_buf=(unsigned char*)mrc_malloc(30*1024);
 
  if(inbuf_buf==NULL||JPG_enc_buf==NULL)
  {
     mrc_exit();//�ڴ治��
	 return -1;
  }
  else
  {
  mrc_memset(JPG_enc_buf,0,30*1024);
 
  }

  cinfo = jpeg_create_compress();
  cinfo->image_width = (int)w;
  cinfo->image_height= (int)h;
  cinfo->output =(char*) JPG_enc_buf;
  

  jpeg_set_default(cinfo);  
  f=mrc_open(JpgName,12);
  
  jpeg_start_compress(cinfo);
  while (cinfo->next_line < cinfo->image_height) 
  {
    jpeg_write_scanline(cinfo,(JSAMPLE *) &image[w*h*3-(cinfo->next_line*cinfo->image_width*3)]);
    t++;
  }
  jpeg_finish_compress(cinfo);
  
  mrc_write(f,JPG_enc_buf ,pt_buf);
  mrc_close(f);
  jpeg_destory_compress(cinfo);
  mrc_free(JPG_enc_buf);
  mrc_printf("%d",t);
 return 0;
}


