#ifndef JERROR_H
#define JERROR_H

typedef struct {
  char code;
  char *msg;
} JERROR;

#endif /*JERROR_H*/

