#include "mr_toolbar.h"

VOID Toolbar_Create(VOID)
{

}