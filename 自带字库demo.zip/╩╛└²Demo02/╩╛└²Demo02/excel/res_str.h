
//begin the strings
#define STR_HELLOWORLD 0
#define STR_HELP 1
#define STR_OK 2
#define STR_MENU 3
#define STR_EXIT 4
#define STR_CANCEL 5
#define STR_TITLE 6
#define STR_TEST 7
#define STR_HELP_TEXT 8
#define STR_HINT_EXIT 9

#define RES_STRING_COUNT 10
