#include "mrc_base.h"
#include "i18n.h"
#include "res_str.h"


int32 MRC_EXT_INIT(void)
{
	return MR_SUCCESS;
}

int32 MRC_EXT_EXIT(void)
{	
	return MR_SUCCESS;
}

int32 mrc_appEvent(int32 code, int32 param0, int32 param1)
{//�Ʒ�״̬�£��Զ�����
	return MR_SUCCESS;
}

int32 mrc_appPause()
{//�Ʒ�״̬�£��Զ�����
	return MR_SUCCESS;	
}

int32 mrc_appResume()
{
	return MR_SUCCESS;
}
