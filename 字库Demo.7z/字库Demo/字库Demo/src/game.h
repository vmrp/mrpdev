#ifndef _GAME_H_

#define _GAME_H_


void Game_Start(void);
void Game_Pause(void);
void Game_Resume(void);
void Game_ReleaseSource(void);
void Game_KeyCheck(int32 code, int32 param0, int32 param1);



#endif
