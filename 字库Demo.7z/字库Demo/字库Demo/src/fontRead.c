#include "mrc_base.h"
#include "mrc_exb.h"
#include "mrc_bmp.h"
#include "debug.h"

#include "fontRead.h"

//�ļ����淶
//fpoint_1.bin    fpoint_2.bin     fpoint_3.bin �ֱ��ӦBIG��MEDIUM��SAMLL���������
//fun_1.bin    fun_2.bin     fun_3.bin �ֱ��ӦBIG��MEDIUM��SAMLL������unicode����
//fgb_1.bin    fgb_2.bin     fgb_3.bin �ֱ��ӦBIG��MEDIUM��SAMLL������gb2312����
//
//
#define FONT_POINT "fpoint_%d.bin"
#define FONT_UINDEX "fun_%d.bin"
#define FONT_GBINDEX "fgb_%d.bin"

typedef enum
{
	FONT_TYPE_BIG = 1,
	FONT_TYPE_MEDIUM = 2,
	FONT_TYPE_SAMLL=3
}E_FONT_TYPE;


#define FONT_DES		128
#define INSERT_WIDHT	0
#define INSERT_HEIGHT	0


typedef struct fontPoint
{
	uint8 *uIndexBuf;
	uint8 *bIndexBuf;
	uint8 *PointBuf;

	BOOL isMemBuf;
	BOOL isSupport;

	int32 uIndexLen;
	int32 bIndexLen;
	int32 PointLen;

	int32 fontWidth;
	int32 fontHeight;
	int32 fontLen;

	int32 fontHandle;

}T_POINT_INFO;


T_POINT_INFO g_big;
T_POINT_INFO g_medium;
T_POINT_INFO g_small;
T_POINT_INFO g_nowUse;

static uint8 Buf[FONT_DES];		     //���������Ϣ����

static mr_screeninfo screen_Size;
static BOOL useSysFontInfo;			//TURE��ʶ��������Ϸ�Դ��ֿ⣬��ôʹ��ϵͳ�ֿ�; False ��ʶ������Ϸ�Դ��ֿ⣬ʹ���Դ��ֿ�


T_POINT_INFO GetSupportFont(MR_FONT_TYPE  font)
{
	switch(font)
	{
	case MR_FONT_BIG:
		if(g_big.isSupport)
		{
			return g_big;
		}
		else if(g_medium.isSupport)
		{
			return g_medium;
		}
		else if(g_small.isSupport)
		{
			return g_small;
		}
	case MR_FONT_MEDIUM:
		if(g_medium.isSupport)
		{
			return g_medium;
		}
		else if(g_big.isSupport)
		{
			return g_big;
		}
		else if(g_small.isSupport)
		{
			return g_small;
		}
	case MR_FONT_SMALL:
		if(g_small.isSupport)
		{
			return g_small;
		}
		else if(g_big.isSupport)
		{
			return g_big;
		}
		else if(g_medium.isSupport)
		{
			return g_medium;
		}
	}
	return g_medium;
}

//��ȡһ���ַ����ֿ�����е�����
int32 GetOffSet(uint16 chr, E_CHR_SET flag)
{	//flag TRUE ��ʶΪUNICODE����FALSE��ʶΪGB��
	uint16 iM = 0;//(һ�������16λUNICODEֵ16λƫ����)
	uint16 iB = 1;
	uint16 iE = 0;
	int32 UValue = 0;
	int32 indexLen = 0;
	uint8 *buf = NULL;

	switch(flag)
	{
	case MR_SET_GB:
		indexLen = g_nowUse.bIndexLen;
		buf = g_nowUse.bIndexBuf;
		break;
	case MR_SET_UNICODE:
		indexLen = g_nowUse.uIndexLen;
		buf = g_nowUse.uIndexBuf;
		break;
	default:
		return 0;
	}

	iE = indexLen /5;
	while(iB <= iE)
	{
		iM = (iB + iE)/2;
		UValue = buf[(iM-1)*5];
		UValue = UValue << 8;
		UValue += buf[(iM-1)*5+1];
		
		if(chr == UValue)
		{
			UValue = buf[(iM-1)*5+2];
			UValue = UValue << 8;
			UValue += buf[(iM-1)*5+3];
			UValue = UValue << 8;
			UValue += buf[(iM-1)*5+4];

			return UValue;
		}
		else if(chr > UValue)
		{
			iB = iM+1;
		}
		else
		{
			iE = iM-1;
		}
	}

	return 0;
}

int32 freeFontData(char *filename,char *path)
{

	return MR_FAILED;
}

int32 readIndexData(char * filename,uint8 *buf,int32 *buflen)
{
	return   mrc_readFileFromMrpEx(NULL, filename, (uint8**)&buf, buflen, 0);
}

const uint8* GetgbBitmap(uint16 ch, uint16 font)
{
	int32 offset = GetOffSet(ch,FALSE);
	mrc_memset(Buf,0,FONT_DES);
	if(g_nowUse.isMemBuf == TRUE)
	{
		mrc_memcpy(Buf, g_nowUse.PointBuf + offset, FONT_DES);
	}
	else
	{
		mrc_seek(g_nowUse.fontHandle, offset, MR_SEEK_SET);
		mrc_read(g_nowUse.fontHandle, Buf, FONT_DES);
	}	

	return (uint8*)Buf;
}

const uint8* GetUniBitmap(uint16 ch, uint16 font)
{
	int32 offset = GetOffSet(ch,TRUE);

	if(offset == 0)
		return NULL;

	mrc_memset(Buf, 0, FONT_DES);
	if(g_nowUse.isMemBuf == TRUE)
	{
		mrc_memcpy(Buf, g_nowUse.PointBuf + offset, FONT_DES);
	}
	else
	{
		mrc_seek(g_nowUse.fontHandle, offset, MR_SEEK_SET);
		mrc_read(g_nowUse.fontHandle, Buf, FONT_DES);
	}

	return (uint8*)Buf;
}

int32 _drawChar(char* chr, int16 x, int16 y, mr_colourSt colorst, E_CHR_SET flag, uint16 font)
{
	uint16 chU = 0;
	const uint8 *current_bitmap;
	uint16 color=MAKERGB(colorst.r, colorst.g, colorst.b);
	uint16 *screenBuf = (uint16 *)w_getScreenBuffer();
	int8 index_I,index_J = 0;
	uint16 totalPoint = 0;
	uint16 totalIndex = 0;
	int32 temp = 0;
	int32 X,Y;
	mrc_memset(&g_nowUse,0,sizeof(T_POINT_INFO));
	g_nowUse = GetSupportFont(font);

	if(!chr)
	{
		return MR_FAILED;
	}
	if(x > screen_Size.width || y >screen_Size.height || x < 0 || y < 0)
	{
		return MR_FAILED;
	}
	switch(flag)
	{
	case MR_SET_UNICODE:
		chU = *chr;
		chU = chU << 8;
		chU += (uint8)*(chr+1);
		break;
	case MR_SET_GB:
		if((chU = *chr) > 0x80)
		{
			chU = chU << 8;
			chU += (uint8)*(chr+1);
		}
		break;
	default:
		return MR_FAILED;
	}

	if(chU == 0x20||chU == 0xa || chU == 0xd)
	{
		return	MR_SUCCESS;
	}
	switch(flag)
	{
	case MR_SET_UNICODE:
		current_bitmap = GetUniBitmap(chU,font);
		if(!current_bitmap)
		{
			return MR_FAILED;
		}
		g_nowUse.fontWidth = *current_bitmap;
		if(g_nowUse.fontWidth + x > screen_Size.width)
			return MR_FAILED;
		g_nowUse.fontLen = *(current_bitmap + 1);
		current_bitmap += 2;
		break;
	case MR_SET_GB:
		current_bitmap = GetgbBitmap(chU, font);
		if(!current_bitmap)
		{
			return MR_FAILED;
		}
		g_nowUse.fontWidth = (uint8)*current_bitmap;
		g_nowUse.fontLen = (uint8)*(current_bitmap + 1);
		current_bitmap += 2;
		break;
	default:
		return MR_FAILED;
	}
	totalPoint = g_nowUse.fontHeight * g_nowUse.fontWidth;
	X = x;
	Y = y;
	for ( index_I = 0; index_I < g_nowUse.fontLen; index_I++)
	{
		temp = current_bitmap[index_I];
		for (index_J = 0; index_J < 8; index_J++)
		{
			totalIndex++;
			if (temp & 0x80)
			{
				*(screenBuf + Y * screen_Size.width + X) = color;
			}
			X++;
			if ((totalIndex % g_nowUse.fontWidth) == 0)
			{
				Y++;
				X= x;
			}
			if (totalIndex >= totalPoint)
				break;
			temp = temp << 1;
		}
	}
	return MR_SUCCESS;
}

int32 _drawTextLeftByLineN(char* pcText, int16 x, int16 y, mr_screenRectSt rect, mr_colourSt colorst, E_CHR_SET flag, uint16 font, int32 lineStart)
{
	if (!pcText)
	{
		return MR_FAILED;
	}
	if(useSysFontInfo)
	{
		mrc_drawTextLeft(pcText,  x,  y,rect, colorst, 3,font);
		return MR_SUCCESS;
	}

	{
		uint16 ch;
		uint8 a_ch[4];
		uint16* screenBuf = w_getScreenBuffer();
		const char *current_bitmap;
		uint8  *p=(uint8*)pcText;
		int16 chx=x,chy=y;
		int32 totalIndex,totalPoint,X1,Y1,index_I,index_J;
		uint8 temp = 0;
		uint16 color=MAKERGB(colorst.r, colorst.g, colorst.b);
		BOOL sign = FALSE;
		mrc_memset(&g_nowUse,0,sizeof(T_POINT_INFO));
		g_nowUse = GetSupportFont(font);
		a_ch[2]=a_ch[3]=0;
		switch(flag)
		{
		case MR_SET_UNICODE:
			ch = (uint16) ((*p<<8)+*(p+1));
			break;
		case MR_SET_GB:
			if((ch = *p)>0x80)
			{
				ch = ch <<8;
				ch += *(p+1);
			}
			break;
		default:
			return MR_FAILED;
		}//����unicode/GB����ֵ

		while(ch)
		{
			if ((ch == 0x0a) || (ch == 0x0d))
			{//���д���
				chy += (g_nowUse.fontHeight + INSERT_HEIGHT);
				chx = x;
				//p += 2;//�Ƴ���һ���ո�
				goto sign;
			}
			else if(ch == 0x20)
			{//�ո���
				chx +=8;
				if(chx >(rect.x + rect.w))
				{
					chx = x;
					chy +=  (g_nowUse.fontHeight+ INSERT_HEIGHT);
				}
				goto sign;
			}
			else
			{
				switch(flag)
				{
				case MR_SET_UNICODE:
					current_bitmap =(char*) GetUniBitmap(ch, font);
					if(!current_bitmap)
					{
						return MR_FAILED;
					}
					g_nowUse.fontWidth = *current_bitmap;
					g_nowUse.fontLen = *(current_bitmap+1);
					current_bitmap += 2;
					break;
				case MR_SET_GB:
					current_bitmap =(char*) GetgbBitmap(ch, font);
					if(!current_bitmap)
					{
						return MR_FAILED;
					}
					g_nowUse.fontWidth = *current_bitmap;
					g_nowUse.fontLen = *(current_bitmap+1);
					current_bitmap += 2;
					break;
				default:
					return MR_FAILED;
				}
			}
			if((chx + g_nowUse.fontWidth) > (rect.x + rect.w))
			{
				chy += (g_nowUse.fontHeight + INSERT_HEIGHT);
				chx = x;
			}
			if((chy-y)/g_nowUse.fontHeight < lineStart && !sign)
			{
				chx = chx + g_nowUse.fontWidth + INSERT_WIDHT;
				goto sign;
			}
			else if(!sign)
			{
				sign = TRUE;
				chy = y;
			}
			if(((chx+g_nowUse.fontWidth) <= (rect.x + rect.w)) && (chx >= rect.x) &&
				((chy+g_nowUse.fontHeight) <= (rect.y + rect.h)) && (chy >= rect.y) && chx >= 0 && chy >= 0)
			{
				totalPoint = g_nowUse.fontHeight * g_nowUse.fontWidth;
				X1 = Y1 = 0;
				totalIndex = 0;
				for ( index_I = 0; index_I < g_nowUse.fontLen; index_I++)
				{
					temp = current_bitmap[index_I];
					for (index_J = 0; index_J < 8; index_J++)
					{
						totalIndex++;
						if (temp & 0x80)
						{
							*(screenBuf + (chy + Y1) * screen_Size.width + (chx + X1)) = color;
						}
						X1++;
						if(!g_nowUse.fontWidth)
							return MR_FAILED;
						if ((totalIndex % g_nowUse.fontWidth) == 0)
						{
							Y1++;
							X1= 0;
						}
						if (totalIndex >= totalPoint)
							break;
						temp = temp << 1;
					}

				}
			}
			chx = chx + g_nowUse.fontWidth + INSERT_WIDHT;
sign:
			if(ch <0x80 && !flag)
			{
				p+=1;
			}
			else
			{
				p+=2;
			}   //���ݱ������� ����ƫ����
			if(flag == MR_SET_UNICODE)
			{
				ch = (uint16) ((*p<<8)+*(p+1));
			}
			else if(flag == MR_SET_GB)
			{
				if((ch = *p)>0x80)
				{
					ch = ch <<8;
					ch += *(p+1);
				}
			}//����unicode/GB����ֵ
		};
	}

	return 0;
}

int32 _drawTextLeft(char* pcText, int16 x, int16 y, mr_screenRectSt rect, mr_colourSt colorst, E_CHR_SET flag, uint16 font)
{
	if (!pcText)
	{
		return MR_FAILED;
	}
	
	if(useSysFontInfo)
	{
		mrc_drawTextLeft(pcText,  x,  y,rect, colorst, 3,font);
		return MR_SUCCESS;
	}

	{
		uint16 ch;
		uint8 a_ch[4];
		uint16* screenBuf = w_getScreenBuffer();
		const char *current_bitmap;
		uint8  *p=(uint8*)pcText;
		int16 chx=x,chy=y;
		int32 totalIndex,totalPoint,X1,Y1,index_I,index_J;
		uint8 temp = 0;
		uint16 color=MAKERGB(colorst.r, colorst.g, colorst.b);
		
		mrc_memset(&g_nowUse,0,sizeof(T_POINT_INFO));
		g_nowUse = GetSupportFont(font);
		a_ch[2]=a_ch[3]=0;
		
		switch(flag)
		{
		case MR_SET_UNICODE:
			ch = (uint16) ((*p<<8)+*(p+1));
			break;
		case MR_SET_GB:
			if((ch = *p)>0x80)
			{
				ch = ch <<8;
				ch += *(p+1);
			}
			break;
		default:
			return MR_FAILED;
		}//����unicode/GB����ֵ

		while(ch)
		{
			if ((ch == 0x0a) || (ch == 0x0d))
			{//���д���
				chy += (g_nowUse.fontHeight + INSERT_HEIGHT);
				chx = x;
				//p += 2;//�Ƴ���һ���ո�
				goto sign;
			}
			else if(ch == 0x20)
			{//�ո���
				chx +=8;
				if(chx >(rect.x + rect.w))
				{
					chx = x;
					chy +=  (g_nowUse.fontHeight+ INSERT_HEIGHT);
				}
				goto sign;
			}
			else
			{
				switch(flag)
				{
				case MR_SET_UNICODE:
					current_bitmap =(char*) GetUniBitmap(ch, font);
					if(!current_bitmap)
					{
						return MR_FAILED;
					}
					g_nowUse.fontWidth = *current_bitmap;
					g_nowUse.fontLen = *(current_bitmap+1);
					current_bitmap += 2;
					break;
				case MR_SET_GB:
					current_bitmap =(char*) GetgbBitmap(ch, font);
					if(!current_bitmap)
					{
						return MR_FAILED;
					}
					g_nowUse.fontWidth = *current_bitmap;
					g_nowUse.fontLen = *(current_bitmap+1);
					current_bitmap += 2;
					break;
				default:
					return MR_FAILED;
				}
			}
			if((chx + g_nowUse.fontWidth) > (rect.x + rect.w))
			{
				chy += (g_nowUse.fontHeight + INSERT_HEIGHT);
				chx = x;
			}

			if(((chx+g_nowUse.fontWidth) <= (rect.x + rect.w)) && (chx >= rect.x) &&
				((chy+g_nowUse.fontHeight) <= (rect.y + rect.h)) && (chy >= rect.y) && chx >= 0 && chy >= 0)
			{
				totalPoint = g_nowUse.fontHeight * g_nowUse.fontWidth;
				X1 = Y1 = 0;
				totalIndex = 0;
				for ( index_I = 0; index_I < g_nowUse.fontLen; index_I++)
				{
					temp = current_bitmap[index_I];
					for (index_J = 0; index_J < 8; index_J++)
					{
						totalIndex++;
						if (temp & 0x80)
						{
							*(screenBuf + (chy + Y1) * screen_Size.width + (chx + X1)) = color;
						}
						X1++;
						if(!g_nowUse.fontWidth)
							return MR_FAILED;
						if ((totalIndex % g_nowUse.fontWidth) == 0)
						{
							Y1++;
							X1= 0;
						}
						if (totalIndex >= totalPoint)
							break;
						temp = temp << 1;
					}

				}
			}
			chx = chx + g_nowUse.fontWidth + INSERT_WIDHT;
sign:
			if(ch <0x80 && !flag)
			{
				p+=1;
			}
			else
			{
				p+=2;
			}   //���ݱ������� ����ƫ����
			if(flag == MR_SET_UNICODE)
			{
				ch = (uint16) ((*p<<8)+*(p+1));
			}
			else if(flag == MR_SET_GB)
			{
				if((ch = *p)>0x80)
				{
					ch = ch <<8;
					ch += *(p+1);
				}
			}//����unicode/GB����ֵ
		};
	}
	return 0;
}

int32 _drawText(char* chr, int16 x, int16 y,  mr_colourSt colorst, E_CHR_SET flag, uint16 font)
{
	if (!chr ||y < 0)
	{
		return MR_FAILED;
	}
	//��������Ϸ�Դ��ֿ⣬��ôת��ϵͳ�ֿ�ȥ��
	if(useSysFontInfo)
	{
		mrc_drawText(chr,x,y,colorst.r,colorst.g,colorst.b,flag,font);
		return MR_SUCCESS;
	}
	//������Ϸ�Դ��ֿ⣬ʹ���Դ��ֿ�
	{
		int totalPoint,totalIndex,index_I,index_J;
		uint16 *tempBuf= (uint16 *)chr;
		uint16 ch=0;
		uint16* screenBuf = w_getScreenBuffer();
		int32 temp_mr_screen_w = screen_Size.width;
		int32 X1,Y1,chx,chy;
		const uint8 *current_bitmap;
		uint8  *p=(uint8*)tempBuf;
		uint8 temp = 0;
		uint16 color=MAKERGB(colorst.r, colorst.g, colorst.b);
		mrc_memset(&g_nowUse,0,sizeof(T_POINT_INFO));
		g_nowUse = GetSupportFont(font);
		if(y+g_nowUse.fontHeight > screen_Size.height)
			return MR_FAILED;
		switch(flag)
		{
		case MR_SET_UNICODE:
			ch = (uint16) ((*p<<8)+*(p+1));
			break;
		case MR_SET_GB:
			if((ch = *p)>0x80)
			{
				ch =ch << 8;
				ch += *(p+1);
			}
			break;
		default:
			return MR_FAILED;
		}
		chx=x;
		chy=y;

		while(ch)
		{
			X1 = Y1 = 0;
			totalIndex = totalPoint = 0;
			if ((ch == 0x0a) || (ch == 0x0d))
			{//����ֱ�ӷ���
				return MR_SUCCESS;
			}
			else if(ch == 0x20)
			{//�ո���ո�
				chx += 8;
				goto sign;
			}
			else
			{
				switch(flag)
				{
				case MR_SET_UNICODE:
					current_bitmap = GetUniBitmap(ch, font);
					if(!current_bitmap)
					{
						return MR_FAILED;
					}
					g_nowUse.fontWidth = *current_bitmap;
					g_nowUse.fontLen = *(current_bitmap+1);
					current_bitmap += 2;
					break;
				case MR_SET_GB:
					current_bitmap = GetgbBitmap(ch, font);
					if(!current_bitmap)
					{
						return MR_FAILED;
					}
					g_nowUse.fontWidth = *current_bitmap;
					g_nowUse.fontLen = *(current_bitmap+1);
					current_bitmap +=2;
					break;
				default:
					return MR_FAILED;
				}
			}
			if((chx+ g_nowUse.fontWidth ) >temp_mr_screen_w)
				return MR_SUCCESS;
			if(chx < 0)
			{
				chx =chx +  g_nowUse.fontWidth + INSERT_WIDHT;//�ּ��Ϊ 4
				goto sign;
			}
			totalPoint = g_nowUse.fontHeight * g_nowUse.fontWidth;
			totalIndex = 0;
			for ( index_I = 0; index_I < g_nowUse.fontLen; index_I++)
			{
				temp = current_bitmap[index_I];
				for (index_J = 0; index_J < 8; index_J++)
				{
					totalIndex++;
					if (temp & 0x80)
					{
						*(screenBuf + (chy + Y1) * screen_Size.width + (chx + X1)) = color;
					}
					X1++;
					if(!g_nowUse.fontWidth)
						return MR_FAILED;
					if ((totalIndex % g_nowUse.fontWidth) == 0)
					{
						Y1++;
						X1= 0;
					}
					if (totalIndex >= totalPoint)
						break;
					temp = temp << 1;
				}
			}
			chx =chx +  g_nowUse.fontWidth + INSERT_WIDHT;//�ּ��Ϊ 4
sign:
			if((ch < 0x80) && (flag == MR_SET_GB))
			{
				p+= 1;
			}
			else
			{
				p+=2;
			}
			if(flag)
			{
				ch = (uint16) ((*p<<8)+*(p+1));
			}
			else
			{
				if((ch = *p)>0x80)
				{
					ch =ch << 8;
					ch +=*(p+1);
				}
			}
		}
	}
	return MR_SUCCESS;
}

int32 _drawTextFromRight(char* pcText, int16 x, int16 y, mr_screenRectSt rect, mr_colourSt colorst,E_CHR_SET flag,  uint16 font)
{
	uint8 tempwidth = 0;
	if (!pcText)
	{
		return MR_FAILED;
	}
	if(useSysFontInfo)
	{
		mrc_drawTextRight(pcText,  x,  y,rect, colorst, flag,font);
		return MR_SUCCESS;
	}

	{
		uint16 ch;
		uint16* screenBuf = w_getScreenBuffer();
		const char *current_bitmap;
		uint8  *p=(uint8*)pcText;
		int16 chx = rect.x + rect.w - x, chy=y;      //XΪrect�����ұ߿���ʼ���λ��,Ӧ���ټ�ȥ��һ���ֵĿ��ȣ���������
		int32 totalIndex,totalPoint,X1,Y1,index_I,index_J;		
		uint8 temp = 0;
		uint16 color=MAKERGB(colorst.r, colorst.g, colorst.b);		
		mrc_memset(&g_nowUse,0,sizeof(T_POINT_INFO));
		g_nowUse = GetSupportFont(font);
		switch(flag)
		{
		case MR_SET_UNICODE:
			ch = (uint16) ((*p<<8)+*(p+1));
			break;
		case MR_SET_GB:
			if((ch = *p)>0x80)
			{
				ch = ch <<8;
				ch += *(p+1);
			}
			break;
		default:
			return MR_FAILED;
		}//����unicode/GB����ֵ

		while(ch)
		{
			if((ch == 0x0a) || (ch == 0x0d))
			{//���д���
				chy += (g_nowUse.fontHeight + INSERT_HEIGHT);
				chx = rect.x + rect.w;
				goto sign;	
			}
			else if(ch == 0x20)
			{//�ո���
				chx -=tempwidth;
				if(chx < rect.x)
				{
					chx = rect.x + rect.w;
					chy +=  (g_nowUse.fontHeight+ INSERT_HEIGHT);
				}
				goto sign;
			}
			else
			{
				switch(flag)
				{
				case MR_SET_UNICODE:
					current_bitmap =(char*) GetUniBitmap(ch, font);
					if(!current_bitmap)
					{
						return MR_FAILED;
					}
					g_nowUse.fontWidth = *current_bitmap;
					g_nowUse.fontLen = *(current_bitmap+1);
					current_bitmap += 2;
					break;
				case MR_SET_GB:
					current_bitmap =(char*) GetgbBitmap(ch, font);
					if(!current_bitmap)
					{
						return MR_FAILED;
					}
					g_nowUse.fontWidth = *current_bitmap;
					g_nowUse.fontLen = *(current_bitmap+1);
					current_bitmap += 2;
					break;
				default:
					return MR_FAILED;
				}
			}
			if((chx - g_nowUse.fontWidth) < rect.x)
			{
				chy += (g_nowUse.fontHeight + INSERT_HEIGHT);
				chx = rect.x + rect.w;			
			}
			chx -= g_nowUse.fontWidth;
			if(( chx >= rect.x) && ((chy+g_nowUse.fontHeight) <= (rect.y + rect.h)) && (chy >= rect.y) && (chx >= 0) && (chy >= 0))
			{
				totalPoint = g_nowUse.fontHeight * g_nowUse.fontWidth;
				X1 = Y1 = 0;
				totalIndex = 0;
				for ( index_I = 0; index_I < g_nowUse.fontLen; index_I++)
				{
					temp = current_bitmap[index_I];
					for (index_J = 0; index_J < 8; index_J++)
					{
						totalIndex++;
						if (temp & 0x80)
						{
							*(screenBuf + (chy + Y1) * screen_Size.width + (chx + X1)) = color;
						}
						X1++;
						if(!g_nowUse.fontWidth)
							return MR_FAILED;
						if ((totalIndex % g_nowUse.fontWidth) == 0)
						{
							Y1++;
							X1= 0;
						}
						if (totalIndex >= totalPoint)
							break;
						temp = temp << 1;
					}

				}
			}
			chx = chx -INSERT_WIDHT;
sign:
			if(ch <0x80 && !flag)
			{
				p+=1;
			}
			else
			{
				p+=2;
			}   //���ݱ������� ����ƫ����         
			if(flag == MR_SET_UNICODE)
			{
				ch = (uint16) ((*p<<8)+*(p+1));
			}
			else if(flag == MR_SET_GB)
			{
				if((ch = *p)>0x80)
				{
					ch = ch <<8;
					ch += *(p+1);
				}
			}//����unicode/GB����ֵ
		};
	}

	return MR_SUCCESS;
}

int32 _textWidthHeightLine(char *pcText,int32 *width,int32 *height,int32 *lines,E_CHR_SET flag, uint16 font, int32 linewidth)
{
	uint16 chU;
	int32 tempCount = 0;
	uint8* tempChr = (uint8*)pcText;
	uint8 *bmpPoint = NULL;
	mrc_memset(&g_nowUse,0,sizeof(T_POINT_INFO));
	g_nowUse = GetSupportFont( font);

	if(!tempChr)
	{
		return MR_FAILED;
	}
	if(useSysFontInfo)
	{
		//	   		mrc_textWidthHeight(pcText, flag, font,width, height);
		mrc_unicodeTextWidthHeight((uint16*)pcText, font, width, height);
		return MR_SUCCESS;
	}//ȡƽ̨ϵͳ�ֿ���Ϣ

	*width = *height = *lines = 0;
	switch(flag)
	{
	case MR_SET_UNICODE:
		chU = (uint16) ((*tempChr<<8)+*(tempChr+1));
		break;
	case MR_SET_GB:
		chU = *tempChr;
		if(chU>0x80)
		{
			chU = (uint16) ((*tempChr<<8)+*(tempChr+1));
		}
		break;
	default:
		return MR_FAILED;
	}//��ȡGB��UNICODEֵ

	while(chU)
	{
		*height = g_nowUse.fontHeight;

		if(chU == 0x20)
		{
			*width += 8;
			tempCount += 8;
			if(tempCount > linewidth)
			{
				*lines += 1;
				tempCount = 8;
			}
			goto NEXT;
		}

		if(chU == 0xa || chU == 0xd)
		{
			*lines += 1;
			tempCount = 0;
			tempChr +=  2;
			goto sign;				
		}
		switch(flag)
		{
		case MR_SET_UNICODE:
			bmpPoint = (uint8*)GetUniBitmap(chU,  font);
			if(!bmpPoint)
			{
				return MR_FAILED;
			}
			break;

		case MR_SET_GB:
			bmpPoint = (uint8*)GetgbBitmap(chU, font);
			if(!bmpPoint)
			{
				return MR_FAILED;
			}
			break;

		default:
			return MR_FAILED;
		}
		
		*width += (*bmpPoint + INSERT_WIDHT);
		tempCount += (*bmpPoint + INSERT_WIDHT);
		
		if((tempCount- INSERT_WIDHT) > linewidth)
		{
			*lines += 1;
			tempCount = (*bmpPoint + INSERT_WIDHT);
		}
NEXT:
		if(chU < 0x80 && flag==MR_SET_GB)
		{
			tempChr += 1;
		}
		else
		{
			tempChr +=  2;
		}
		/*
		if(*tempChr == '\0')
		return MR_SUCCESS;
		*/
sign:
		switch(flag)
		{
		case MR_SET_UNICODE:
			chU = (uint16) ((*tempChr<<8)+*(tempChr+1));
			break;
		
		case MR_SET_GB:
			chU = *tempChr;
			if(chU>0x80)
			{
				chU = (uint16) ((*tempChr<<8)+*(tempChr+1));
			}
			break;
		
		default:
			return MR_FAILED;
		}//��ȡGB��UNICODEֵ
	}
	
	*height += INSERT_HEIGHT;
	*lines += 1;

	return MR_SUCCESS;
}

int32 _textWidthHeight(char *pcText,int32 *width,int32 *height,E_CHR_SET flag, uint16 font)
{
	uint16 chU;
	uint8* tempChr = (uint8*)pcText;
	uint8 *bmpPoint = NULL;
	mrc_memset(&g_nowUse,0,sizeof(T_POINT_INFO));

	g_nowUse = GetSupportFont( font);

	if(!tempChr)
	{
		return MR_FAILED;
	}
	if(useSysFontInfo)
	{
		//   		mrc_textWidthHeight(pcText, flag, font,width, height);
		mrc_unicodeTextWidthHeight((uint16*)pcText, font, width, height);
		return MR_SUCCESS;
	}//ȡƽ̨ϵͳ�ֿ���Ϣ

	*width = *height = 0;
	switch(flag)
	{
	case MR_SET_UNICODE:
		chU = (uint16) ((*tempChr<<8)+*(tempChr+1));
		break;
	case MR_SET_GB:
		chU = *tempChr;
		if(chU>0x80)
		{
			chU = (uint16) ((*tempChr<<8)+*(tempChr+1));
		}
		break;
	default:
		return MR_FAILED;
	}//��ȡGB��UNICODEֵ

	while(chU)
	{
		*height = g_nowUse.fontHeight;
		
		if(chU == 0x20)
		{
			*width += 8;
			goto NEXT;
		}

		switch(flag)
		{
		case MR_SET_UNICODE:
			bmpPoint = (uint8*)GetUniBitmap(chU,  font);
			if(!bmpPoint)
			{
				return MR_FAILED;
			}
			break;
		case MR_SET_GB:
			bmpPoint = (uint8*)GetgbBitmap(chU, font);
			if(!bmpPoint)
			{
				return MR_FAILED;
			}
			break;
		default:
			return MR_FAILED;
		}

		*width += (*bmpPoint + INSERT_WIDHT);

NEXT:
		if(chU < 0x80 && flag==MR_SET_GB)
		{
			tempChr += 1;
		}
		else
		{
			tempChr +=  2;
		}

		/*
		if(*tempChr == '\0')
		return MR_SUCCESS;
		*/

		switch(flag)
		{
		case MR_SET_UNICODE:
			chU = (uint16) ((*tempChr<<8)+*(tempChr+1));
			break;
		case MR_SET_GB:
			chU = *tempChr;
			if(chU>0x80)
			{
				chU = (uint16) ((*tempChr<<8)+*(tempChr+1));
			}
			break;
	
		default:
			return MR_FAILED;
		}//��ȡGB��UNICODEֵ
	}
	
	*height += INSERT_HEIGHT;
	
	return MR_SUCCESS;
}

static void Font_FontReset(T_POINT_INFO *t_font)
{
	if(t_font->uIndexBuf)
		mrc_freeFileData(t_font->uIndexBuf, t_font->uIndexLen);
	
	if(t_font->bIndexBuf)
		mrc_freeFileData(t_font->bIndexBuf, t_font->bIndexLen);
	
	if(t_font->PointBuf)
		mrc_freeFileData(t_font->PointBuf, t_font->PointLen);
	
	if(t_font->fontHandle && (!t_font->isMemBuf))
	{
		mrc_close(t_font->fontHandle);
		t_font->fontHandle = 0;
	}

	mrc_memset(t_font, 0, sizeof(T_POINT_INFO));
}

static void Font_FontRead(T_POINT_INFO *t_font, E_FONT_TYPE type, int32 isMemLoad, int32 gbsupport, int32 unsupport)
{
	char tmp[64] = {0};

	if(t_font->uIndexBuf)
		mrc_freeFileData(t_font->uIndexBuf, t_font->uIndexLen);
	if(t_font->bIndexBuf)
		mrc_freeFileData(t_font->bIndexBuf, t_font->bIndexLen);
	if(t_font->PointBuf)
		mrc_freeFileData(t_font->PointBuf, t_font->PointLen);
	
	if(unsupport)
	{
		mrc_sprintf(tmp, FONT_UINDEX, type);
		t_font->uIndexBuf = (uint8*)mrc_readFileFromMrp(tmp,&(t_font->uIndexLen),0);
	}
	
	if(gbsupport)
	{
		mrc_sprintf(tmp, FONT_GBINDEX, type);
		t_font->bIndexBuf = (uint8*)mrc_readFileFromMrp(tmp,&(t_font->bIndexLen),0);
	}
	
	if(isMemLoad)
	{
		mrc_sprintf(tmp, FONT_POINT, type);
		t_font->PointBuf= (uint8*)mrc_readFileFromMrp(tmp,&(t_font->PointLen),0);
		if(t_font->PointBuf)
		{
			t_font->isMemBuf = TRUE;
			t_font->fontHeight = *t_font->PointBuf;
		}
	}
	else
	{
		char path[128] = {0};
		uint8 * buf = NULL;
		int32 bufLen = 0;
	
		mrc_sprintf(tmp, FONT_POINT, type);
		mrc_GetMrpInfo(mrc_getPackName(),MRP_FILENAME,(uint8*)path,128);
		
		if(MR_IS_DIR !=mrc_fileState(path))
		{
			mrc_mkDir(path);
#if defined (__thumb)
			mrc_sleep(100);
#endif
		}//���ɴ洢·��

		mrc_strcat(path, "\\");
		mrc_strcat(path, tmp);
		if(MR_IS_FILE == mrc_fileState(path))
		{//�ļ��Ϸ��Լ��,������ڸ��ļ���ֱ�ӷ��سɹ�
			mrc_remove(path);
		}

		//��ȡ�ֿ����
		buf=(uint8*)mrc_readFileFromMrp(tmp, &bufLen, 0);
		if(buf)
		{
			t_font->fontHeight = *buf;	//ÿ���ֿ����128�ֽڣ���һ���ֽ����ַ��߶ȣ��ڶ����ֽ����ַ�����
			t_font->fontHandle = mrc_open(path,MR_FILE_CREATE|MR_FILE_WRONLY);
			
			if(t_font->fontHandle != 0)
			{
				mrc_write(t_font->fontHandle,buf,bufLen);
				mrc_close(t_font->fontHandle);
			}

			mrc_freeFileData(buf, bufLen);
			t_font->fontHandle = mrc_open(path,MR_FILE_RDONLY);
		}
	}

}

static int32 checkFontSupport(int32 checkType)
{
	int32 ret_big = MR_FAILED, ret_medium = MR_FAILED, ret_small = MR_FAILED;

	switch(checkType)
	{
	case 1:
		if(g_big.uIndexBuf)
			ret_big = MR_SUCCESS;
		if(g_medium.uIndexBuf)
			ret_medium = MR_SUCCESS;
		if(g_small.uIndexBuf)
			ret_small = MR_SUCCESS;
		break;
	case 2:
		if(g_big.bIndexBuf)
			ret_big = MR_SUCCESS;
		if(g_medium.bIndexBuf)
			ret_medium = MR_SUCCESS;
		if(g_small.bIndexBuf)
			ret_small = MR_SUCCESS;
		break;
	case 3://MEMLOAD
		if(g_big.PointBuf)
			ret_big = MR_SUCCESS;
		if(g_medium.PointBuf)
			ret_medium = MR_SUCCESS;
		if(g_small.PointBuf)
			ret_small = MR_SUCCESS;
		break;
	case 4://TCARD
		if(g_big.fontHandle)
			ret_big = MR_SUCCESS;
		if(g_medium.fontHandle)
			ret_medium = MR_SUCCESS;
		if(g_small.fontHandle)
			ret_small = MR_SUCCESS;
		break;
	default:
		break;
	}

	if(MR_SUCCESS == ret_big)
	{
		g_big.isSupport = TRUE;
	}
	else
	{
		Font_FontReset(&g_big);
	}

	if(MR_SUCCESS == ret_medium)
	{
		g_medium.isSupport = TRUE;
	}
	else
	{
		Font_FontReset(&g_medium);
	}

	if(MR_SUCCESS == ret_small)
	{
		g_small.isSupport = TRUE;
	}
	else
	{
		Font_FontReset(&g_small);
	}
}

int32 FontModuleInit(BOOL isUnicodeIndexSupport,BOOL isGBIndexSupport, BOOL isMemLoad)
{

	char path[100];
	char tempForHeight[1];

	mrc_getScreenInfo(&screen_Size);

	mrc_memset(&g_big,0,sizeof(T_POINT_INFO));
	mrc_memset(&g_medium,0,sizeof(T_POINT_INFO));
	mrc_memset(&g_small,0,sizeof(T_POINT_INFO));
	mrc_memset(&g_nowUse,0,sizeof(T_POINT_INFO));

	Font_FontRead(&g_big, FONT_TYPE_BIG, isMemLoad, isUnicodeIndexSupport, isGBIndexSupport);
	Font_FontRead(&g_medium, FONT_TYPE_MEDIUM, isMemLoad, isUnicodeIndexSupport, isGBIndexSupport);
	Font_FontRead(&g_small, FONT_TYPE_SAMLL, isMemLoad, isUnicodeIndexSupport, isGBIndexSupport);

	if(isUnicodeIndexSupport)
	{
		checkFontSupport(1);
	}

	if(isGBIndexSupport)
	{
		checkFontSupport(2);
	}

	if(isMemLoad)
	{
		checkFontSupport(3);
	}
	else
	{
		checkFontSupport(4);
	}

	if(!g_big.isSupport && !g_medium.isSupport && !g_small.isSupport)
	{
		useSysFontInfo = TRUE;
		FPRINTF("UseSysFont...");
	}

	return MR_SUCCESS;
}

void FontModuleRelease()
{
	mrc_printf("FontRelease B");

	Font_FontReset(&g_big);
	Font_FontReset(&g_medium);
	Font_FontReset(&g_small);

	mrc_printf("FontRelease E");
}