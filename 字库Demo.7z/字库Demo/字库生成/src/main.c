#include "mrc_base.h"
#include "i18n.h"
#include "res_str.h"
#include "game.h"


typedef struct fontInfo 
{
	char tag[6];
	int16 reva;
	int32 fileSize;

	int32 uIndexOff, uIndexLen;

	int32 pointOff, pointLen;

	int8 gbWidth, ascWidth, height, revb;

	uint8 name[20];		//�ֿ���
	uint8 vendor[20];	//����

	uint8 revc[56];
}T_FONTFILE_INFO;


int32 MRC_EXT_INIT(void)
{
	T_FONTFILE_INFO head = {0};
	int32 fd, fd2, off;

	strcpy(head.tag, "TSFONT");
	head.ascWidth = 8;
	head.gbWidth = 16;
	head.height = 16;
	strcpy(head.name, "����16");
	strcpy(head.vendor, "��ʹ֮��");

	head.pointLen = mrc_getLen("fpoint_2.bin");
	head.uIndexLen = mrc_getLen("fun_2.bin");

	head.fileSize = 128 + head.pointLen + head.uIndexLen;

	if(MR_IS_FILE == mrc_fileState("font16.tsf"))
		mrc_remove("font16.tsf");

	fd = mrc_open("font16.tsf", MR_FILE_CREATE|MR_FILE_RDWR);
	if (fd)
	{
		off = 128;
		mrc_seek(fd, off, MR_SEEK_SET);
		head.uIndexOff = off;
		
		fd2 = mrc_open("fun_2.bin", MR_FILE_RDONLY);
		if(fd2){
			uint8 *buf = malloc(head.uIndexLen);
			mrc_read(fd2, buf, head.uIndexLen);
			mrc_write(fd, buf, head.uIndexLen);
			mrc_free(buf);
			mrc_close(fd2);
			off += head.uIndexLen;
		}

		mrc_seek(fd, off, MR_SEEK_SET);
		head.pointOff = off;
		fd2 = mrc_open("fpoint_2.bin", MR_FILE_RDONLY);
		if (fd2)
		{
			uint8 *buf = malloc(head.pointLen);
			mrc_read(fd2, buf, head.pointLen);
			mrc_write(fd, buf, head.pointLen);
			mrc_free(buf);
			mrc_close(fd2);
			off += head.pointLen;
		}

		mrc_seek(fd, 0, MR_SEEK_SET);
		mrc_write(fd, &head, sizeof(T_FONTFILE_INFO));

		mrc_close(fd);
	}


	mrc_printf("size = %d", sizeof(T_FONTFILE_INFO));


	return MR_SUCCESS;
}

int32 MRC_EXT_EXIT(void)
{	
	Game_ReleaseSource();
	return MR_SUCCESS;
}

int32 mrc_appEvent(int32 code, int32 param0, int32 param1)
{//�Ʒ�״̬�£��Զ�����
	Game_KeyCheck(code, param0, param1);
	return MR_SUCCESS;
}

int32 mrc_appPause()
{//�Ʒ�״̬�£��Զ�����
	Game_Pause();
	return MR_SUCCESS;	
}

int32 mrc_appResume()
{
	Game_Resume();
	return MR_SUCCESS;
}
