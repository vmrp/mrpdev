#include "mrc_base.h"
#include "mrc_win.h"
#include "mrc_exb.h"


#define SCREEN_W    240
#define SCREEN_H    320
#define STR_OVER    "GAME OVER"

int32 timerH;
int32 mousemove = 0;
int32 value = 0, ball = 0;
int32 pass = 0;                        //��ǰ�ؿ���, ��ʼֵΪ 0
int32 speed = 100;                     //С�����е��ٶ�
int32 xPos = SCREEN_W / 2, yPos = 277; //С�����������
int32 x, y;                            //С��ÿ���ƶ��ľ���
int32 go_stop, start = 1;              //ǰ�������к���ͣ�ı�ʶ, �����ǵ�ǰ�Ľ�����
int32 Block_x = SCREEN_W / 2 - 25;     //ľ��� x ����
int32 move_x, move_x1;                 //ľ��ÿ������������ƶ��ľ���
int32 i = 0;                           //���ڽ���ڼ��еļ���,��ǰ��һ��
int32 score = 0;                       //��Ϸ��õķ���
int32 block[7] = {0};                  //ľ���Ƿ�С��ײ����, ��ʼֵΪ0
int32 r[7] = {0};                      //ÿ��ľ�����ԭɫ
int32 g[7] = {0};
int32 b[7] = {0};
int32 r1[12] = {0}; 
int32 g1[12] = {0};
int32 b1[12] = {0}; 
int32 border[3] = {SCREEN_H / 2 - 40, SCREEN_H / 2 - 20, SCREEN_H / 2};

//���ڴ�ŵ�һ��ש�����ɫ r g b 
void colour()
{
	int32 k;
	mrc_sand(mrc_getUptime());
	for(k = 0; k < 7; k++)
	{
		r[k] = mrc_rand() % 256;
	    g[k] = mrc_rand() % 256;
	    b[k] = mrc_rand() % 256;
	}
}

//���ڴ�ŵ�һ��ש�����ɫ r g b 
void colourNext()
{
	int32 k;
	mrc_sand(mrc_getUptime());
	for(k = 0; k < 12; k++)
	{
		r1[k] = mrc_rand() % 256;
	    g1[k] = mrc_rand() % 256;
	    b1[k] = mrc_rand() % 256;
	}

}

//��ʼ��С����˶������ƶ��ľ���
void xy_Distance()
{    
	int32 way = mrc_rand() % 2;
	mrc_sand(mrc_getUptime());

	if(way == 0)
        x = -(mrc_rand() % 5 + 1);
	else
        x = (mrc_rand() % 5 + 1);
    y = -1 * (mrc_rand() % 6 + 5);
}

//��Ϸ˳�����
void Finish()
{
	char buffer[10];
	pass++;

	mrc_clearScreen(255, 255, 255);
  
	mrc_drawText("Congratulations", SCREEN_W / 2- 60, SCREEN_H / 2 - 40, 0, 0, 0, 0, MR_FONT_BIG);
	mrc_drawText("You Have Completed", SCREEN_W / 2 - 60, SCREEN_H / 2 - 20, 0, 0, 0, 0, MR_FONT_BIG);
	mrc_drawText("SCORE:", SCREEN_W / 2 - 60, SCREEN_H / 2 + 5, 0, 0, 0, 0, MR_FONT_MEDIUM);

	if(pass == 1)
	{
		start = 5;
		mrc_drawText("Next", 5, SCREEN_H - 20, 0, 0, 0, 0, MR_FONT_SMALL);
	}
	else
		if(pass == 2)
			start = 6;
	
	mrc_sprintf(buffer,"%d", score);
	mrc_drawText(buffer, SCREEN_W / 2, SCREEN_H / 2 + 5, 0, 0, 0, 0, MR_FONT_MEDIUM);
	mrc_drawText("Back", SCREEN_W - 40, SCREEN_H - 20, 0, 0, 0, 0, MR_FONT_SMALL);

	mrc_refreshScreen(0, 0, SCREEN_W, SCREEN_H);
}

//��Ϸ����
void Over()
{
	int32 w, h;
	char buffer[10];

	start = 4;
	mrc_unicodeTextWidthHeight((uint16*)STR_OVER, MR_FONT_BIG, &w, &h);  

        mrc_clearScreen(255, 255, 255);
        mrc_drawText("GAME OVER", (SCREEN_W - w) / 2, (SCREEN_H - h) / 2 - 10, 0, 0, 0, 0, MR_FONT_BIG);
	mrc_drawText("SCORE:", (SCREEN_W - w) / 2, (SCREEN_H - h) / 2 + 5, 0, 0, 0, 0, MR_FONT_MEDIUM);

	mrc_sprintf(buffer,"%d", score);
	mrc_drawText(buffer, (SCREEN_W - w) / 2 + 60, (SCREEN_H - h) / 2 + 5, 0, 0, 0, 0, MR_FONT_MEDIUM);
	mrc_drawText("Back", SCREEN_W - 40, SCREEN_H - 20, 0, 0, 0, 0, MR_FONT_SMALL);

	mrc_refreshScreen(0, 0, SCREEN_W, SCREEN_H);
}

//��С��
void DrawBall()
{
	int32 k;
	int32 x1, y1;

	for(x1 = xPos - 7; x1 <= xPos + 7; x1++)
		for(y1 = yPos - 7; y1 <= yPos + 7; y1++)
		{
			if((x1 - xPos) * (x1 - xPos) + (y1 - yPos) * (y1 - yPos) <= 49)
	            mrc_drawPointEx((int16)x1, (int16)y1, 255, 106, 255);
		}
	if(value == 1)
	{
		xy_Distance();
		value = 0;
	}

	xPos += x;
    yPos += y;

	//�ж�С��ķ���仯
	if((xPos + x) <= 2 || xPos <= 2 || xPos >= 230)
        x = -x;                                                                                               
    if((yPos + y) <= 54 || yPos <= 54)
        y = -y;
	if(yPos >= 285 && yPos <= 290 && xPos >= Block_x && xPos <= Block_x + 50)
		y = -y;

	//��һ���ж�С��ײ��ש��ķ���
	if(pass == 0)
	{
	    for(k = 1; k <= 7; k++)
	    {
		    if(xPos >= SCREEN_W / 2 - 64 + 18 * (k - 1) && xPos <= SCREEN_W / 2 - 48 + 18 * (k - 1) && 
		       yPos >= 200 - 18 * (k - 1) + 16 - 2 && yPos <= 200 - 18 * (k - 1) + 16 + 2 && block[k - 1] == 0)
		    {
			    y = -y;
			    block[k - 1] = 1;
			    score += 10;
		    }

		    if(xPos >= SCREEN_W / 2 - 64 + 18 * (k - 1) && xPos <= SCREEN_W / 2 - 48 + 18 * (k - 1) && 
		       yPos >= 200 - 18 * (k - 1) - 2 && yPos <= 200 - 18 * (k - 1) + 2 && block[k - 1] == 0)
		    {
			    y = -y;
			    block[k - 1] = 1;
			    score += 10;
		    }

		    if(xPos >= SCREEN_W / 2 - 64 + 18 * (k - 1) - 2 && xPos <= SCREEN_W / 2 - 64 + 18 * (k - 1) + 2 && 
		       yPos >= 200 - 18 * (k - 1) && yPos <= 200 - 18 * (k - 1) + 16 && block[k - 1] == 0)
		    {
			    x = -x;
			    block[k - 1] = 1;
			    score += 10;
		    }

		    if(xPos >= SCREEN_W / 2 - 48 + 18 * (k - 1) - 2 && xPos <= SCREEN_W / 2 - 48 + 18 * (k - 1) + 2 && 
		       yPos >= 200 - 18 * (k - 1) && yPos <= 200 - 18 * (k - 1) + 16 && block[k - 1] == 0)
		    {
			    x = -x;
			    block[k - 1] = 1;
			    score += 10;
		    }    
	    }
	}

	//δ��ľ���סС��ʱ, ���� Over ����
	if((yPos) > 290)
	{
		Over();
		mrc_timerStop(timerH);
	}
	//������װ�鶼��С��ײ�������������
	else
		if(score == 70)
		{
		    Finish();
			mrc_timerStop(timerH);
		}
}

//ʱ�䶨ʱ������
void TimerCB(int32 data)
{
	int32 i, j, m = 0;
	char buffer[10];

	mrc_clearScreen(255, 255, 255);

	//�����������
	mrc_drawRect(0, 0, SCREEN_W / 2, 50, 125, 70, 125);
	mrc_drawText("NAME:", 10, 15, 0, 0, 0, 0, MR_FONT_MEDIUM);
	mrc_drawText("Player1", 55, 15, 0, 0, 0, 0,MR_FONT_MEDIUM);
	//��Ϸ��Ļ�Ͻ�
	mrc_drawLine(0, 50, SCREEN_W, 50, 0, 0, 0);             

	//��ҵ÷�����
	mrc_drawRect(SCREEN_W / 2, 0, SCREEN_W / 2, 50, 125, 125, 125);
	mrc_drawText("SCORE:", SCREEN_W / 2 + 10, 15, 0, 0, 0, 0, MR_FONT_MEDIUM);

	mrc_sprintf(buffer,"%d", score);
	mrc_drawText(buffer, SCREEN_W / 2 + 70, 15, 0, 0, 0, 0, MR_FONT_MEDIUM);

	//����
	mrc_drawRect(Block_x, 290, 50, 10, 100, 100, 100);
	//��Ϸ��Ļ�½�
	mrc_drawLine(0, 300, SCREEN_W, 300, 200, 40 ,200);
    
	mrc_drawRect(0, 300, SCREEN_W, 20, 200, 100, 100);

	if(go_stop == 1)
	{
		mrc_drawRect(0, 300, 30, 20, 200, 200, 200);
	    mrc_drawText("Go", 5, 303, 0, 0, 0, 0, MR_FONT_SMALL);

		mrc_timerStop(timerH);
	}
	else
	{
		mrc_drawRect(0, 300, 40, 20, 200, 200, 200);
		mrc_drawText("Stop", 5, 303, 0, 0, 0, 0, MR_FONT_SMALL);

		mrc_timerStart(timerH, 100, speed, TimerCB, 0);
	}
	mrc_drawText("@DING YOU", SCREEN_W / 2 - 40, 303, 0, 0, 0, 0, MR_FONT_SMALL);
	mrc_drawRect(200, 300, 40, 20, 200, 200, 200);
	mrc_drawText("Back", 202, 303, 0, 0, 0, 0, MR_FONT_SMALL);
	
	//��ש��, ��һ��
	if(pass == 0)
	{
	    for(i = 1; i <= 7; i++)
	    {
		    if(r[m] <= 250 && g[m] <= 250 && b[m] <= 250)
		    {
			    if(block[i - 1] == 0)
                    mrc_drawRect(SCREEN_W / 2 - 64 + 18 * (i - 1), 200 - 18 * (i - 1), 16, 16, r[m], g[m], b[m]);
			    else
				    mrc_drawRect(SCREEN_W / 2 - 64 + 18 * (i - 1), 200 - 18 * (i - 1), 16, 16, 255, 255, 255);
		    }
		    else
		    {
			    if(block[i - 1] == 0)
		            mrc_drawRect(SCREEN_W / 2 - 64 + 18 * (i - 1), 200 - 18 * (i - 1), 16, 16, 0, 0, 0);
			    else
				    mrc_drawRect(SCREEN_W / 2 - 64 + 18 * (i - 1), 200 - 18 * (i - 1), 16, 16, 255, 255, 255);
		    }
			m++;
	    }
	}
	//�ڶ��ص�ש��
	else
		if(pass == 1)
	    {
			for(j = 1; j <= 3; j++)
			{
				if(r1[m] <= 250 && g1[m] <= 250 && b1[m] <= 250)
                    mrc_drawRect(SCREEN_W / 2 - 109 + 18 * (j - 1), 204 - 18 * (j - 1), 16, 16, r1[m], g1[m], b1[m]);
			    else
				    mrc_drawRect(SCREEN_W / 2 - 109 + 18 * (j - 1), 204 - 18 * (j - 1), 16, 16, 0, 0, 0);
			    m++;
			}
			for(j = 1; j <= 3; j++)
			{
				if(r1[m] <= 250 && g1[m] <= 250 && b1[m] <= 250)
                    mrc_drawRect(SCREEN_W / 2 + 54 + 18 * (j - 1), 132 - 18 * (j - 1), 16, 16, r1[m], g1[m], b1[m]);
			    else
				    mrc_drawRect(SCREEN_W / 2 + 54 + 18 * (j - 1), 132 - 18 * (j - 1), 16, 16, 0, 0, 0);
			    m++;
			}
	        for(i = 1; i <= 6; i++)
		    {         
			    if(r1[m] <= 250 && g1[m] <= 250 && b1[m] <= 250)
                    mrc_drawRect(SCREEN_W / 2 - 54 + 18 * (i - 1), 150, 16, 16, r1[m], g1[m], b1[m]);
			    else
				    mrc_drawRect(SCREEN_W / 2 - 54 + 18 * (i - 1), 150, 16, 16, 0, 0, 0);
			    m++;
		    }
	    }

	//���µĵ���
	if(mousemove)
	{
		mrc_drawRect(Block_x, 290, 240, 10, 255, 255, 255);

		if(Block_x >= 5)
	        Block_x += move_x;
		if(Block_x <= 185)
			Block_x += move_x1;

	    mrc_drawRect(Block_x, 290, 50, 10, 100, 100, 100);
	}
	
	DrawBall();

	mrc_refreshScreen(0, 0, SCREEN_W, SCREEN_H);
}

//��Ϸ������Ϣ
void Help()
{  
	start = 2;
	mrc_clearScreen(158, 190, 226);

	mrc_drawText("Game Help", SCREEN_W / 2 - 40, SCREEN_H / 2 - 20, 0, 0, 0, 0, MR_FONT_BIG);
	mrc_drawText("Informations...", SCREEN_W / 2 - 41, SCREEN_H / 2, 0, 0, 0, 0, MR_FONT_BIG);
	mrc_drawText("Back", SCREEN_W - 40, SCREEN_H - 20, 0, 0, 0, 0, MR_FONT_SMALL);
	mrc_refreshScreen(0, 0, SCREEN_W, SCREEN_H);
}

//������Ϸ����Ϣ
void About()
{
	start = 3;
	mrc_clearScreen(158, 190, 226);

	mrc_drawText("The Description", SCREEN_W / 2 - 50, SCREEN_H / 2 - 20, 0, 0, 0, 0, MR_FONT_BIG);
	mrc_drawText("Of The Game...", SCREEN_W / 2 - 40, SCREEN_H / 2, 0, 0, 0, 0, MR_FONT_BIG);
	mrc_drawText("Back", SCREEN_W - 40, SCREEN_H - 20, 0, 0, 0, 0, MR_FONT_SMALL);
	mrc_refreshScreen(0, 0, SCREEN_W, SCREEN_H);
}

//��Ϸ��ʼ����
void Starting()
{
	int s;

	//���½��뿪ʼ����ʱ, ��ȫ�ֱ�����ʼ��ԭ����ֵ
	xPos = SCREEN_W / 2, yPos = 277;
	x = 0, y = 0;
	value = 0;
	ball = 0;
	Block_x = SCREEN_W / 2 - 25;
	score = 0;
	for(s = 0; s < 7; s++)
	{
		r[s] = 0;
		g[s] = 0;
		b[s] = 0;
        block[s] = 0;
	}

	start = 0;

	if(pass == 0)
	    colour();
	else
		if(pass == 1)
			colourNext();
	timerH = 0;
	timerH = mrc_timerCreate();

    if(timerH)
	{
		go_stop = 1;
		mrc_timerStart(timerH, 100, speed, TimerCB, 1);
	}
}

//��ʼ���溯��
void Start()
{
	//��ʼ���ؿ����ͷ���
	pass = 0;
	start = 1;

	mrc_clearScreen(158, 190, 226);
	mrc_drawRect(SCREEN_W / 2 - 50, border[i],  110, 15, 216, 169, 194);
	mrc_drawText("1. START GAME", SCREEN_W / 2 - 50, border[0], 0, 0, 0, 0, MR_FONT_BIG);
	mrc_drawText("2. HELP    ME", SCREEN_W / 2 - 50, border[1], 0, 0, 0, 0, MR_FONT_BIG);
	mrc_drawText("3. ABOUT GAME", SCREEN_W / 2 - 50, border[2], 0, 0, 0, 0, MR_FONT_BIG);
	mrc_drawText(" Select", 0, SCREEN_H - 20, 0, 0, 0, 0, MR_FONT_SMALL);
	mrc_drawText("Exit", SCREEN_W - 40, SCREEN_H - 20, 0, 0, 0, 0, MR_FONT_SMALL);
	mrc_refreshScreen(0, 0, SCREEN_W, SCREEN_H);
}
int32 mrc_init(void)
{
	//��һ���뿪ʼ���溯��
	Start();

	return MR_SUCCESS;
}

//�¼���������
int32 mrc_appEvent(int32 code, int32 param0, int32 param1)
{
	switch(code)
	{
		//������¼�, С��ʼ�˶�
		//�������������ĵ�ǰλ��
		case MR_MOUSE_DOWN:

			//�����¼�, ���� GO ʱ����, STOPʱ��ͣ
			if(param0 >= 0 && param0 <= 30 && param1 >= 300 && param1 <= 320 )
			{
				if(go_stop == 0)
				    go_stop = 1;
				else	
				{
					mrc_timerStart(timerH, 100, speed, TimerCB, 1);
					go_stop = 0;	
				}
			}
			if(param0 >= 0 && param0 <= 30 && param1 >= 300 && param1 <= 320 && ball == 0)
			{
                value = 1;
				ball = 1;
			}
			
			//��������ƶ����嵽�����λ��
		    if(param0 >= 0 && param0 <= 240 && param1 >= 240 && param1 <= 300)
			{
		        mousemove = 1;
				if(param0 >= 190)
					Block_x = 190;
				else
			        Block_x = param0;
			}
            break;

		//�����¼�, �������������ƶ�����
		case MR_KEY_PRESS:
            switch(param0)
            {
				//�����ƶ�����
			    case MR_KEY_LEFT:
				{
					mousemove = 1;
					move_x = -5;
					break;
				} 
				//�����ƶ�����
				case MR_KEY_RIGHT:
				{
					mousemove = 1;
					move_x1 = 5;
					break;
				}
				//ѡ��ǰ�Ĳ���
                case MR_KEY_SELECT:
				{
					//���������Ϸ����
					if(i == 2 && start == 1)
					{
						About();
						start = 3;
						break;
					}
					//���������Ϣ����
					if(i == 1 && start == 1)
					{
						Help();
						start = 2;
						break;
					}
					//������Ϸ����
					if(i == 0 && start == 1)
					{
						Starting();
						start = 0;
					}
					break;
				}

				//�������¼�����
				case MR_KEY_SOFTLEFT:
				{
					//������ڹ���Ϸ����
					if(i == 2 && start == 1)
					{
						About();
						start = 3;
						break;
					}
					//������ڵڶ�����Ϸ����
					if(i == 0 && start == 5 && pass == 1)
					{
						mrc_timerStop(timerH);
						Starting();
						break;
					}
					//���������Ϣ����
					if(i == 1 && start == 1)
					{
						Help();
						start = 2;
						break;
					}
					//�����һ����Ϸ����
					if(i == 0 && start == 1)
					{
						Starting();
						start = 0;
						break;
					}

					//��ͣ�������¼�����
					if(go_stop == 0)
					{
				        go_stop = 1;
					}
				    else 
					{
						mrc_timerStart(timerH, 100, speed, TimerCB, 1);
					    go_stop = 0;
					}

					if(ball == 0)
			        {
                        value = 1;
				        ball = 1;
			        }
					break;
				}

				//�������¼�����
				case MR_KEY_SOFTRIGHT:
				{
					if(i == 0 && start == 6)
					{
						mrc_timerStop(timerH);
						Start();
						start = 1;
						break;
					}
					//����ɽ������Ҽ����ؿ�ʼ����
					if(i == 0 && start == 5)
					{
						mrc_timerStop(timerH);
						Start();
						start = 1;
						break;
					}
					//����Ϸ�������Ҽ����ؿ�ʼ����
					if(i == 0 && start == 4)
					{
						mrc_timerStop(timerH);
						Start();
						start = 1;
						break;
					}
					//����Ϸ�������Ҽ����ؿ�ʼ����
					if(i == 0 && start == 0)
					{
						mrc_timerStop(timerH);
						Start();
						start = 1;
						break;
					}
					//�ڹ�����Ϸ�������Ҽ����ؿ�ʼ����
					if(i == 2 && start == 3)
					{
						Start();
						start = 1;
						break;
					}
					//�ڰ�����Ϣ�������Ҽ����ؿ�ʼ����
					if(i == 1 && start == 2)
					{
						Start();
						start = 1;
						break;
					}
					if(start == 1)
					{
					    mrc_exit();
						break;
					}
				}

				//���·���ѡ��
				case MR_KEY_DOWN:
				{
					if(i <= 2 && start == 1)
					{
						i++;
						if(i == 1)
						{
							 mrc_drawRect(SCREEN_W / 2 - 50, border[i - 1],  110, 15, 158, 190, 226);
                             mrc_drawText("1. START GAME", SCREEN_W / 2 - 50, border[i - 1], 0, 0, 0, 0, MR_FONT_BIG);
							 mrc_drawRect(SCREEN_W / 2 - 50, border[i],  110, 15, 216, 169, 194);
	                         mrc_drawText("2. HELP    ME", SCREEN_W / 2 - 50, border[i], 0, 0, 0, 0, MR_FONT_BIG);

							 mrc_refreshScreen(0, 0, SCREEN_W, SCREEN_H);
						}
						else
							if(i == 2)
						    {
							    mrc_drawRect(SCREEN_W / 2 - 50, border[i - 1],  110, 15, 158, 190, 226); 
							    mrc_drawText("2. HELP    ME", SCREEN_W / 2 - 50, border[i - 1], 0, 0, 0, 0, MR_FONT_BIG);
							    mrc_drawRect(SCREEN_W / 2 - 50, border[i],  110, 15, 216, 169, 194);
	                            mrc_drawText("3. ABOUT GAME", SCREEN_W / 2 - 50, border[i], 0, 0, 0, 0, MR_FONT_BIG);

							    mrc_refreshScreen(0, 0, SCREEN_W, SCREEN_H);
						    }
					    else      
					    {
						    i = 0;
					        mrc_drawRect(SCREEN_W / 2 - 50, border[i + 2],  110, 15, 158, 190, 226); 
						    mrc_drawText("3. ABOUT GAME", SCREEN_W / 2 - 50, border[i + 2], 0, 0, 0, 0, MR_FONT_BIG);
						    mrc_drawRect(SCREEN_W / 2 - 50, border[i],  110, 15, 216, 169, 194);
						    mrc_drawText("1. START GAME", SCREEN_W / 2 - 50, border[i], 0, 0, 0, 0, MR_FONT_BIG);							          

					  	    mrc_refreshScreen(0, 0, SCREEN_W, SCREEN_H);
					   }
					}
					break;
				}

				//���Ϸ���ѡ��
				case MR_KEY_UP:
				{
					if(i >= 0 && start == 1)
					{
						i--;
						if(i == 0)
						{
							mrc_drawRect(SCREEN_W / 2 - 50, border[i + 1],  110, 15, 158, 190, 226);
                            mrc_drawText("2. HELP    ME", SCREEN_W / 2 - 50, border[i + 1], 0, 0, 0, 0, MR_FONT_BIG);
							mrc_drawRect(SCREEN_W / 2 - 50, border[i],  110, 15, 216, 169, 194);
							mrc_drawText("1. START GAME", SCREEN_W / 2 - 50, border[i], 0, 0, 0, 0, MR_FONT_BIG);							          

							mrc_refreshScreen(0, 0, SCREEN_W, SCREEN_H);
						}
						else
							if(i == 1)
						    {
							    mrc_drawRect(SCREEN_W / 2 - 50, border[i + 1],  110, 15, 158, 190, 226); 
							    mrc_drawText("3. ABOUT GAME", SCREEN_W / 2 - 50, border[i + 1], 0, 0, 0, 0, MR_FONT_BIG);
							    mrc_drawRect(SCREEN_W / 2 - 50, border[1],  110, 15, 216, 169, 194);
							    mrc_drawText("2. HELP    ME", SCREEN_W / 2 - 50, border[i], 0, 0, 0, 0, MR_FONT_BIG);
							
							    mrc_refreshScreen(0, 0, SCREEN_W, SCREEN_H);
						    }
						else
						{
							i = 2;
							mrc_drawRect(SCREEN_W / 2 - 50, border[i - 2],  110, 15, 158, 190, 226); 
							mrc_drawText("1. START GAME", SCREEN_W / 2 - 50, border[i - 2], 0, 0, 0, 0, MR_FONT_BIG);
						    mrc_drawRect(SCREEN_W / 2 - 50, border[i],  110, 15, 216, 169, 194);
							mrc_drawText("3. ABOUT GAME", SCREEN_W / 2 - 50, border[i], 0, 0, 0, 0, MR_FONT_BIG);
						    							          

					  	    mrc_refreshScreen(0, 0, SCREEN_W, SCREEN_H);

						}
					}
					break;
				}
				
			}
			break;

		//�ƶ������¼�, ������ס����ʱ����һֱ���һ������ƶ�, �ɿ�ʱֹͣ�ƶ�
		case MR_KEY_RELEASE:
			switch(param0)
            {
			    case MR_KEY_LEFT:
				{
					move_x = 0;
					break;
				} 
				case MR_KEY_RIGHT:
				{
					move_x1 = 0;
					break;
				}
			} 
			break;

	    default:
			break;

	}
	return MR_SUCCESS;
}

int32 mrc_pause(void)
{
    return MR_SUCCESS;  
}

int32 mrc_resume(void)
{
	return MR_SUCCESS;  
}

int32 mrc_exitApp(void)
{
	if(timerH)
	{
		mrc_timerDelete(timerH);
		timerH = 0;
	}
    return MR_SUCCESS;
} 