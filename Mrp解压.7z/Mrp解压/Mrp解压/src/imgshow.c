#include "imgshow.h"
#include "topwnd.h"

#include "mrc_bmp.h"
#include "mrc_image.h"

/* SGL�ؼ� */
#include "smp.h"
#include "i18n.h"
#include "smp_titlebar.h"
#include "smp_toolbar.h"
#include "smp_button.h"
#include "smp_msgbox.h"
#include "smp_textinfo.h"
#include "smp_label.h"
#include "string.h"

#define WND2_H  26  //��ť���ڴ��ڵĸ߶�
#define BTN_W 10 
#define BTN_H 5

//����ID
enum Imig_Wid
{
	WID_TOOLBAR = 1,
	WID_BTN1, WID_BTN2, WID_BTN3, WID_BTN4, WID_BTN5, WID_BTN6,
	WID_IMIGDRAW,
	WID_LABEL
};

typedef struct WinData
{
	char imigname[64];
	uint16* pimgbuf;
	int32 buflen;
}WINDATA, *PWINDATA;

typedef struct ImgData
{
	int16 x, y, w, h;
	uint16 rope;
}IMIGDATA;

typedef struct BmpSize
{
	int16 width[50];   //�洢Ԥ�ÿ���
	int16 curw;
}BMPSIZE;

//����
IMIGDATA imginfo;  //����ʾͼƬ��Ϣ
RECT ImgRect;      //��ʾͼƬ�ľ��ο�
BMPSIZE bmp;
static uint32 BgClr;
static HWND hText ;
static HWND hLabel ;
UnicodeSt unicode;
static UCHAR caption[100];

//��ʾbmpͼƬ
int32 Drawimg_Bmp(uint16 *bmpbuf, int32 buflen, int16 x, int16 y, int16 w, uint16 rope);

VOID ShowImage(PIMGFILEDATA image)
{
	HideTopWindow(TOPWND_EXTRACT, 0, 0);
	ShowTopWindow(TOPWND_IMIGSHOW, 0, (DWORD)image);
}

VOID HideImgWnd(VOID)
{
	HideTopWindow(TOPWND_IMIGSHOW, 0, 0);
	ShowTopWindow(TOPWND_EXTRACT, 0, 1001);
}

LRESULT ImigShow_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	PWINDATA pData = _GET_WINDATA(hWnd, PWINDATA);
	HWND hControl;// hContent;

	switch(Msg)
	{
	case WM_CREATE:
		{
			pData = SGL_MALLOC(sizeof(WINDATA));
			if(!pData){
				SGL_TRACE("%s, %d: memory out\n", __FILE__, __LINE__);
				return 1;
			}
			SGL_MEMSET(pData, 0, sizeof(WINDATA));
			_SET_WINDATA(hWnd, pData);
			SGL_MEMSET(&imginfo, 0, sizeof(IMIGDATA));

			ImgRect.left=0, ImgRect.top=0, ImgRect.width = SCREEN_WIDTH, ImgRect.height = SCREEN_HEIGHT - SMP_TOOLBAR_HEIGHT - WND2_H;

			////��������
			//hContent = SGL_CreateWindow(SGL_Window_WndProc, 
			//	0,  ImgRect.height, _WIDTH(hWnd), WND2_H,
			//	0, 0, 0);

			//hControl = SGL_CreateWindow(SMP_Button_WndProc, 
			//	50,  280, BTN_W, BTN_H,
			//	WID_BTN1, 0, 0);
			//_FGCOLOR(hControl) = COLOR_user3;
			//SMP_Button_SetTitle(hControl, SGL_LoadString(STR_OK));
			//SGL_AddChildWindow(hContent, hControl);

			//hControl = SGL_CreateWindow(SMP_Button_WndProc, 
			//	70,  ImgRect.height+1, BTN_W, BTN_H,
			//	WID_BTN2, 0, 0);
			//SMP_Button_SetTitle(hControl, SGL_LoadString(STR_OK));
			//SGL_AddChildWindow(hContent, hControl);

			//SGL_AddChildWindow(hWnd, hContent);

			hText = SGL_CreateWindow(SMP_TextInfo_WndProc, 
				0,  0, _WIDTH(hWnd), _HEIGHT(hWnd)-SMP_TOOLBAR_HEIGHT,
				0, SMP_TEXTINFOS_HASBOARD|WS_TABSTOP|SMP_TEXTINFOS_NOSCRBAR, 0);
			SMP_TextInfo_SetContent(hText, SGL_LoadString(STR_HELP_IMG));

			hLabel = SGL_CreateWindow(SMP_Label_WndProc, 
				0,  SCREEN_HEIGHT - SMP_TOOLBAR_HEIGHT - WND2_H, _WIDTH(hWnd), WND2_H,
				WID_LABEL, SMP_LABELS_AUTOSCROLL|SMP_LABELS_STATIC, 0);
			wstrcpy(caption, (PCWSTR)"\x56\xfe\x72\x47\x4f\xe1\x60\x6f\xff\x1a\x5b\xbd\x5e\xa6\x0\x20\x0\x3d\x0\x20\x0\x57\x0\x2c\x0\x20\x9a\xd8\x5e\xa6\x0\x20\x0\x3d\x0\x20\x0\x48\x0\x2c\x0\x20\x6a\x2a\x57\x50\x68\x7\x0\x20\x0\x3d\x0\x20\x0\x58\x0\x2c\x0\x20\x7e\xb5\x57\x50\x68\x7\x0\x20\x0\x3d\x0\x20\x0\x59\x0\x2e\x0\xa");
			SMP_Label_SetContent(hLabel, RESID_INVALID, caption, 500);
			_BGCOLOR(hLabel) = COLOR_lightwhite;
			_FGCOLOR(hLabel) = COLOR_black;
			SGL_AddChildWindow(hWnd, hLabel);
			
			//����������
			hControl = SGL_CreateWindow(SMP_Toolbar_WndProc, 
				0,  _HEIGHT(hWnd) - SMP_TOOLBAR_HEIGHT, _WIDTH(hWnd), SMP_TOOLBAR_HEIGHT,
				WID_TOOLBAR, 0, 0);
			_FGCOLOR(hControl) = COLOR_lightwhite;
			SMP_Toolbar_SetStrings(hControl,  STR_HELP , RESID_INVALID, STR_BACK, TRUE);
			SGL_AddChildWindow(hWnd, hControl);
			
			BgClr = COLOR_lightwhite;
			_BGCOLOR(hWnd) = BgClr;
			break;
		}

	case WM_DESTROY:
		if(pData)
			SGL_FREE(pData);
		break;

	case WM_SHOW:
		{
			int32 ret = MR_FAILED;
			PIMGFILEDATA image;
			int size, w, h, i, j;
			size = w = h = i = j = 0;

			image = _GET_USERDATA(hWnd, PIMGFILEDATA);

			if(pData->pimgbuf)
			{
				mrc_freeFileData(pData->pimgbuf, pData->buflen);
				pData->pimgbuf = NULL;
				pData->buflen = 0;
			}else
			{
				pData->pimgbuf = NULL;
				pData->buflen = 0;
			}

			ret = mrc_readFileFromMrpExA(image->packname, image->filename, (uint8**)&pData->pimgbuf, &pData->buflen, 3);
			imginfo.w = 0, imginfo.x = 3, imginfo.y = 3, imginfo.rope = BM_COPY;
			//�����
			size = pData->buflen/2;
			mrc_memset(&bmp, 0, sizeof(BMPSIZE));
			for(i=4; i<=(size/4); i++)
			{
				if(size%i == 0)
				{
					if(j<50)
						bmp.width[j++] = (int16)i;
					if(i*i == size)
					{
						imginfo.w = i;
						bmp.curw = j;
					}
				}
			}
			if(imginfo.w == 0 && bmp.width[0] != 0)
			{
				imginfo.w = bmp.width[0];
				bmp.curw = 0;
			}else if(imginfo.w == 0 && bmp.width[0] == 0)
				imginfo.w = 2;
			_BGCOLOR(hWnd) = BgClr;
		}
		break;

	case WM_HIDE:
		if(pData->pimgbuf)
		{
			mrc_freeFileData(pData->pimgbuf, pData->buflen);
			pData->pimgbuf = NULL;
			pData->buflen = 0;
		}
		break;

	case WM_KEYDOWN:
	case WM_KEYDOWNREPEAT:
		{
			switch(wParam)
			{
			case MR_KEY_UP:  //ͼ������
				//if(imginfo.y >= 2)
					imginfo.y -= 5;
				SGL_UpdateWindow(hWnd);
				return 1;

			case MR_KEY_DOWN: //ͼ������
				if(imginfo.y <= ImgRect.height - 3)
					imginfo.y += 5;
				SGL_UpdateWindow(hWnd);
				return 1;

			case MR_KEY_LEFT: //ͼ������
				if(imginfo.x >= ImgRect.left-imginfo.w+3)
					imginfo.x -= 5;
				SGL_UpdateWindow(hWnd);
				return 1;

			case MR_KEY_RIGHT: //ͼ������
				if(imginfo.x <= ImgRect.left+ImgRect.width-3)
				imginfo.x += 5;
				SGL_UpdateWindow(hWnd);
				return 1;

			case MR_KEY_1:  // BMP���ȴֵ�(+)
				if(bmp.curw < 50 && bmp.width[bmp.curw+1] != 0)
					imginfo.w = bmp.width[++bmp.curw];
				SGL_UpdateWindow(hWnd);
				return 1;

			case MR_KEY_2: // BMP���ȴֵ�(-)
				if(bmp.curw >0 )
					imginfo.w = bmp.width[--bmp.curw];
				SGL_UpdateWindow(hWnd);
				return 1;

			case MR_KEY_4: // BMP���ȼ�1
				if(imginfo.h > 0)
					imginfo.w += 1;
				SGL_UpdateWindow(hWnd);
				return 1;

			case MR_KEY_5: // BMP���ȼ�1
				if(imginfo.w > 2)
					imginfo.w -= 1;
				SGL_UpdateWindow(hWnd);
				return 1;

			case MR_KEY_6: // �л�����
				if(_BGCOLOR(hWnd) == COLOR_lightwhite)
					_BGCOLOR(hWnd) = COLOR_Listface;
				else
					_BGCOLOR(hWnd) = COLOR_lightwhite;
				BgClr = _BGCOLOR(hWnd);
				SGL_UpdateWindow(hWnd);
				return 1;

			case MR_KEY_8: // BMP���ȼ�4
				SGL_UpdateWindow(hWnd);
				return 1;

			case MR_KEY_3: // �л�Ч��
				if(imginfo.rope == BM_COPY)
					imginfo.rope = BM_TRANSPARENT;
				else
					imginfo.rope = BM_COPY;
				SGL_UpdateWindow(hWnd);
				return 1;
			}
		}
		break;

	case WM_KEYUP:
		{
			switch(wParam)
			{
			case MR_KEY_SOFTRIGHT:
				if( SGL_IsWindowVisible(hText))
					SGL_RemoveChildWindow(hText);
				else
					HideImgWnd();
				return 1;

			case MR_KEY_SOFTLEFT:
				if( SGL_IsWindowVisible(hText))
					SGL_RemoveChildWindow(hText);
				else
				{
					SGL_AddChildWindow(hWnd, hText);
					SGL_SetFocusWindow(hWnd, hText);
				}
				return 1;
			}
		}
		break;	

	case WM_PAINT:
		{
			HWND hLabel;
			char buf[100] = {0};
			mrc_sprintf(buf, "ͼ��: %d ͼ��: %d ����: X=%d Y=%d", imginfo.w, imginfo.h, imginfo.x, imginfo.y);
			CharToUnicode2(buf, &unicode.pText, &unicode.len);
			wstrcpy(caption, (PCWSTR)unicode.pText);
			mrc_freeOrigin(unicode.pText, unicode.len);
			hLabel = SGL_FindChildWindow(hWnd, WID_LABEL);
			SMP_Label_SetContent(hLabel, RESID_INVALID, caption, 1000);
			SMP_Label_StartAutoScroll(hLabel, 1);

			GAL_Rectangle(PHYSICALGC, ImgRect.left, ImgRect.top, ImgRect.width, ImgRect.height, COLOR_focus);
			GAL_Rectangle(PHYSICALGC, ImgRect.left+2, ImgRect.top+2, ImgRect.width-4, ImgRect.height-4, COLOR_focus);
			Drawimg_Bmp(pData->pimgbuf, pData->buflen, imginfo.x,imginfo.y, imginfo.w, imginfo.rope);
		}
		break;

	case WM_COMMAND:
		{
			WID id = LOWORD(wParam);
			//WORD code = HIWORD(wParam);

			switch(id)
			{
			}
		}
		break;
	}
	return 0;
}

//��ʾbmpͼƬ
int32 Drawimg_Bmp(uint16 *bmpbuf, int32 buflen, int16 x, int16 y, int16 w, uint16 rope)
{
	int32 ret = MR_FAILED;
	int32 h = 0;

	h = buflen/w/2;
	if(h < 1)
	{
		h = 1;
		imginfo.h = 1;
	}else
		imginfo.h = (int16)h;

	ret = mrc_bitmapShowEx(bmpbuf, x,y ,w, w, (int16)h, rope, 0,0);

	return ret;
}