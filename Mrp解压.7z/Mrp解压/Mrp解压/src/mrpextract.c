#include "mrpextract.h"
#include "mrpeditwnd.h"
#include "topwnd.h"
//#include "platopen.h"
#include "imgshow.h"
#include "comfun.h"

/*  SGL �ؼ� */
#include "smp_list.h"
#include "smp.h"
#include "bmp.h"
#include "string.h"
#include "i18n.h"
#include "smp_titlebar.h"
#include "smp_toolbar.h"
#include "smp_menu.h"
#include "smp_menuwnd.h"
#include "smp_msgbox.h"

#include "mrc_exb.h"

enum Wids1
{
	WID_LIST=1,
	WID_TITLEBAR,
	WID_TOOLBAR,
	WID_OPT_MENU,
	WID_EXT_MENU
};

typedef struct AppData
{
	int32 index;
	char packname[80];
	int32 hEdit;
	HWND hList;
}APPDATA, *PAPPDATA;

static PMRPFILESINFO MrpFiles; //�洢mrp���ļ�
static int32 count; 
static char extdir[20];
static failedpoint;


int GetFileNumber1(VOID)
{
	return count;
}

VOID AddFileToList1(int index, PSMPROWDATA pData)
{
	int w, h;

	if (!pData || index<0 || index > count) //�����������
		return;

	switch(MrpFiles[index].type)
	{
	case FILE_AUDIO:
		pData->hBmp = SGL_LoadBitmap(BMP_AUDIO, &w, &h);
		break;
	case FILE_IMAGE:
		pData->hBmp = SGL_LoadBitmap(BMP_IMAGE, &w, &h);
		break;
	case FILE_MRP:
		pData->hBmp = SGL_LoadBitmap(BMP_MRP, &w, &h);
		break;

	default:
		pData->hBmp = SGL_LoadBitmap(BMP_TEXT, &w, &h);
		break;
	}

	pData->margin = 4;              //�б�����
	pData->colWidth0 = (uint16)w;   //ͼ�����
	pData->colHeight0 = (uint16)h;  //ͼ��߶�
	pData->cols->width = SCREEN_WIDTH - 4 - w - 20;  //�б�����
	pData->cols->str = (PCWSTR)MrpFiles[index].filename;    //�ļ���
}

/* ��ȡmrp�ļ���������ļ���
* ReadMrpFiles
* ������
*     mrp�ļ���
* ����ֵ��
*     �洢mrp�ļ��б��Ľṹ��ָ��
*/
int32 ReadMrpFiles(PSTR mrpname) //, PMRPFILESINFO mrpFiles
{
	int32 fd = 0;  
	int32 flStar = 0, temp = 0, flEnd = 0; //MRP �ļ��б���ֹλ��
	int32 fnLen = 0;   //mrp ���ļ�������
	int32 fCount = 0;  //mrp ���ļ���Ŀ
	char mrphead[5] = {0};  //��֤mrp�ļ�ͷ
	UCHAR fName[40] = {0};  //�ļ���

	fd = mrc_open(mrpname, MR_FILE_RDONLY);

	//���ж��Ƿ�Ϊ��ȷ��MRP��ʽ
	mrc_seek(fd, 0, MR_SEEK_SET);
	mrc_read(fd, mrphead, 4);
	if( mrc_strncmp(mrphead, "MRPG", 4) != 0 ) 
	{
		mrc_close(fd);
		return MR_FAILED;
	}

	//��ȡ�ļ��б��յ�λ��
	mrc_read(fd, &flEnd, 4);
	flEnd += 8;
	//��ȡ�ļ��б���ʼλ��
	mrc_seek(fd, 12, MR_SEEK_SET);
	mrc_read(fd, &flStar, 4);
	temp = flStar;
	//��ʼ��ȡ�ļ�,��ȡ�ļ���
	while(flStar < flEnd)
	{
		++fCount;
		mrc_seek(fd, flStar, MR_SEEK_SET);
		mrc_read(fd, &fnLen, 4);      //��ȡ�ļ�������
		flStar = flStar + fnLen + 16; //�����¸��ļ�
	}
	//��ʼ���
	MrpFiles = (PMRPFILESINFO)mrc_malloc(fCount * sizeof(MRPFILESINFO));
	mrc_memset(MrpFiles, 0, fCount * sizeof(MRPFILESINFO));
	fCount = 0;
	flStar = temp;
	while(flStar < flEnd)
	{
		mrc_seek(fd, flStar, MR_SEEK_SET);
		mrc_read(fd, &fnLen, 4);      //��ȡ�ļ�������
		mrc_read(fd, fName, fnLen);
		mrc_memcpy(MrpFiles[fCount].filename, fName, fnLen);
		MrpFiles[fCount].type = (uint8)GetFileFormat((PSTR)fName);

		flStar = flStar + fnLen + 16; //�����¸��ļ�
		++fCount;

		mrc_memset(&fName, 0, 20);
		fnLen = 0;
	}
	mrc_close(fd);
	return (fCount);
}

/**
 * ��ѹMRP
 * ���أ�
 *  	>0 ��ѹ�ɹ���Ŀ
 *	    MR_FAILED ʧ��
 * ������
	  packname:
	     �ļ�����mrp��
	  filename��
		 �ļ���
 *
 */
int32 ExtractMrpFiles(PSTR packname, PCSTR filename)
{
	int32 ret = MR_FAILED;
	uint8* filebuf = NULL;  //��ѹ�ļ�����
	int32 filelen = 0;   //��ѹ�ļ�����
	char ExtFileName[80] = {0};
	int32 fd = 0;

	if(mrc_strlen(extdir) == 0)
		mrc_strcpy(extdir, "temp");

	if( MR_IS_DIR != mrc_fileState((PCSTR)extdir) )
		mrc_mkDir((PCSTR)extdir);

	ret = mrc_readFileFromMrpExA(packname, filename, &filebuf, &filelen, 3);
	if(ret == MR_SUCCESS) 
	{
		mrc_strcpy(ExtFileName, (PSTR)extdir);
		mrc_strcat(ExtFileName, "/");
		mrc_strcat(ExtFileName, filename); //�ϳ��ļ���

		fd = mrc_open(ExtFileName, MR_FILE_RDWR | MR_FILE_CREATE);
		if(fd != 0)
		{
			mrc_write(fd, filebuf, filelen);
			mrc_close(fd);
			mrc_freeFileData(filebuf, filelen);
		}else  //�����ļ�ʧ��
		{
			failedpoint = 1;
			mrc_freeFileData(filebuf, filelen);
			return MR_FAILED;
		}
	}else  //��ȡ�ļ�ʧ��
	{
		failedpoint = 2;
		mrc_freeFileData(filebuf, filelen);
		return MR_FAILED;
	}

	filebuf = NULL;
	filelen = 0;
	return MR_SUCCESS;
}

VOID ShowMrpExtractWnd(HWND hParent, PSTR name)
{
	HideTopWindow(TOPWND_MRPEDIT, 0, 1);
	ShowTopWindow(TOPWND_EXTRACT, hParent, (DWORD)name);
}

VOID HideMrpExtractWnd(VOID)
{
	HideTopWindow(TOPWND_EXTRACT, 0, 1);
	ShowTopWindow(TOPWND_MRPEDIT, 0, 1001);
}

static const DWORD miExtract[] = 
{
	STR_SHOWIMG,     //0.ͼƬԤ��
	STR_PLAYSOUND,   //1.����
	STR_EXTRACT_CUR, //2.
	STR_EXTRACT_ALL  //3.
};
static VOID Show_Ext_Menu(HWND hWnd)
{
	PAPPDATA pData = _GET_WINDATA(hWnd, PAPPDATA);

	SMP_Menu_ClearMenuItems();
	SMP_Menu_SetMenuItem2(0, miExtract, TABLESIZE(miExtract));

	if(MrpFiles[pData->index].type != FILE_AUDIO)
		SMP_Menu_DisableMenuItem(1, 1); 
	if(MrpFiles[pData->index].type != FILE_IMAGE)
		SMP_Menu_DisableMenuItem(0, 1); 

	SMP_Menu_Popup(WID_EXT_MENU, SMP_MENUS_BOTTOMLEFT, hWnd, 30, _HEIGHT(hWnd) - SMP_TOOLBAR_HEIGHT - 30, NULL);
}

static const DWORD miOption[] = 
{
	STR_EXTDIR //��ѹĿ¼
};
static const DWORD miSelDir[] =
{
	STR_SELDIR,
	STR_NEWDIR
};
static VOID Show_Opt_Menu(HWND hWnd)
{
	SMP_Menu_ClearMenuItems();
	SMP_Menu_SetMenuItem2(0, miOption, TABLESIZE(miOption));
	SMP_Menu_SetMenuItem2(TABLESIZE(miOption), miSelDir, TABLESIZE(miSelDir));
	SMP_Menu_SetSubMenu(0, TABLESIZE(miOption));
	SMP_Menu_DisableMenuItem(1, 1); 
	SMP_Menu_Popup(WID_OPT_MENU, SMP_MENUS_BOTTOMLEFT, hWnd, 0, _HEIGHT(hWnd) - SMP_TOOLBAR_HEIGHT , NULL);
}

LRESULT Mrp_Extract_WndProc(HWND hDlg, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	PAPPDATA pData = _GET_WINDATA(hDlg, PAPPDATA);
	HWND hControl;

	switch(Msg)
	{
	case WM_CREATE:
		{
			pData = (PAPPDATA)SGL_MALLOC(sizeof(APPDATA));
			if(!pData){
				SGL_TRACE("%s, %d: memory out\n", __FILE__, __LINE__);
				return 1;
			}
			SGL_MEMSET(pData, 0, sizeof(APPDATA));
			_SET_WINDATA(hDlg, pData);

			//����������
			hControl = SGL_CreateWindow(SMP_Titlebar_WndProc,
				0, 0, SCREEN_WIDTH, SMP_HEADER_HEIGHT,
				WID_TITLEBAR, SMP_TITLEBAR_STATIC,0);
			SMP_Titlebar_SetContent(hControl, BMP_ICO1, SGL_LoadString(STR_EXTRACT_WND));
			SGL_AddChildWindow(hDlg, hControl);

			pData->hList = SGL_CreateWindow(SMP_List_WndProc,
				0, SMP_HEADER_HEIGHT ,
				SCREEN_WIDTH, SCREEN_HEIGHT - SMP_HEADER_HEIGHT - SMP_TOOLBAR_HEIGHT,
				WID_LIST, WS_TABSTOP|WS_CHILD, 0);
			SMP_List_SetDataProvider(pData->hList, GetFileNumber1, AddFileToList1);
			SGL_AddChildWindow(hDlg, pData->hList);

			//����������
			hControl = SGL_CreateWindow(SMP_Toolbar_WndProc, 
				0,  _HEIGHT(hDlg) - SMP_TOOLBAR_HEIGHT, _WIDTH(hDlg), SMP_TOOLBAR_HEIGHT,
				WID_TOOLBAR, 0, 0);
			_FGCOLOR(hControl) = COLOR_lightwhite;
			SMP_Toolbar_SetStrings(hControl,  STR_OPTIONS , RESID_INVALID, STR_BACK, TRUE);
			SGL_AddChildWindow(hDlg, hControl);

			break;
		}

	case WM_DESTROY:
		{
			if(pData) SGL_FREE(pData);
			break;
		}

	case WM_HIDE:
		{
			break;
		}
	case WM_INITFOCUS:
		SGL_SetFocusWindow(hDlg, pData->hList);
		break;

	case WM_SHOW:
		{
			PSTR name;
			name = _GET_USERDATA(hDlg, PSTR);
			if(name == (PSTR)1001)
				break;

			if(MrpFiles)
			{
				mrc_free(MrpFiles);
				MrpFiles = NULL;
			}
			mrc_memset(extdir, 0, 20);
			mrc_memset(pData->packname, 0, 80);
			count = 0;
			mrc_strcpy(pData->packname, name);
			count  = ReadMrpFiles(pData->packname);
			SMP_List_Refresh(pData->hList);
			SGL_UpdateWindow(pData->hList);
			break;
		}
	case WM_PAINT:
		{
			break;
		}

	case WM_KEYUP:
		{
			switch(wParam)
			{
			case MR_KEY_SOFTRIGHT: 
				HideMrpExtractWnd();
				return 1 ;

			case MR_KEY_SOFTLEFT:
				Show_Opt_Menu(hDlg);
				return 1 ;

			case MR_KEY_5:
				return 1 ;
			}
			break;
		}

	case MR_DIALOG_EVENT:
		{
			PWSTR text = NULL;
			PSTR buf;
			switch(wParam)
			{
			case MR_DIALOG_KEY_CANCEL:
				mrc_editRelease(pData->hEdit);
				pData->hEdit = 0;
				break;

			case MR_DIALOG_KEY_OK:
				if(pData->hEdit != 0)
					text = (PWSTR)mrc_editGetText(pData->hEdit); //hEditΪmrc_editCreate�����ľ��
				if(text != NULL)
				{
					buf  = (PSTR)UnicodeToChar(text);
					mrc_strncpy(extdir, buf, 20);
					mrc_free(buf);
				}
				mrc_editRelease(pData->hEdit);
				pData->hEdit = 0;
				break;
			}
			SGL_UpdateWindow(hDlg);
			break;
		}

	case MR_LOCALUI_EVENT:
		{
			uint8* buf;
			int32 namelen;
			PSTR buf2;

			switch(wParam)
			{
			case MR_LOCALUI_KEY_OK:
				mrc_platEx(1405, NULL, 0, (uint8**)&buf, &namelen, NULL);
				buf2 = mrc_strrchr((PCSTR)buf, '/');
				mrc_memset(extdir, 0, 20);
				mrc_strcpy(extdir, buf2+1);
				mrc_free(buf);
				mrc_platEx(1406, NULL, 0, NULL, NULL, NULL); //���������
				SGL_UpdateWindow(hDlg);
				break;

			case MR_LOCALUI_KEY_CANCEL:
				mrc_platEx(1406, NULL, 0, NULL, NULL, NULL); //�����������
				SGL_UpdateWindow(hDlg);
				break;
			}
			break;
		}

	case WM_COMMAND:
		{
			WID id = LOWORD(wParam);
			WORD code = HIWORD(wParam);

			switch(id)
			{
			case WID_OPT_MENU:
				{
					switch(code)
					{
					case STR_SELDIR: //ѡ��Ŀ¼
						//Plat_SelDir();
						break;

					case STR_NEWDIR:
						pData->hEdit = mrc_editCreate((PCSTR)SGL_LoadString(STR_INPUT), (PCSTR)"", MR_EDIT_ANY, 10);   //STR_EDITΪ�༭���ʼ���ݵ���ԴID
						break;
					}
					break;
				}

				//�б��¼�
			case WID_LIST:
				{
					switch(code)
					{
					case SMP_LISTN_HILICHANGED:
						pData->index = (int)lParam;
						break;

					case SMP_LISTN_SELECTED:  //���������ļ������˵�������
					case SMP_LISTN_CLICKED:
						pData->index = (int)lParam;
						Show_Ext_Menu(hDlg);
						break;
					}
					break;
				}

			case WID_EXT_MENU:
				{
					char filename[40] = {0};
					char buf[50] = {0};
					switch(code)
					{
					case STR_EXTRACT_CUR:
						{
							mrc_strcpy(filename, MrpFiles[pData->index].filename);
							if(MR_SUCCESS == ExtractMrpFiles(pData->packname, filename) )
							{
								mrc_strcpy(buf, "�ļ�������mythroad/");
								mrc_strcat(buf, extdir);
								SMP_MsgBox(0, hDlg, NULL, SGL_LoadString(STR_SUCCESS), (PCWSTR)CharToUnicode(buf), ID_OK|SMP_MSGBOXS_AUTOCLOSE , NULL);
							}
							else
							{
								mrc_sprintf(buf, "��ѹʧ�ܣ�ʧ�ܵ�%d", failedpoint);
								SMP_MsgBox(0, hDlg, NULL, SGL_LoadString(STR_HINT), (PCWSTR)CharToUnicode(buf), ID_OK|SMP_MSGBOXS_AUTOCLOSE , NULL);
							}
							break;
						}

					case STR_EXTRACT_ALL:
						{
							int i, scount = 0;

							SMP_MsgBox(0, hDlg, NULL, SGL_LoadString(STR_HINT), SGL_LoadString(STR_HINT6), ID_NON , NULL);
							for(i=0; (i<count && i<200); ++i)
							{
								mrc_strcpy(filename, MrpFiles[i].filename);
								if(MR_SUCCESS == ExtractMrpFiles(pData->packname, filename) )
									scount++;
							}
							mrc_sprintf(buf, "�ɹ� %d, ʧ�� %d!\n�ļ�������mythroad/%s", scount, count-scount, extdir);
							SMP_MsgBox(0, hDlg, NULL, SGL_LoadString(STR_SUCCESS), (PCWSTR)CharToUnicode(buf), ID_OK , NULL);
							break;
						}

					case STR_PLAYSOUND: //��������
						break;

					case STR_SHOWIMG: //ͼƬԤ��
						{
							IMGFILEDATA image;
							image.packname = pData->packname;
							image.filename = MrpFiles[pData->index].filename;

							if(MrpFiles[pData->index].type == FILE_IMAGE)
								ShowImage(&image);
						}
						break;
					}
					break;
				}
			}
			break;
		}
	}
	return SMP_MenuWnd_WndProc(hDlg, Msg, wParam, lParam);  
}


