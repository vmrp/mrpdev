#include "application.h"
#include "topwnd.h"
#include "md5.h"
#include "mrc_exb.h"
#include "bmp.h"
#include "smp.h"

#include "fontread.h"

#define STR_ERROR   "\x8f\x6f\x4e\xf6\x88\xab\x60\x76\x61\xf\x78\x34\x57\x4f\xff\x1\x0\xa\x8b\xf7\x4e\xa\x0\x68\x0\x74\x0\x74\x0\x70\x0\x3a\x0\x2f\x0\x2f\x0\x6d\x0\x70\x0\x72\x0\x79\x0\x78\x0\x2e\x0\x63\x0\x6e\x4e\xb\x8f\x7d\x6b\x63\x72\x48\x8f\x6f\x4e\xf6"

static int32 g_timer = 0;       /*��ʱ��*/

//��ʾͼƬ����
void DrawBmp(DWORD BMPID, uint32 BgClr)
{
	int w,h;
	HBITMAP bmp;

	GAL_ClearScreen(BgClr);
	bmp = SGL_LoadBitmap(BMPID, &w, &h); 
	mrc_bitmapShowEx(bmp, (int16)(DIV(SCREEN_WIDTH,2)-DIV(w,2)), (int16)(DIV(SCREEN_HEIGHT,2)-DIV(h,2)), (int16)w, (int16)w, (int16)h, BM_COPY, 0, 0); 
	GAL_Flush(PHYSICALGC);
}

int32 MD5Checksum(PSTR filename, int32 offset, BOOL CheckMrphead, PSTR correct)
{
	PSTR key = "102ecdf";
	uint8 md5[17] = {0};		//md5����ֵ 
	uint8 md5Str[33] = {0};		//md5���ܴ��ַ���ֵ
	int32 result = MR_FAILED;
	PSTR packname = mrc_getPackName();

	if(CheckMrphead) //У��mrpͷ
	{
		int32 handel = 0, strLen = 0;
		char appname[20] = {0};  //��ʾ��
		char vender[20] = {0};   //����
		char descrip[60] = {0};  //Ӧ��˵��
		char buf[100] = {0};

		handel = mrc_open(packname, MR_FILE_RDONLY);
		mrc_seek(handel, 28, MR_SEEK_SET); //����ʾ��
		mrc_read(handel, appname, 20);
		mrc_seek(handel, 88, MR_SEEK_SET); //������
		mrc_read(handel, vender, 20);
		mrc_seek(handel, 128, MR_SEEK_SET);//��Ӧ��˵��
		mrc_read(handel, descrip, 60);
		
		mrc_strcpy(buf, appname);  //ƴ�ӳɴ�����У��
		mrc_strcat(buf, vender);
		mrc_strcat(buf, descrip);
		strLen = mrc_strlen(buf);

		MD5((BYTE*)buf, strLen, (BYTE*)md5);
		if(handel != 0)
			mrc_close(handel);
		handel = 0;
	}
	else  //У��logo
	{
		int32 fileLen;
		uint8 *buf;
		if(filename != NULL)
		{
			buf = mrc_readFileFromMrp(filename, &fileLen, 0);
			md5MakeFromMem(key, buf, offset, fileLen, md5);
			mrc_freeFileData((uint8*)buf, fileLen);
			buf = NULL;
		}
	}

	//�Ƚ�MD5ֵ����ͬ��result=0����MR_SUCCESS
	md5ToString(md5, md5Str);
	result = mrc_strncmp((PSTR)md5Str, correct, 32*sizeof(uint8));

	return result;
}


// ���������� 
void CreatMainWin(int32 data)
{
	mrc_timerStop(g_timer);
	mrc_timerDelete(g_timer);
	SGL_ReleaseBitmap(BMP_LOGOSK);
	InitTopWindow(); 
	ShowTopWindow(TOPWND_MRPEDIT, 0, 0);
}

//��ʾ����logo����
void StartLogoShow(void)
{
	DrawBmp(BMP_LOGOSK, COLOR_black);
	g_timer = mrc_timerCreate();
	if(g_timer)
		mrc_timerStart(g_timer, 1000, 0, CreatMainWin, 0);
}

int InitApplication(VOID)
{	
	PSTR file_name, correct0 ; 
	mr_screenRectSt rect = {10,100,220,220};
	mr_colourSt color = {192,192,192};

	correct0 = "BBAE59485C47C76823D7424B2C6B5E14";
	file_name = "logo_sk.bmp";

	if( (MD5Checksum(file_name, 121, FALSE, correct0) == MR_SUCCESS))
	{
		StartLogoShow(); 

#ifdef FONT_SUPPORT  
		FontModuleInit(0, 0, 1);
#else
#endif
		return MR_SUCCESS;
	}

	mrc_clearScreen(0,0,0);
	mrc_drawTextEx((PSTR)STR_ERROR ,
		rect.x ,rect.y ,rect ,color ,
		DRAW_TEXT_EX_IS_UNICODE|DRAW_TEXT_EX_IS_AUTO_NEWLINE,
		MR_FONT_BIG);
	mrc_refreshScreen(0,0,240,320);

	// TODO: Add your code here!
	return 0;
}


int ExitApplication(VOID)
{
	mrc_clearScreen(0,0,0);

#ifdef FONT_SUPPORT   /*�˳��ͷ��ֿ�*/
	FontModuleRelease();
#else
#endif

	mrc_drawText("�����˳�������", 20, 80, 30,144,255, 0, MR_FONT_MEDIUM);
	mrc_refreshScreen(0,0,240,320);
	// TODO: Add your code here!
	return 0;
}


int PauseApplication(VOID)
{
	// TODO: Add your code here!
	return 0;
}


int ResumeApplication(VOID)
{
	// TODO: Add your code here!
	return 0;
}

