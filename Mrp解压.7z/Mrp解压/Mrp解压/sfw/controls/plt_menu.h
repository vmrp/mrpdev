#ifndef _PLT_MENU_H
#define _PLT_MENU_H

#include "window.h"

/**
   \defgroup pltmenu Platform Menu window

  To work with the platform menu:
  - Create the platform menu window
  - Setup the menu information
  - Setup the menu items information
  - Add to the desktop
  - Response to MR_MENU_SELECT

  \code

  //create a platform menu and show it
  HWND hMenu = SGL_CreateWindow(PLT_Menu_WndProc,
  			0, 0, SCREEN_WIDTH, SCREEN_HEIGHT,
  			id, 0, 0);
  PLT_Menu_SetInfo(hMenu, title, items);
  PLT_Menu_SetMenuItem(hMenu, 0, ...);
  PLT_Menu_SetMenuItem(hMenu, 1, ...);
  PLT_Menu_SetMenuItem(hMenu, 2, ...);
  ...
  _LISTENER(hMenu) = hWnd; // do not forget to set the listener 
  SGL_AddChildWindow(HWND_DESKTOP, hMenu);

  //response the WM_COMMAND 
  case WM_COMMAND:
  	WID id = LOWORD(wParam);
  	WORD code = HIWORD(wParam);
  	if(id == "the platform menu id")
  	{
  		if(code == MR_MENU_SELECT)
  		{
  			int index = (int)lParam; //the select menu item index
  			//your code
  			......
  		}else if(code == MR_MENU_RETURN){
			//your code
			......
  		}
  	}
  
  \endcode

  @ingroup controls
  @{
 */

	/**
	 * \name Window Member Functions
	 * @{
	 */
	 
/**
 * \brief Set the menu information.
 *
 * This function should called after the menu window created to
 * setup the menu information.
 *
 * \param hMenu the platform menu window
 * \param title the title string
 * \param items the menu items count
 */
VOID PLT_Menu_SetInfo(HWND hMenu, PCWSTR title, Sint32 items);

/**
 * \brief Set a Menu item
 *
 * \param hMenu the platform menu handle
 * \param index the menu item index
 * \param title the menu item string
 */
VOID PLT_Menu_SetMenuItem(HWND hMenu, int index, PCWSTR title);

	/** @} */

	/**
	 * \name Window Procedure
	 * @{
	 */

/**
 * \brief The platform menu window procedure.	
 *
 * \param hMenu the button window handle
 * \param Msg the window message
 * \param wParam the first parameter
 * \param lParam the second parameter
 * \return the result of message process 
 */
LRESULT PLT_Menu_WndProc(HWND hMenu, UINT Msg, WPARAM wParam, LPARAM lParam);
	
	/** @} */

/** @} end of pltmenu */

#endif
