#ifndef _SMP_MSGBOX_H
#define _SMP_MSGBOX_H

#include "window.h"

/**
  \defgroup smp_msgbox Simple MsgBox

  To work with the simple msgbox:
  - Show the msgbox 
  - Response the notify message

  \code
  	//just call this function to show the msgbox
  	SMP_MsgBox(...);

  	//response the notify message
	case WM_COMMAND:
		WID id = LOWORD(wParam);
		WORD code = HIWORD(wParam);

		if(id == "the msgbox id")
		{
			HWND hMsgbox = (HWND)lParam;
			if(code == ID_OK)
			{
				//press ok
			}else{
				//press cancel
			}
		}	
  \endcode

  @ingroup controls
  @{
*/

	/**
	* \name Window Styles
	* @{
	*/

/**
 * \brief Identifer Non.
 */
#define ID_NON		0 //when modal window close by the window manangement system

/**
 * \brief Indicates the msgbox has the ok button.
 */
#define ID_OK		0x0001L

/**
 * \brief Indicates the msgbox has the cancel button.
 */
#define ID_CANCEL	0x0002L

/**
 * \brief Indicates the msgbox button should be "YES/NO"
 */
#define ID_YESNO	0x0004L

/**
 * \brief Indicates the msgbox can terminate itself after a specific interval.
 *
 * This style can just only used when the msgbox only has less than one button.
 */
#define SMP_MSGBOXS_AUTOCLOSE		0x0008L

	/** @} */

/**
 * \brief The close timer interval to close the msgbox.
 *
 * when the msgbox only has one button, 
 * the msgbox will terminate after SMP_MSGBOX_AUTOCLOSE_INTERVAL ms.
 */
#define SMP_MSGBOX_AUTOCLOSE_INTERVAL	3000 //ms

	/**
	 * \name Window Member Functions
	 * @{
	 */

/**
 * \brief Show a Message box.
 *
 * \param id the msg box id
 * \param hParent the top-level window handle
 * \param hBmp the icon
 * \param title the title string
 * \param content the content string
 * \param style the window style and buttons could be the | value of ID_OK, ID_CANCEL, ID_YESNO
 * \param listener who receive the notify message, parenter will get the messages when it is NULL
 */
HWND SMP_MsgBox(WID id, HWND hParent, HBITMAP hBmp, PCWSTR title, PCWSTR content, DWORD style, HWND listener);

	/** @} */
	
	/**
	 * \name Window Procedure
	 * @{
	 */

/**
 * \brief The msgbox window procedure.
 *
 * \param hDlg the window handle
 * \param Msg the window message
 * \param wParam the first parameter
 * \param lParam the second parameter
 * \return the result of message process 
 */
LRESULT SMP_MsgBox_WndProc(HWND hDlg, UINT Msg, WPARAM wParam, LPARAM lParam);
	
	/** @} */

/** @} end of smp_msgbox */

#endif /* _SMP_MSGBOX_H */

