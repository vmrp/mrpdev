#ifndef _SMP_MENU_H
#define _SMP_MENU_H

#include "window.h"

/**
 * \defgroup controls Common Controls
 * @{
 */

/**
  \defgroup smp_menu Simple Menu

  To work with the simple menu:
  - Setup the menu items
  - Call simple menu APIs to show the menu
  - Response the menu notify message

  Below are the different ways to setup menu items and show a popup menu:
  
  Sample Code 1:
  \code
  	SMP_Menu_ClearMenuItems();
  	SMP_Menu_SetMenuItem(0, ..., 1);
  	SMP_Menu_SetMenuItem(1, ..., 2);
  	SMP_Menu_SetMenuItem(2, ..., 3);
  	...

  	SMP_Menu_Popup(...);
  \endcode

  Sample Code 2:
  \code
  	//global menu items information
	static const DWORD miOptions [] =
	{
		STR_CONNECT,
		STR_EXIT,
		STR_REGISTER,
		...
	};

	//your code
  	SMP_Menu_ClearMenuItems();
	SMP_Menu_SetMenuItem2(0, miOptions, sizeof(miOptions)/sizeof(miOptions[0]));
	...
	
  	SMP_Menu_Popup(...);
  \endcode

  Sample code 3:
  \code
  	//when the popup is a simple menu without submenu, there is a wrapper for sample code 2

  	//global menu items information
	static const DWORD miOptions [] =
	{
		STR_CONNECT,
		STR_EXIT,
		STR_REGISTER,
		...
	};

	SMP_Menu_Popup2(..., miOptions, sizeof(miOptions)/sizeof(miOptions[0]));
  \endcode

  Response to the Menu notify message.

  \code
	case WM_COMMAND:
		WID id = LOWORD(wParam);
		WORD code = HIWORD(wParam); // is the menu item id

		if(id == "the menu id")
		{
			DWORD userdata = (DWORD)lParam; //if setted with the menu item
			switch(code)
			{
			case STR_CONNECT:
				//handle the notify event.
				break;
			case STR_EXIT:
				break;
			case STR_REGISTER:
				break;
			...
			}
		}	
  \endcode

  @ingroup controls
  @{
 */

/**
 * \brief Max Menu items in a menu. Reconfigure it as needed.
 */
#define SMP_MENU_MAX_MENUITEM	20

	/**
	* \name Window Styles
	* @{
	*/

/**
 * \brief Indicates the (x, y) position in popup function is the menu (left, button)
 */
#define SMP_MENUS_BOTTOMLEFT			0x0001L	

#if 0 //not implemented yet
/**
 * \brief Indicates the (x, y) position in popup function is the menu (right, button)
 */
#define SMP_MENUS_BOTTOMRIGHT		0x0002L
#endif

/**
 * \brief Indicates the (x, y) position in popup function is the menu (left, top)
 */
#define SMP_MENUS_TOPLEFT				0x0004L

#if 0 //not implemented yet
/**
 * \brief Indicates the (x, y) position in popup function is the menu (right, top)
 */
#define SMP_MENUS_TOPRIGHT			0x0008L
#endif

/**
 * \brief Indicates that is a flat menu with fixed width.
 *
 * This style only used in SMP_Menu_PopupFlat to show a flat style menu.
 * The flat menu just one level, so do not use this style for a normal menu,
 * it is used by combo box and some other controls.
 */
#define SMP_MENUS_FLAT				0x0010L

	/** @} */

/**
 * \brief Seperator menu item id.
 */
#define SMP_MENU_SEPERATOR		0xffff

	/**
	 * \name Window Member Functions
	 * @{
	 */

/**
 * \brief Clear the simple menu items.
 */
VOID SMP_Menu_ClearMenuItems(VOID);

/**
 * \brief Set a menu item with a index.
 * 
 * \param index the menu item index
 * \param id the menu item id
 * \param str the string displayed for the menuitem
 * \param data the menuitem data
 * \param next the next menu item, -1 means have no next menuitem
 */
VOID SMP_Menu_SetMenuItem(int index, WID id, PCWSTR str, DWORD data, int next);

/**
 * \brief Setup menuitems with a string resource array.
 *
 * \param start the start index
 * \param items the string resource array
 * \param size the str array size
 */
VOID SMP_Menu_SetMenuItem2(int start, const DWORD* items, int size);

/**
 * \brief Set a sub menu.
 *
 * \param index the menu item index which will has the submenu
 * \param sub the sub menu items
 */
VOID SMP_Menu_SetSubMenu(int index, int sub);

/**
 * \brief Check a menu item.
 * 
 * \param index the menu item index
 * \param check TRUE checked, FALSE unchecked
 */
VOID SMP_Menu_CheckMenuItem(int index, BOOL check);

/**
 * \brief Disable a menu item.
 *
 * \param index the menu item index
 * \param disable TRUE disalbe, FALSE enable
 */
VOID SMP_Menu_DisableMenuItem(int index, BOOL disable); 

/**
 * \brief Popup the global menu with menuitems.
 *
 * \param id the Menu Window ID
 * \param style the Menu style
 * \param hParent the top-level/modal window handle
 * \param x the left position
 * \param y the top position
 * \param listener the window to handle the WM_COMMAND message
 * \return the global menu handle
 */
HMENU SMP_Menu_Popup(WID id, DWORD style, HWND hParent, int x, int y, HWND listener);

/**
 * \brief Popup the global menu with menuitems.
 *
 * \param id the Menu Window ID
 * \param style the Menu style
 * \param hParent the top-level/modal window handle
 * \param x the left position
 * \param y the top position
 * \param items the Menu Item string array
 * \param size the menu item string array size
 * \param listener the window to handle the WM_COMMAND message
 * \return the global menu handle
 */
HMENU SMP_Menu_Popup2(WID id, DWORD style, HWND hParent, int x, int y, const DWORD* items, int size, HWND listener);

/**
 * \brief Popup the global flat style menu with fixed width.
 *
 * \param id the Menu Window ID
 * \param style the Menu style
 * \param hParent the top-level/modal window handle
 * \param x the left position
 * \param y the top position
 * \param w the menu width
 * \param listener the window to handle the WM_COMMAND message
 * \return the global menu handle
 */
HMENU SMP_Menu_PopupFlat(WID id, DWORD style, HWND hParent, int x, int y, int w, HWND listener);

	/** @} */

	/**
	 * \name Window Procedure
	 * @{
	 */

/**
 * \brief The simple menu window procedure.
 *
 * \param hMenu the window handle
 * \param Msg the window message
 * \param wParam the first parameter
 * \param lParam the second parameter
 * \return the result of message process 
 */
LRESULT SMP_Menu_WndProc(HMENU hMenu, UINT Msg, WPARAM wParam, LPARAM lParam);

	/** @} */

/** @} end of smp_menu */

/** @} end of controls */

#endif /* _SMP_MENU_H */

