
//begin the sounds
#define SOUND_ONLINE 0
#define SOUND_MSG 1

#define RES_SOUND_COUNT 2
