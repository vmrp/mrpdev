#ifndef _IMGSHOW_H
#define _IMGSHOW_H

#include "window.h"


//ͼƬ�������ڰ�
typedef struct ImgFileData
{
	PSTR packname;
	PSTR filename;
}IMGFILEDATA, *PIMGFILEDATA;

VOID ShowImage(PIMGFILEDATA image);

LRESULT ImigShow_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);

#endif