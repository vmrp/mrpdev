#ifndef _TOPWND_H
#define _TOPWND_H

#include "window.h"

/**
 * \brief top window id start
 */
#define TOPWND_ID_START		300


/**
 * \brief top level window ids
 *
 * A top window id SHOULD has a entry in
 * InitTopWindow implement.
 */
enum {
	TOPWND_MAINWND = TOPWND_ID_START,
	//add your top window id here
	TOPWND_MRPEDIT,   //mrp�༭������ID
	TOPWND_IMIGSHOW,  //
	TOPWND_EXTRACT,   //
	TOPWND_OPENDLG,   //���ļ�����
	MAX_TOPWND_COUNT  //keep it
};

/**
 * \brief initialize the top windows
 *
 * This function should called in InitApplication.
 */
VOID InitTopWindow(VOID);

/**
 * \brief get the top window
 *
 * \param wid the top window id
 * \return 
 */
HWND GetTopWindow(WID wid);

/**
 * \brief show a top window
 *
 * \param wid the top window id
 * \param listener the top window listener
 * \param userdata the user specific data
 * \return the top window handle, NULL when failed
 */
HWND ShowTopWindow(WID wid, HWND listener, DWORD userdata);

/**
 * \brief hide a top window
 *
 * \param wid the top window id
 * \param destroy if destory the window
 * \param redraw if refresh the top window
 */
VOID HideTopWindow(WID wid, BOOL destroy, BOOL redraw);


#endif
