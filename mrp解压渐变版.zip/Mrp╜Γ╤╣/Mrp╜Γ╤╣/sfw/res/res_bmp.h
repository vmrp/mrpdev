
//begin the bitmaps
#define BMP_ICO1 0
#define BMP_TEXT 1
#define BMP_ARCHIVE 2
#define BMP_AUDIO 3
#define BMP_IMAGE 4
#define BMP_MRP 5
#define BMP_LOGO1 6
#define BMP_LOGOSK 7
#define BMP_FILE 8
#define BMP_FOLDER 9

#define RES_BITMAP_COUNT 10
