#ifndef _SMP_DATEPICKER_H
#define _SMP_DATEPICKER_H

#include "window.h"

/**
  \defgroup smp_datepicker Simple DatePicker

  To work with the simple date picker:
	- Create the date picker window
	- Set the current date
	- Add to the parent window
	- Response the notify messages
  
  \code
	//create a date picker
	hControl = SGL_CreateWindow(SMP_DatePicker_WndProc, ...);
	SMP_DatePicker_Set2CurrentDate(hControl, FALSE, FALSE);
	SGL_AddChildWindow(hWnd, hControl);

	//response to notify messages
	case WM_COMMAND:
		WID id = LOWORD(wParam);
		WORD code = HIWORD(wParam);

		if(id == "the datepicker id")
		{
			switch(code)
			{
			case SMP_DATEPICKERN_VALUECHANGED:
				HWND hControl = (HWND)lParam; // the datepicker window handle
				//handle the notify event.
				break;
			}
		}	
  \endcode
  
  @ingroup controls
  @{
*/

	/**
	 * \name Window Notify Messages
	 * @{
	 */
	 
/**
 * \brief Sent when the datepicker window value changed.
 *
 * \code
 *	case WM_COMMAND:
 *		WID id = LOWORD(wParam);
 *		WORD code = HIWORD(wParam);
 *
 *		if(id == "the calendar id" && code == SMP_DATEPICKERN_VALUECHANGED)
 *		{
			HWND hControl = (HWND)lParam; // the datepicker window handle
 * 			//handle the notify message
 *		}
 * \endcode
 *
 * \param hControl the calendar handle send this message
 */
#define SMP_DATEPICKERN_VALUECHANGED		0x0001

	/** @} */

	/**
	 * \name Window Member Functions
	 * @{
	 */

/**
 * \brief Set the new date 
 *
 * \param hWnd the date picker window handle
 * \param year the year of the date
 * \param month the month of the date
 * \param day the day of the date
 * \param notify if send notify message
 * \param update if redraw the window
 */
VOID SMP_DatePicker_SetDate(HWND hWnd, int year, int month, int day, BOOL notify, BOOL update);

/**
 * \brief Get the date from the control
 *
 * \param hWnd the Date picker window handle
 * \param[out] year the year of the date
 * \param[out] month the month of the date
 * \param[out] day the day of the date
 */
VOID SMP_DatePicker_GetDate(HWND hWnd, int* year, int* month, int* day);

/**
 * \brief Set the Date picker to current date
 *
 * \param hWnd the date picker window handle
 * \param notify if send notify message
 * \param update if redraw the window
 */
VOID SMP_DatePicker_Set2CurrentDate(HWND hWnd, BOOL notify, BOOL update);

	/** @} */

	/**
	 * \name Window Procedure
	 * @{
	 */

/**
 * \brief The simple Date picker window procedure.
 *
 * \param hWnd the window handle
 * \param Msg the window message
 * \param wParam the first parameter
 * \param lParam the second parameter
 * \return the result of message process 
 */
LRESULT SMP_DatePicker_WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);

	/** @} */

/** @} end of smp_datepicker */


#endif
